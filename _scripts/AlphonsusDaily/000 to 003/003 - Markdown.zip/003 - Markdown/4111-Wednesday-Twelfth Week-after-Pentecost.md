# Wednesday\--Twelfth Week after Pentecost

## Morning Meditation

*X. \-- THE GLORY OF THE BLESSED VIRGIN MARY IN HEAVEN.*

Let us consider how exalted was the throne to which our Lady was raised in Heaven. \"If the mind of man,\" says St. Bernard, \"can never comprehend the immense glory prepared by God in Heaven for those who love Him, as St. Paul assures us, who then can ever comprehend the glory God prepared for His beloved Mother!\"

I.

Let us consider how exalted was the throne to which our Lady was raised in Heaven.

\"If the mind of man,\" says St. Bernard, \"can never comprehend the immense glory prepared in Heaven by God for those who on earth have loved Him, as the Apostle tells us, who can ever comprehend the glory God prepared for His beloved Mother, who, more than all men, loved Him on earth; nay, even from the very first moment of her creation, loved Him more than all men and Angels united? Rightly, then, does the Church sing that Mary, having loved God more than all the Angels, \"the Mother of God has been exalted above them all in the heavenly kingdom.\" *Exaltata est sancta Dei Genitrix super choros Angelorum ad coelestia regna.* Yes, she was exalted, says the abbot Guerric, above the Angels; so that she sees none above her but her Son, Who is the only-begotten of the Father.

Hence it is that the learned Gerson asserts that, as all the orders of Angels and Saints are divided into three Hierarchies, so does Mary of herself constitute a Hierarchy apart, the sublimest of all, and next to that of God. And, says St. Antoninus, as the mistress is, without comparison, above her servants, so is \"Mary, who is the sovereign Lady of the Angels, exalted incomparably above the angelic hierarchies.\" To understand this, we need only know what David said: *The Queen stood on thy right hand* (Ps. xliv. 10). And as an ancient author says, these words are explained as meaning that \"Mary is placed at the right hand of God.\"

II\.

It is certain, as St. Ildephonsus says, that Mary\'s good works incomparably surpassed in merit those of all the Saints, and therefore her reward must have surpassed theirs in the same proportion; for \"as that which she bore was incomprehensible, so is the reward which she merited and received incomprehensibly greater than that of all the Saints.\" And since it is certain that God rewards according to merit, as the Apostle writes, *who will render to every man according to his works* (Rom. ii. 6), it is also certain, as St. Thomas teaches, that the Blessed Virgin, \"who was equal to and even superior in merit to all men and Angels, was exalted above all the celestial orders.\" \"In fine,\" adds St. Bernard, \"let us measure the singular grace that she acquired on earth, and then we may measure the singular glory which she obtained in Heaven\"; for, \"according to the measure of her grace on earth is the measure of her glory in the kingdom of the Blessed.\"

## Spiritual Reading

*TO THEE DO WE SIGH, MOURNING AND WEEPING IN THIS VALLEY OF TEARS*

4.-THE NECESSITY OF MARY\'S INTERCESSION FOR OUR SALVATION.

St. Bernard say that \"as a man and a woman co-operated in our ruin, so it was proper that another man and another woman should co-operate in our Redemption, and these two were Jesus and His Mother Mary.\" \"There is no doubt,\" says the Saint, \"that Jesus Christ alone was more than sufficient to redeem us; but it was more becoming that both sexes should co-operate in the reparation of an evil in causing which both had shared.\" Hence Blessed Albert the Great calls Mary, the \"helper of the redemption\": and the Blessed Virgin herself revealed to St. Bridget, that \"as Adam and Eve sold the world for an apple, so did she with her Son redeem it as it were with one heart.\" This is confirmed by St. Anselm, who says that \"although God could create the world out of nothing, yet, when it was lost by sin, he would not repair the evil without the co-operation of Mary.\"

Suarez says that \"Mary co-operated in our salvation in three ways; first, by having merited, by a merit of congruity, the Incarnation of the Word; secondly, by having continually prayed for us whilst she was living in this world; thirdly, by having willingly sacrificed the life of her Son to God.\" For this reason our Lord has justly decreed, that, as Mary co-operated in the salvation of man with so much love, and at the same time gave such glory to God, so all men through her intercession are to obtain their salvation.

Mary is called \"the co-operator in our justification\"; for to her God has entrusted all graces intended for us; and therefore St. Bernard affirms that \"all men, past, present, and to come, should look upon Mary as the means and negotiator of the salvation of all generations.\"

Jesus Christ says that no one can find Him unless the Eternal Father first draws him by the means of Divine grace: *No man can come to me, except the Father who hath sent me, draw him* (Jo. vi. 44). Thus also does Jesus Christ address His Mother, says Richard of St. Laurence: \"No one comes to Me unless My Mother first of all draw him by her prayers.\" Jesus was the fruit of Mary, as St. Elizabeth told her: *Blessed art thou amongst women, and blessed is the fruit of thy womb* (Luke i. 42). Whoever, therefore, desires the fruit must go to the tree; whoever desires Jesus must go to Mary; and whoever finds Mary will most certainly find Jesus.

When St. Elizabeth saw that the most Blessed Virgin had come to visit her in her own house, not knowing how to thank her, and filled with humility, she exclaimed: *And whence is this to me, that the Mother of my Lord should come to me?* (Luke i. 43). But, we may ask, how could this be? Did not St. Elizabeth already know that not only Mary, but also Jesus, had entered her house? Why then does she say that she is unworthy to receive the Mother, and not, rather, that she is unworthy to receive the Son, Who had come to visit her? Ah, yes, it was because the Saint knew full well that when Mary comes she brings Jesus, and therefore it was sufficient to thank the Mother without naming the Son.

## Evening Meditation

*CONSIDERATIONS ON THE PASSION OF JESUS CHRIST*

I.

The Jews, not satisfied with the injuries and blasphemies they had offered to Jesus Christ, reproached Him with the Name of His Father, saying: *He trusted in God, let him now deliver him, if he will have him; for he said, I am the Son of God* (Matt. xxvii. 43). This sacrilegious expression of the Jews was already foretold by David, when he said in the Name of Christ: *All they that saw me laughed me to scorn \... saying: He trusted in God, let him deliver him, let him save him, seeing he delighted in him* (Ps. xxi. 8, 9). These very men who thus spoke were called bulls, dogs, and lions by David in the same Psalm: *Fat bulls have besieged me \... Many dogs have encompassed me \... Save me from the mouth of the lion* (Ps. xxi.). Thus, when the Jews said: *Let him now deliver him if he will have him* (Matt. xxvii. 43), they truly showed that they were these bulls, dogs, and lions foretold by David.

These very same blasphemies, which were one day to be spoken against the Saviour and against God, were already foretold by the Wise Man with even more exactness: *He boasteth that he hath the knowledge of God, and calleth himself the son of God \... He glorieth that he hath God for his father \... If he be the true son of God he will befriend him and will deliver him from the hands of his enemies \... Let us examine him, by outrages and tortures that we may know his meekness and try his patience. Let us condemn him to a most shameful death* (Wis. ii. 13-20).

The chief priests were stirred up by envy and hatred against Jesus Christ thus to insult Him; but, at the same time, they were not exempt from the fear of some great punishment, as they could not deny the miracles wrought by our Lord. Wherefore all the priests and chiefs of the Synagogue continued disturbed and in terror, and therefore desired to be present at His death, in order to be freed from this fear which tormented them. Seeing Him then fastened upon the Cross, and that He was not delivered from it by His Father, they proceeded with increased audacity to taunt Him with His helplessness and His saying He was the Son of God. They said: \"He gloried that He had God for His Father; why, then, does not God deliver Him if He loves Him as His Son?\" But these malicious men were in grievous error, for God did truly love Jesus Christ, and loved Him as His Son; and He loved Him on this very account, that Jesus was sacrificing His life upon the Cross for the salvation of men, in order to obey His Father. This Jesus Himself had said: *I lay down my life for my sheep \... therefore doth the Father love me, because I lay down my life* (Jo. x. 15, 17). The Father had already destined Him to be the victim of this great sacrifice which would bring Him infinite glory \-- the Sacrifice of the God-man Himself \-- and which would ensure the salvation of all men; but if the Father had delivered Him from death, the sacrifice would have been imperfect, and then the Father would have been deprived of that glory, while men would have been deprived of their salvation.

II\.

Tertullian writes that all the insults that were offered to Jesus Christ were a secret remedy for our pride; for these injuries, which were unjust, and undeserved, were nevertheless necessary for our salvation, and becoming a God Who chose to suffer so much to save man. And then, speaking of the reproaches laid against Jesus, he adds: \"Of Him they were unworthy, but to us they were necessary, and, for that reason, they were worthy of God, because nothing is so worthy of God as the salvation of man.\"

Let us, therefore, who glory in being disciples of Jesus Christ, be ashamed of angrily resenting the injuries we receive from men, because the God Who made us, suffered the same for our salvation with so much patience. And let us not be ashamed of imitating Jesus Christ in pardoning those who offend us, for He Himself declares, in the Day of Judgment He will be ashamed of those who in this life have been ashamed of Him.

O my Jesus, how can I grieve over any insults I may receive, who have so often deserved to be trodden under foot by the devils in hell! Oh, by the merit of all the insults which Thou didst suffer in Thy Passion, give me grace to suffer with patience all the insults which may be offered to me, through love of Thee, Who hast embraced so many for love of me. I love Thee above all things, and desire to suffer for Thee, Who hast suffered so much for me. I hope for everything from Thee, Who hast bought me with Thy Blood. And I also hope in thy intercession, O my Mother Mary.
