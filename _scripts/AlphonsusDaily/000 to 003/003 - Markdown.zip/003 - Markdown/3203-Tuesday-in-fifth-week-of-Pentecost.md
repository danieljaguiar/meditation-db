# Tuesday\--Fifth Week after Pentecost

## Morning Meditation

WE MUST BEFORE ALL THINGS SECURE THE SALVATION OF OUR SOULS.

Let us proceed at once with the work of our soul\'s salvation, for death is at hand. What we can do to-day let us not put off till to-morrow. Time passes and returns no more.

I.

Let us proceed at once with the work of our soul\'s salvation, for death is at hand. What we can do to-day let us not put off till to-morrow. Time passes and returns no more.

Every one says, at the hour of death: Oh, that I had been a saint! But of what avail will such regrets be when the oil fails, and the lamp will soon be extinguished?

We shall say when death comes: What would it have cost me to have avoided that occasion, to have borne with that person, to have broken off that correspondence, to have yielded that point of honour? But I did not do so and now what will become of me?

Let us not think that we can do too much to gain eternal salvation. \"No security can be too great,\" says St. Bernard, \"where Eternity is at stake.\"

To secure our salvation, we must be resolved to adopt the means. Inclination will not be sufficient; nor will it serve us to say, I will do it by and by. Hell is filled with souls who said: By and by! By and by! Death came in the meantime, and they were lost.

O Lord, help me! I will say to Thee, with St. Catherine of Genoa: \"My Jesus, no more sins, no more sins!\" I renounce all things to please Thee.

II\.

The Apostle says, *With fear and trembling work out your salvation* (Phil. 12). He who trembles at the thought of being lost, always recommends himself to God, avoids the occasions of sin, and will be saved.

To be saved we must use violence. Heaven is not given to indolent cowards. *The violent bear it away* (Matt. xi. 12).

O Lord, how many promises have I not made Thee! But my promises have all been treasons. I will never betray Thee more; help me, grant that I may die rather than offend Thee.

*Ask*, says our Lord, *and you shall receive.* (Jo. xvi. 24), by which He manifests to us His great desire that we should be saved. If any one should say to his friend: Ask of me what you please, he could say nothing more. Let us, then, ever pray to God, and we shall be enriched with graces, and secure of salvation.

My dear Jesus, cast Thine eyes on my miseries and have pity on me. I have been forgetful of Thee, but Thou hast not forgotten me. I love Thee, my Love, with all my soul; I detest all the offences I have committed against Thee above every evil. Pardon me, my God, and forget my many acts of ingratitude. And since Thou knowest my weakness, do not abandon me; enlighten me, and strengthen me to conquer all things to please Thee. Grant that I may forget all, that I may think only of Thy love and the mercies by which Thou hast so powerfully obliged me to love Thee. Mary, Mother of God, pray to Jesus for me.

## Spiritual Reading

III.\--THE ADVANTAGE OF A RETREAT MADE IN SOLITUDE AND SILENCE.

Jesus Christ, Who had no need of solitude to be recollected and united with God, in order to set us an example, often retired from intercourse with men and withdrew to mountains or into deserts to pray: *Having dismissed the multitude he went into a mountain alone to pray* (Matt. xiv. 23); and *He retired into the desert and prayed* (Luke v. 16). He also desired His disciples, after the fatigue of their missions, to retire to some solitary place to rest in spirit: *Come apart into a desert place and rest a little* (Mark vi. 31), declaring by this that the spirit, even amidst spiritual occupations, being obliged to treat with men, becomes somewhat relaxed, whence it is very necessary to renew it in solitude and retreat.

Worldlings, who are accustomed to divert themselves in conversations, at banquets and plays, imagine that in solitude, where no such things are found, one must suffer insupportable tediousness. This is indeed the case with those who have a conscience defiled by sin. As long as they are occupied in the affairs of this world they do not think of the things of the soul; but when they are disengaged and in solitude where they do not seek God, they feel all at once remorse of conscience, and thus they find nothing but tediousness and pain. But in the case of one who seeks God, he will find in solitude not tediousness, but contentment and joy. Of this the Wise Man assures us: *For her* (wisdom\'s) *conversation hath no bitterness, nor her company any tediousness, but joy and gladness* (Wis. viii. 16). Oh no, to converse with God causes no bitterness, no tediousness; no, nothing but peace and joy.

The Blessed Cardinal Bellarmine, during the season when the other Cardinals went to pass their holidays in country seats and villas, used to go to some quiet house to make the Exercises for a month, and these he called his holiday, and certainly his heart found more delight in them than others did in their pastimes.

St. Charles Borromeo made the Exercises every year and found in them his paradise on earth; and it was while he was one year engaged in these Exercises on Mount Varalle that his last illness and death came. Hence it is that St. Jerome says that solitude was his paradise on earth: \"Solitude is a paradise to me.\"

But, perhaps, some one will ask: What contentment can a person find, being alone and having no one with whom to converse? St. Bernard answers: \"He who seeks God is by no means alone in solitude, for God Himself is there with him, and renders him happier than if he had the company of the first princes of the world.\" \" I am never less alone,\" wrote the holy Abbot, \"than when alone.\" *Nunquam minus solus quam cum solus.*

The Prophet Isaias, describing the sweetness which God gives to those who seek Him in retreat, says: *The Lord therefore will comfort Sion, and will comfort all the ruins thereof; and he will make her desert as a place of pleasure, and her wilderness as a garden of the Lord. Joy and gladness shall be found therein, thanksgiving and the voice of praise* (Is. li. 3).

The Lord well knows how to comfort a soul that withdraws from the world. He compensates a thousandfold for the loss of all the pleasures of the world. He changes solitude into a garden of delights, where the tumult of the world being excluded, the soul thanks and praises God, and finds a very paradise of peace.

## Evening Meditation

THE PRACTICE OF THE LOVE OF JESUS CHRIST.

*\" Charity beareth all things.\"*

HE THAT LOVES JESUS CHRIST BEARS ALL THINGS FOR HIM, AND ESPECIALLY ILLNESS, POVERTY AND CONTEMPT.

I.

Oh, what abundance of merits may be accumulated by patiently enduring an illness! Almighty God revealed to Father Balthazar Alvarez the great glory He had in store for a certain nun who had borne a painful sickness with resignation; and told him that she had acquired greater merit in those eight months of her illness than some other Religious in many years. It is by the patient endurance of ill-health that we weave a great part, and perhaps the greater part, of the crown that God destines for us in Heaven. St. Lidwina had a revelation to this effect. After sustaining many and most cruel disorders, as we mentioned, she prayed to die a martyr for the love of Jesus Christ; now, as she was one day sighing after this martyrdom, she suddenly saw a beautiful crown, but as yet incomplete, and she understood that it was destined for herself; whereupon the Saint, longing to behold it completed, entreated the Lord to increase her sufferings. Her prayer was heard, for some soldiers came shortly after and ill-treated her, not only with injurious words, but with blows and outrages. An Angel then appeared to her with the crown completed, and informed her that those last injuries had added to it the gems that were wanting; and shortly afterwards she expired.

II\.

Ah, yes to the hearts that fervently love Jesus Christ, pains and ignominies are most delightful. And thus we see the holy Martyrs going with gladness to encounter the sharp prongs and hooks of iron, the plates of glowing steel and axes. The Martyr St. Procopius thus spoke to the tyant who tortured him: \"Torment me as you like; but know at the same time that nothing is sweeter to the lover of Jesus Christ than to suffer for His sake.\" St. Gordiano, Martyr, replied in the same way to the tyrant who threatened him with death: \"Thou threatenest me with death; but I am sorry that I can die only once for my own beloved Jesus.\" And I ask, did these Saints speak thus because they were insensible to pain or weak in intellect? No, replies St. Bernard; not insensibility, but love caused this: *Hoc non fecit stupor, sed amor*. They were not insensible, for they felt well enough the torments inflicted on them; but since they loved God, they esteemed it a great privilege to suffer for God, and to lose all, even life itself, for the love of God.
