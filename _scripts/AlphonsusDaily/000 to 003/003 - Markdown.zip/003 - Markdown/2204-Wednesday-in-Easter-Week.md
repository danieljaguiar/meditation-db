# Wednesday in Easter Week

## Morning Meditation

\"THOU SHALT LOVE THE LORD THY GOD WITH THY WHOLE HEART.\"

*For to this end Christ died and rose again, that he might be the Lord both of the dead and of the living.* (Rom. xiv. 9). The Saints, contemplating the death of Jesus Christ, thought it little to give their life and all things for the love of so loving a God. How many Martyrs have sacrificed their lives for Him! How many tender Virgins, renouncing the nuptials of the great, have gone with joy to death to make some return for the affection of a God Who died for their sake! And what have you done for Jesus\' sake?

I.

*But one thing is necessary.* (Luke x. 42). What is this one thing necessary? It is not necessary to acquire riches, nor to obtain dignities, nor to gain a great name. The only thing necessary is to love God. Whatever is not done for the love of God is lost. This is the greatest and the First Commandment of the Divine Law. To the Pharisee who asked which was the great Commandment of the Law, Jesus Christ answered: *Thou shalt love the Lord thy God with thy whole heart\... This is the greatest and first commandment.* (Matt. xxii. 37, 38). But this, the greatest of the commandments, is the most despised by men: there are few who fulfil it. The greater part of men love relatives, friends, and even brute animals, but do not love God. Of these St. John says that they have not life \-- that they are dead. *He that loveth not abideth in death* (1 Jo. iii. 14). St. Bernard says that the reward of a soul is estimated by the measure of her love for God.

Let us consider, then, how dear to us should be this command to love God with our whole heart. What object more noble, more magnificent, more powerful, more rich, more beautiful, more bountiful, more merciful, more grateful, more amiable, or more loving than Himself could God give us to love?

Who more *noble* than God? Some boast of a family nobility of five hundred or a thousand years; but the nobility of God our Father is eternal. He is the Lord of all. Before God all the Angels in Heaven, and all the nobles on earth are but as a drop of water or a grain of dust. *Behold the Gentiles are but as a drop of a bucket \-- behold the islands are as a little dust* (Is. xl. 15).

Who more *powerful* than God? He can do whatsoever He wills. By an act of His will He created this world, and by another act He can destroy it when He pleases.

Who more *wealthy*? He possesses all the riches of Heaven and earth.

Who more *beautiful*? Before the beauty of God all the beauties of creatures fade away.

Who more *bountiful*? St. Augustine says that God has a greater desire to do good to us than we have to receive it.

Who more *merciful*? If the most impious sinner on earth humble himself before God, and repent of his sins, God instantly pardons and embraces him.

Who more *grateful*? He does not leave unrewarded the smallest act we perform for His sake.

Who more *amiable*? God is so amiable that, by barely seeing and loving Him in Heaven, the Saints feel a joy which makes them perfectly happy and content for all eternity. The greatest of the torments of the damned arises from knowing that this God is so amiable, and that they cannot love Him.

O Infinite Goodness! O Infinite Love! My enamoured Jesus, fill my heart with Thy love so that I may forget myself, and think of nothing but of loving and pleasing Thee. I now consecrate to Thee my body, my soul, my will, my liberty. Till now I have sought to gratify myself to Thy great displeasure. I am exceedingly sorry, my crucified Love. I will henceforth seek nothing but Thee, my God and my All.

II\.

And who is more loving than God? In the Old Law men might doubt whether God loved them with a tender love; but, after seeing Him die on a Cross for us, how can we doubt the tenderness and the ardent affection with which He loves us? Let us raise our eyes and look at Jesus, the true Son of God, fastened with nails to a gibbet, and let us consider the intensity of the love which He bears us. That Cross, those Wounds, says St. Bernard, cry out, and proclaim to us that He truly loves us. And what more could He do to convince us of His great love than to lead a life of sorrow for thirty-three years, and afterwards die in torments on the infamous tree of the Cross, in order to wash away our sins with His own Blood? *Christ also hath loved us, and hath delivered himself up for us.* (Ephes. v. 2). *Who hath loved us, and washed us from our sins in his own blood.* (Apoc. i. 5). \"How,\" says St. Philip Neri, \"is it possible for him who believes in God to love anything but God?\" Contemplating God\'s love towards men, St. Mary Magdalene de Pazzi began one day to ring the bell, saying that she wished to invite all nations of the earth to love so loving a God. St. Francis de Sales used to say with tears: \"To love our God it would be necessary to have an infinite love; and we throw away our love on vain, contemptible things.\"

Alas, my Jesus, how many times have I renounced Thy friendship and made myself a slave of Satan, dishonouring Thy Infinite Majesty! I grieve above all things for having so grievously insulted Thee. Ah, my God, bind my will to Thy feet with the sweet cords of Thy holy love, that it may wish for nothing but what pleases Thee. May I take Thy Will as the sole guide of my life. I renounce everything. Thou alone art sufficient for me.

## Spiritual Reading

CONFESSION.

II.-EXAMINATION OF CONSCIENCE.

Every one knows that for a good Confession three things are necessary: an Examination of Conscience, Sorrow, and the Purpose to Avoid Sin.

As to the examination of conscience, for those that frequent the Sacraments, it is not necessary to distress the head by efforts to find out all the minute circumstances of venial sins. I would rather see such persons careful to discover the causes and roots of their attachments and tepidity. Some there are who have the same story to tell, and recite the same faults without sorrow, and without any thought of amendment.

For spiritual souls that go frequently to Confession, and guard against deliberate venial sins, it is not necessary to spend a long time in the examination of conscience. With regard to grievous sins, they need not scrutinize the conscience, for had they committed any mortal sin, they would know it without examination. With regard to venial sins, if they have been fully deliberate, they, too, by the remorse that they cause, would make themselves known to the soul. Besides, there is no obligation of confessing all our venial transgressions; consequently we are not obliged to make a strict search after them, and much less after the number, the circumstance, the manner, or the causes of them; it is enough to confess those that are most grievous, and most opposed to perfection, and to tell the rest in general terms. And when you have not certain matter for the Sacrament, tell some sin of your past life for which you have great sorrow; and say, for example: I accuse myself in a special manner of all the faults I have committed in my past life against Charity, Purity, or Obedience. How consoling is the doctrine of St. Francis de Sales on this point. \"Be not troubled,\" he says, if you do not remember all your little faults at Confession; for as you often fall imperceptibly, so you are often raised up imperceptibly,\" that is, by the acts of love, or by the other good acts that devout souls are accustomed to perform.

## Evening Meditation

THE PRACTICE OF THE LOVE OF JESUS CHRIST.

I.-HOW DESERVING JESUS CHRIST IS OF OUR LOVE ON ACCOUNT OF THE LOVE HE HAS SHOWN US IN HIS PASSION.

The whole sanctity and perfection of a soul consists in loving Jesus Christ our God, our sovereign Good, and our Redeemer. Whoever loves Me, says Jesus Christ Himself, shall be loved by My Eternal Father: *The Father himself loveth you, because you have loved me.* (John xvi. 27). Some, says St. Francis de Sales, make perfection consist in an austere life; others in prayer; in frequenting the Sacraments; others in alms-deeds. But they deceive themselves: perfection consists in loving God with our whole heart. The Apostle wrote: *Above all these things have charity, which is the bond of perfection.* (Col. iii. 14). It is charity which keeps united and preserves all the virtues that render a man perfect. Hence St. Augustine said: \"Love God, and do whatever you please\"; because a soul which loves God is taught by that same love never to do anything that will displease Him, and to leave nothing undone that may please Him.

But perhaps God does not deserve all our love? *I have loved thee with an everlasting love.* (Jer. xxxi. 3). O man, says the Lord, behold I was the first to love thee. Thou wast not yet in the world, nay, the world itself was not, and I already loved thee. As long as I am God, I love thee; as long as I have loved Myself, I have also loved thee. With good reason, therefore, did St. Agnes, that young holy virgin, reply to those who wished to unite her to an earthly spouse: \"I am engaged to another Lover.\" \"Go,\" said she, \"O lovers of this world, cease to ask my love; my God was the first to love me. He has loved me from all eternity: it is but just, then, for me to give Him all my affections, and to love none other but Him.\"

II\.

As Almighty God knew that man is won by kindness, He determined to lavish His gifts upon him, and so take captive the affections of his heart. For this reason He said: *I will draw them with the cords of Adam, with the bands of love* (Osee, xi. 4). I will catch men by those very snares by which they are naturally caught, that is, by the snares of love. And such exactly are all the favours of God to man. After having given him a soul created to His own image, with memory, understanding, and will, and a body with its senses, He created Heaven and earth for him; yes, all that exists, all for the love of man, the firmament, the stars, the planets, the seas, the rivers, the fountains, the hills, the plains, metals, fruits, and a countless variety of animals: and all these God made that they might minister to the uses of man, and that man might love Him in gratitude for so many admirable gifts. \"The heavens and the earth and all things tell me to love Thee,\" says St. Augustine. \"My Lord,\" he said, \"whatever I behold on the earth, or above the earth, all speak to me and exhort me to love Thee; because all assure me that Thou hast made them for the love of me.\" The Abbot de Rance, founder of La Trappe, when from his hermitage he stood and surveyed the hills, the fountains, the birds, the flowers, the planets, and the skies, felt himself animated by each one of these creatures to love that God Who had created all through love for him.
