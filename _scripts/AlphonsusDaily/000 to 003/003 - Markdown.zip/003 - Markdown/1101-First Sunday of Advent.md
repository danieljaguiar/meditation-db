# First Sunday of Advent

## Morning Meditation

*THE DAY OF THE LAST JUDGMENT*

*That day is a day of wrath \... a day of calamity and misery*. \-- Soph: i. 15.

On the Last Day will be verified the prediction of St. John: *And they say to the mountains and to the rocks: Fall upon us and hide us from the face of him that sitteth upon the throne and from the wrath of the Lamb.* (Apoc. vi., 16).

Send forth O Lord, the Lamb, the Ruler of the earth Who by sacrificing Himself shall satisfy Thy justice for us, and so reign in the hearts of men. O Lamb of God, pardon me before the arrival of that day on which Thou shalt judge me.

I.

The Last Day is called in Scripture *a day of wrath and misery*; and such it will be for all those unhappy beings who have died in mortal sin; for on that day their most secret crimes will be made manifest to the whole world, and themselves separated from the company of the Saints, and condemned to the eternal prison of hell, where they will suffer all the agonies of ever dying yet always remaining alive. St. Jerome, in the Cave at Bethlehem, devoted to continual prayer and penance, trembled at the bare thought of the General Judgement. The Ven. Father Juvenal Ancina, hearing that *Sequence for the Dead* sung, *Dies ire, dies illa*, was so struck with the anticipation of Judgment that he left the world and embraced the Religious life.

O Jesus! what will become of me on that day? Shall I be placed on Thy right hand with the Elect, or on Thy left with the reprobate? I know that I have deserved to be placed on Thy left, but I know also that Thou wilt still pardon me if I repent of my sins: therefore do I repent of them with my whole heart, and am resolved rather to die than offend Thee any more.

II\.

As this will be a day of calamity and terror for the reprobate, so will it be a day of joy and triumph for the Elect; for then, in the sight of all mankind, will the blessed souls of the Elect be proclaimed queens of Paradise and spouses of the Immaculate Lamb.

O Jesus! Thy precious Blood is my hope. Remember not the offences that I have committed against Thee, and inflame my whole soul with Thy love. I love Thee, my sovereign Good, and I trust that in that day I shall be associated with those loving souls who will praise and love Thee for all eternity.

Choose, my soul; choose now either an eternal crown in that blessed kingdom, where God will be seen and loved face to face in the company of the Saints, of the Angels, and of Mary, the Mother of Jesus; or the prison of hell, where you must weep and lament for ever, abandoned by God and by all.

\"O Lamb of God that takest away the sins of the world, have mercy on us!\" O divine Lamb, Who, to deliver us from the pains of hell, wast pleased to sacrifice Thy divine life by a bitter death upon the Cross, have compassion on us; but more particularly upon me who have more than others offended Thee. I am sorry above every evil for having dishonoured Thee by my sins, but I hope on that day to honour Thee before men and Angels, by proclaiming Thy mercies towards me. O Jesus! help me to love Thee; I desire Thee alone. O Mary, holy Queen! protect me on that day.

FIRST SUNDAY OF ADVENT

## Spiritual Reading\*

*THE NATIONS IN THE VALLEY OF JOSAPHAT*

St. Jerome spent his days in the Cave of Bethlehem in prayer and penance, and trembled at the thought of Jesus coming at the Last Day to judge the world.

At present God is not known and, therefore He is as much despised by sinners as if He could not avenge, whenever He pleases, the injuries offered to Him. The *wicked looketh upon the Almighty as if he could do nothing.* (Job, xxii., 17). But the Lord has fixed a day, called in the Scriptures, *the day of the Lord, Dies Domini*, on which the Eternal Judge will make known His power and majesty. *The Lord*, says the Psalmist, *shall be known when he exerciseth judgment*. (Ps. ix., 17). On this text St. Bernard writes: \"The Lord, Who is now unknown while He seeks mercy, shall be known when He executes justice.\" The Prophet Sophonias calls the Day of the Lord *a day of wrath \-- a day of tribulation and distress, a day of calamity and misery*. (Soph. i., 15).

This day shall commence with fire from the heavens which will burn the earth, all men then living, and all things upon the earth. *And the earth and the works which are in it shall be burnt up.* (2 Pet. iii., 10). All shall become one heap of ashes.

After the death of all men, *the trumpet shall sound, and the dead shall rise again.* (1 Cor. xv., 52). St. Jerome used to say: \"As often as I consider the Day of Judgment, I tremble. Whether I eat or drink, or whatever else I do, that terrible trumpet appears to sound in my ears, \'Arise ye dead, and come to judgment\'\"; and St. Augustine declared, that nothing banished earthly thoughts from him so effectually as the fear of the Judgment.

At the sound of that trumpet the souls of the Blessed shall descend from Heaven to be united to the bodies with which they served God on earth; and the unhappy souls of the damned shall come up from hell to take possession again of those same bodies with which they offended God. Oh! how different the appearance of the former, compared with that of the latter! The damned will appear deformed and black, like so many firebrands of hell; but *the just shall shine as the sun*. (Matt. xiii., 43). Oh! how great will then be the happiness of those who have mortified their bodies by works of penance! We may estimate their felicity from the words addressed by St. Peter of Alcantara, after death, to St. Teresa: \"O happy penance! which merited for me such glory!\"

After the Resurrection they shall be summoned by the Angels to appear in the Valley of Josaphat. *Nations, nations in the valley of destruction, for the day of the Lord is near*. (Joel, iii.,14). Then the Angels shall come and separate the reprobate from the Elect, placing the latter on the right, and the former on the left. *The Angels shall go out, and shall separate the wicked from among the just.* (Matt. xiii. 40). Oh! how great will then be the confusion which the unhappy damned shall suffer! This punishment alone, says St. Chrysostom, would be sufficient to constitute a hell for the wicked. Brother shall be separated from brother, husband from wife, son from father.

But, behold! the heavens are opened \-- the Angels come to assist at the General Judgment, carrying, as St. Thomas says, the Standard of the Cross and the other instruments of the Passion of the Redeemer. The same may be inferred from the Twenty-fourth Chapter of St. Matthew: *And then shall appear the sign of the Son of Man in heaven; and then shall all the tribes of the earth mourn.* (xxiv. 30). Sinners shall weep at the sight of the Cross; for, as St. Chrysostom says, the nails will complain of them \-- the Wounds and the Cross of Jesus Christ will speak against them.

Most holy Mary, the Queen of Saints and Angels, shall come to assist at the Last Judgment; and lastly, the Eternal Judge shall appear in the clouds, full of splendour and majesty. *And they shall see the Son of Man coming in the clouds of heaven with much power and majesty.* (Ib). Oh, how great shall be the agony of the reprobate at the sight of the Judge! *At their presence*, says the Prophet Joel, *the people shall be in grievous pains.* (Joel, ii). According to St. Jerome the presence of Jesus Christ will give the reprobate more pain than hell itself. \"It would,\" he says, \"be easier for the damned to bear the torments of hell than the presence of the Lord.\" Hence on that day, the wicked shall, according to St. John, call on the mountains to fall on them and to hide them from the sight of the Judge. *And they shall say to the mountains and the rocks: Fall upon us, and hide us from the face of him that sitteth on the throne, and from the wrath of the Lamb.* (Apoc. vi., 16).

\*The Spiritual Reading should, if possible, be read at some quiet, convenient time on the particular day for which it has been selected.

## Evening Meditation

*THE GOODNESS OF GOD IN THE WORK OF THE REDEMPTION*

I.

*And He was incarnate by the Holy Ghost \... and was made man.* \-- Nicene Creed.

Consider that God, having created the first man to serve Him and love Him in this life, and to be afterwards taken by Him to reign eternally with Him in Paradise, enriched him for this end with many lights and graces. But ungrateful man rebelled against God, refusing Him the obedience which he owed Him both in justice and gratitude; and thus he unhappily remained as a rebel, deprived, with all his posterity, of Divine grace, and for ever excluded from Paradise. Behold then, in consequence of this ruin caused by sin, all mankind lost! All were spiritually blind, living in the midst of darkness and the shadow of death.

But God, seeing men reduced to this so miserable a condition, was moved to pity and resolved to save them. And how did He save them? He did not send an Angel, or a Seraph; but to show to the world the immense love that He bore to these ungrateful worms, *He sent his own Son in the likeness of sinful flesh.* (Rom. viii., 3). Yes, He sent His own Son to become Man, and to clothe Himself with the same flesh as that of sinful men, in order that He, by His sufferings and death, might satisfy Divine justice for their crimes, and thus deliver them from eternal death, and reconciling them to His Divine Father, obtain for them Divine grace, and render them worthy to enter the eternal kingdom of Heaven.

But how is it, my Jesus, that after Thou hadst repaired this ruin of sin by Thy death, I have so often wilfully renewed it again by the many offences I have committed against Thee? Thou didst save me at so great a cost, and I have so often chosen to lose myself by losing Thee, O infinite Good! But Thy words give me confidence, for Thou hast said that when the sinner who has turned his back upon Thee is afterwards converted to Thee, Thou dost not refuse to embrace him: *Turn ye to me and I will turn to you.* (Zach. i., 3). And Thou hast likewise said: *If any man \... open to me the door, I will come in to him.* (Apoc. iii., 20). Behold, O Lord, I am one of these rebels, an ungrateful traitor, who have often turned my back upon Thee, and driven Thee from my soul; but now I repent with all my heart for having thus ill-treated Thee and despised Thy grace; I repent of it, and I love Thee above every thing. Behold, the door of my heart is now open, enter Thou in, but enter never to leave it again. I well know that Thou wilt never leave me, if I do not again drive Thee away; but this is my fear, and this is the grace which I ask of Thee, and which I hope always to ask: let me die rather than be guilty of this fresh and greater ingratitude.

II\.

Here pause to consider, on the one hand, the immense ruin that sin brings upon souls, since it deprives them of the friendship of God, and of Paradise, and condemns them to an eternity of torments. And consider, on the other hand, the infinite love which God showed in this great work of the Incarnation of the Word, causing this His only begotten Son to come and sacrifice His Divine life by the hands of executioners, in a sea of pain and infamy, to obtain for us pardon and eternal salvation. Oh, when we contemplate this great mystery and this excess of Divine love, each one of us should do nothing but exclaim: O infinite Goodness! O infinite Mercy! O infinite love! That a God should become Man and die for me!

My dearest Redeemer, I do not deserve to love Thee, after all the offences I have committed against Thee; but I ask of Thee through Thy merits, the gift of Thy holy love. Therefore, make me know the great good Thou art, the love Thou hast borne me, and how much Thou hast done to oblige me to love Thee. Ah, my God and my Saviour, let me no longer live ungrateful to Thy great goodness. My Jesus, I will never leave Thee again; I have offended Thee enough already. It is but right that I should spend the remaining years of my life in loving Thee and pleasing Thee. My Jesus, my Jesus, help me; help a sinner who desires to love Thee. O Mary my Mother, thou hast all power with Jesus, for thou art His Mother. Tell Him to pardon me; tell Him to enchain me with His holy love. Thou art my hope, in thee do I trust.
