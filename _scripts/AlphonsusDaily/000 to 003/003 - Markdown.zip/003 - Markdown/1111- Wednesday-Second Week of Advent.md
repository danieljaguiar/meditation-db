# Wednesday\--Second Week of Advent

## Morning Meditation

*CONSIDERATIONS ON THE RELIGIOUS STATE. III*

*Consider the account which he will have to render to Jesus Christ on the Day of Judgment who does not follow his Vocation.*

The grace of Vocation is a very rare grace which God grants only to a few. But the greater the grace, the greater will be the indignation of the Lord against him who does not correspond with it. He is the Lord. When He calls He wishes to be obeyed, and obeyed promptly.

I.

The grace of Vocation to the Religious state is not an ordinary grace; it is a very rare one, which God grants only to a few. *He hath not done so to every nation* (Ps. cxlvii. 20). Oh, how much greater is this grace, to be called to a perfect life, and to become one of the household of God, than if one were called to be the king of any kingdom on this earth! For what comparison can there be between a temporal kingdom on this earth and the eternal kingdom of Heaven?

But the greater the grace, the greater will be the indignation of the Lord against him who has not corresponded with it, and the more rigorous will be His judgment on the day of account. If a king were to call a poor shepherd to his royal palace, to serve him among the noblemen of his court, what would not be the indignation of the king were he to refuse such a favour through unwillingness to leave his poor little hut and his little flock? God knows well the value of His graces, and therefore He chastises with severity those who despise them. He is the Lord; when He calls He wishes to be obeyed, and obeyed promptly.

O Lord, Thou hast shown me such an excess of bounty as to choose me from among so many others, to serve Thee in Thy own House with Thy most beloved servants. I know how great is that grace, and how unworthy of it I have been. Behold, I am now willing to correspond to so great a love. I will obey Thee. Since Thou hast been so liberal towards me as to call me when I did not seek Thee, and when I was so ungrateful, permit not that I should offer Thee that greater excess of ingratitude as to embrace again my enemy, the world, in which heretofore I have so oftentimes forfeited Thy grace and my eternal salvation, and thus to forsake Thee, Who hast shed Thy Blood and given Thy life for my sake. Since Thou hast called me, give me also the strength to correspond to the call. Already have I promised to obey Thee. I promise it again, but without the grace of perseverance I cannot be faithful to Thee. This perseverance I ask from Thee, and through Thy own merits it is that I wish it and hope to obtain it.

II\.

When, therefore, by His inspiration, God calls a soul to a perfect life, if it does not correspond He deprives it of His light, and abandons it to its own darkness. Oh, how many poor souls shall we see among the reprobate on the Day of Judgment for this very reason, that they were called and would not correspond!

Give thanks, then, to the Lord, Who has invited you to follow Him; but if you do not correspond, tremble! Since God calls you to serve near His Person, it is a sign that He wishes to save you. But He will have you to be saved in that path only which He indicates to you and has chosen for you. If you wish to save yourself on a road of your own choosing, there is great danger that you will not be saved at all; for if you remain in the world, when God wishes you to be a Religious, He will not give you those efficacious helps prepared for you had you lived in His House, and without those you will not save yourself. *My sheep hear my voice* (Jo. x. 27). He who will not obey the voice of God shows that he is not, and will not be, one of His sheep, but in the Valley of Josaphat, he will be condemned with the goats.

Give me courage, O my Jesus, to vanquish the passions of the flesh, through which the devil seeks to induce me to betray Thee. I love Thee, O my Jesus! To Thee I consecrate myself entirely. I am already Thine, I will be always Thine. O Mary, my Mother and my hope, thou art the Mother of perseverance. This grace is only dispensed through thy hands; do thou obtain it for me. In thee do I confide.

## Spiritual Reading

*COUNSELS CONCERNING A RELIGIOUS VOCATION*

III\. THE MEANS TO BE EMPLOYED FOR PRESERVING A RELIGIOUS VOCATION

He, then, who wishes to be faithful to the Divine call, ought not only to resolve to follow it, but to follow it promptly, as soon as ever he can, if he does not wish to expose himself to the evident danger of losing his Vocation. Should he, of necessity, be forced to wait, he ought to use all diligence to preserve it, as the most precious jewel he could possess.

The means to preserve one\'s Vocation are three in number:

1\. *Secrecy;*\
2. *Prayer;*\
3. *Recollection.*

*A. Secrecy*

Generally speaking, he must keep his Vocation secret from everybody except his spiritual Father, because, commonly, people of the world scruple not to say to young people who are called to the Religious state, that one may serve God *anywhere*, and therefore *in the world* also. And the wonder is that such propositions come sometimes out of the mouths of priests, and even of Religious, but of such only who have become Religious without a Vocation, or do not know what Vocation means. Most certainly he who is not called to the Religious state may serve God in every place, but not so he who is called to Religion, and then from his own inclination wishes to remain in the world; such a one, as I have said before, can with difficulty lead a good life, and serve God.

It is especially necessary not to speak about Vocation to parents.

It was, indeed, the opinion of Luther, as Bellarmine relates, that children entering Religion without the consent of their parents commit a sin. For, said he, children are bound to obey their parents in all things. But this opinion has generally been rejected by Councils and the Holy Fathers. The Tenth Council of Toledo expressly declares that it is lawful for children to become Religious without the consent of their parents, provided they have attained the age of fourteen years. Here are the words of the Council: \"It shall not be lawful for parents to put their children in a Religious Order after they have attained their fourteenth year. After this age, it shall be lawful for children to take upon themselves the yoke of Religious observance, whether it be with the consent of their parents, or only the wish of their own hearts.\" The same is taught by St. Ambrose, St. Jerome, St. Augustine, St. Bernard, St. Thomas, and others, with St. John Chrysostom who writes: \"When parents stand in the way of spiritual good, they ought not even to be recognised.\"

Some Doctors hold that when a child called by God to the Religious state can easily and securely obtain the consent of his parents, without any danger of their hindering him from following his Vocation, it is becoming that he should seek their blessing. This doctrine may be held speculatively, but not in practice, because in practice such a danger always exists. Hence it is well to discuss this point fully, in order to do away with the pharisaical scruples which some entertain.

It is certain that in the choice of a state of life, children are not bound to obey their parents. This is the common teaching of Doctors, with St. Thomas, who says: \"Servants are not bound to obey their masters, or children their parents, with regard to contracting matrimony, preserving virginity, and such like things.\" Nevertheless, with regard to the state of marriage, Father Pinamonti, in his Treatise on *Religious Vocation*, rightly holds the opinion of Sanchez, Comminchio, and others, who teach that a child is bound to take counsel of his parents, because in such matters they have more experience than the young, and generally do their duty. But, speaking of Religious Vocation, he adds that a child is not bound at all to take counsel of his parents, because in this matter they have no experience, and through interest, are commonly changed into enemies, as St. Thomas also remarks when speaking of Religious Vocation. \"Frequently,\" he says \"our friends according to the flesh are opposed to our spiritual good.\" For fathers often prefer that their children should be damned with them rather than be saved away from them. Hence, St. Bernard exclaims: \"O hard father, O cruel mother, whose consolation is the death of their son; who wish rather that I perish with them than reign without them!\"

God, says a grave author, Porrecta, when He calls a person to a perfect life wishes him to forget his father, saying: *Hearken, O daughter, and see, and incline thine ear; and forget thy people and thy father\'s house* (Ps. xliv. 11). By this, then, he adds, the Lord certainly admonishes us that he who is called ought by no means to allow the counsel of parents to intervene. \"If God will have a soul, who is called by Him, to forget his father and his father\'s house, without doubt He suggests by this, that he who is called to the Religious state ought not, before he follows the call, to interpose the counsel of the carnal friends of his household.\"

St. Cyril, commenting on what Jesus Christ said to the youth mentioned above: *No man putting his hand to the plough and looking back is fit for the kingdom of God* (Luke ix. 61), says that he who asks for time to confer with his parents in reference to his Vocation is exactly the one who is declared by our Lord to be unfit for Heaven. \"He looks back who seeks for delay that he may be able to confer with his parents.\" Hence, St. Thomas absolutely advises those who are called to Religion, to abstain from deliberating on their Vocation with their relatives: \"From this deliberation, the relatives of the flesh are before all to be excluded; for it is said: *Treat thy cause with thy friend* (Prov. xxv. 9). Now our relatives are in this affair not our friends, but our enemies, according to the saying of our Lord: *A man\'s enemies are they of his own household* (Matt. x. 36).\"

## Evening Meditation

*GRANDEUR OF THE MYSTERY OF THE INCARNATION*

I.

*And the Word was made flesh* (St. John i. 14).

Our Lord sent St. Augustine to write upon the heart of St. Mary Magdalen de Pazzi the words, *And the Word was made flesh.* Oh, let us also pray the Lord to enlighten our minds, and to make us understand what an excess and what a miracle of love this is: that the Eternal Word, the Son of God, should have become Man for the love of us.

The Holy Church is struck with awe at the contemplation of this great Mystery: *I considered thy works and was afraid.* If God had created a thousand other worlds, a thousand times greater and more beautiful than the present, it is certain that this work would be infinitely less grand than the Incarnation of the Word: *He hath showed might in his arm* (Luke i. 51). To execute the great work of the Incarnation, it required all the omnipotence and infinite wisdom of God, in order to unite human nature to a Divine Person, and that a Divine Person should so humble Himself as to take upon Himself human nature. Thus God became Man, and Man became God; and hence, the Divinity of the Word being united to the soul and body of Jesus Christ, all the actions of this Man-God became divine: His prayers were divine, His sufferings divine, His infant cries divine, His tears divine, His steps divine, His members divine, His very Blood divine, which became, as it were, a fountain of health to wash out all our sins, and a Sacrifice of infinite value to appease the justice of the Father, Who was justly angered with men.

O Soul, O Body, O Blood of my Jesus! I adore you and thank you; you are my hope; you are the price paid to save me from hell, which I have so often merited. O my God! What a miserable and hopeless life would await me in eternity, if Thou, my Redeemer, hadst not thought of saving me by Thy sufferings and death! But how is it that souls, redeemed by Thee with so much love, knowing all this, can live without loving Thee, and can despise the grace which Thou hast acquired for them with so much suffering? And did not I also know all this? How, then, could I have offended Thee, and offend Thee so often? But, I repeat it, Thy Blood is my hope. I acknowledge, my Saviour, the great injuries that I have done Thee. Oh that I had rather died a thousand times! Oh, that I had always loved Thee!

II\.

And who, then, are these men? Miserable, ungrateful, and rebellious creatures! And yet for these God becomes Man; subjects Himself to human miseries; suffers and dies to save these unworthy sinners; *He humbled himself, becoming obedient unto death, even to the death of the cross* (Phil. ii. 8). O holy Faith! If Faith did not assure us of it, who would believe that a God of infinite majesty should abase Himself so far as to become a worm like us, in order to save us at the cost of so much suffering and disgrace, and of so cruel and shameful a death?

\"O grace! O power of love!\" cries out St. Bernard. O grace, which men could not even have imagined, if God Himself had not thought of granting it to us! O mercy! O infinite charity, worthy only of an infinite Bounty!

By Thy grace I now feel great sorrow for the offences I have committed against Thee; I feel within me an ardent desire of loving Thee; I feel fully resolved to lose everything rather than Thy friendship; I feel a love towards Thee that makes me abhor everything that displeases Thee. And this sorrow, this desire, this resolution, and this love, who is it that gives them to me? It is Thou, O Lord, in Thy great mercy. Therefore, my Jesus, this is a proof that Thou hast pardoned me; it is a proof that now Thou lovest me, and that Thou willest me at all costs to be saved; Thou willest that I should be saved, and I will save myself principally to give Thee pleasure. Thou lovest me, and I also love Thee; but my love is little indeed. Oh, give me more love; Thou deservest more love from me, for I have received from Thee more special favours than others: I pray Thee do Thou increase the flames of my love.

Most holy Mary, obtain for me that the love of Jesus may consume and destroy in me every affection that has not God for its object. Thou dost listen to the prayers of all that call on thee; listen to me also and obtain for me love and perseverance.
