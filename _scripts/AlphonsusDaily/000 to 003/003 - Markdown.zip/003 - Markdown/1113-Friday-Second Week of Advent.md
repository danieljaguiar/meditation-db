# Friday\--Second Week of Advent

## Morning Meditation

*CONSIDERATIONS ON THE RELIGIOUS STATE. V.*

*Consider the immense glory that Religious will enjoy in Heaven.*

*He will render to everyone according to his works* (Matt. xvi. 27).

From this you can judge how exceeding great will be the reward that God will give in Heaven to good Religious on account of the great merits they acquire every day. *Going, they went and wept casting their seeds; but coming, they shall come with joyfulness, carrying their sheaves* (Ps. cxxv. 6, 7).

I.

Consider, in the first place, what St. Bernard says: that it is difficult for Religious who die in the Religious state to be damned. \"From the cell to heaven the way is easy. One scarcely ever descends from the cell into hell.\" The reason the Saint adduces is: \"because one scarcely ever perseveres in it until death unless he be predestinated.\" For it is with difficulty a Religious perseveres until death, if he be not of the number of the Elect of Paradise. Therefore, St. Laurence Justinian called the Religious state the gate of Paradise: \"Of that heavenly city this is the gate.\" And he said that, therefore, \"Religious have a great sign of predestination.\"

Consider, moreover, that the reward of Heaven, as the Apostle says, is *a crown of justice* (2 Tim. iv. 8). Wherefore, God, though He rewards us for our works more abundantly than we deserve, rewards us nevertheless in proportion to the works we have done. *He will render to everyone according to his works*. From this you can judge how exceedingly great will be the reward which God will give in Heaven to good Religious, in consideration of the great merits they daily acquire.

The Religious gives to God all his earthly goods and is content to be entirely poor, without possessing anything. The Religious renounces all attachment to his parents, friends, and country, in order to unite himself more closely to God. The Religious continually mortifies himself in many things which he would enjoy in the world. The Religious, finally, gives to God his whole self, by giving him his will through the Vow of Obedience.

The dearest thing that we have to give is our own will, and what God, of all other things, requires of us most is the heart, that is to say, the will. *My son, give me thy heart*. He who serves God *in the world* will give Him his possessions, but not himself; he will give Him a part and not the whole, for he will give Him indeed his goods by alms-deeds, his food by fasting, his blood by disciplines, etc. But he will always reserve for himself his own will, fasting when he pleases, praying when he likes. But the Religious, giving Him his own will, gives himself and gives all; gives not only the fruits of the tree, but the whole tree itself. Whence he may then truly say to Him: O Lord! having given Thee my will, I have nothing more to give Thee.

Is it possible, O my God and my true Lover! that Thou so much desirest my good, and to be loved by me, and that I, miserable that I am, desire so little to love and to please Thee? For what end hast Thou favoured me with so many graces, and taken me out of the *world?* O my Jesus! I understand Thee. Thou lovest me much, Thou wilt have me love Thee much, and be all Thine, in this life and in the next. Thou wishest that my love should not be divided with creatures, but wilt have it be wholly for Thyself, the only Good, the only lovely One, and worthy of infinite love. Ah! my Lord, my Treasure, my Love, my All! Yes, I pant and truly desire to love Thee, and to love no other but Thee.

II\.

And, therefore, in all that the Religious does through Obedience, he is sure to do the will of God perfectly, and merits by all he does, not only when he prays, when he hears confessions, when he preaches or fasts, or practises other mortifications, but also when he takes his food; when he sweeps his room, when he makes his bed, when he takes his rest, when he recreates himself; for, doing all this through Obedience, in all he does the will of God. St. Mary Magdalen de Pazzi said that everything done through Obedience is a prayer. Hence, St. Anselm, speaking of those who love Obedience, asserted that all that Religious do is meritorious for them. St. Aloysius Gonzaga said that in Religion one travels, as it were, in a vessel in which even he who does not labour advances.

Oh, how much more will a Religious gain in one month by observing his Rule than a secular, with all his penance and prayers, in a year! Of that disciple of Dorotheus called Dositheus, it was revealed that for the five years he had lived under Obedience, there was given to him in Heaven the glory of St. Paul the Hermit, and of St. Anthony the Abbot, both of whom had, for so many years, lived in the desert. Religious, it is true, have to suffer the inconvenience of regular observance: *Going, they went and wept*. But when they are called to the other life they will go to Heaven, *and \... with joyfulness, carrying their sheaves* (Ps. cxxv. 6, 7). Whence they will sing: *The lines are fallen unto me in goodly places, for my inheritance is goodly to me* (Ps. xv. 6). These bonds which have bound me to the Lord have become for me exceedingly precious, and the glory they have acquired for me is exceedingly great.

I thank Thee, Jesus, for this desire Thou hast given me; preserve it in me, always increase it in me, and grant that I may please Thee, and love Thee on this earth as Thou desirest, so that I may come hereafter to love Thee face to face, with all my strength in Paradise. Behold, this is all that I ask from Thee. Thee will I love, O my God! I will love Thee; and for Thy love I offer myself to suffer every pain. I will become a Saint, not that I may enjoy great delight in Heaven, but to please Thee much, O my beloved Lord! and to love Thee much forever. Graciously hear me, O Eternal Father for the love of Jesus Christ.

My Mother Mary, for the love of this thy Son, help thou me. Thou art my hope; from thee I hope for every good.

## Spiritual Reading

*COUNSELS CONCERNING A RELIGIOUS VOCATION*

V. THE MEANS TO BE EMPLOYED FOR PRESERVING A RELIGIOUS VOCATION

*B. Prayer*

In the second place, it is necessary to remember that these Vocations are only preserved by prayer; he who gives up prayer will certainly lose his Vocation. It is necessary to pray, and to pray much; and, therefore, let him who feels himself called, not omit to make every morning after rising, an hour\'s Meditation, or at least one for half an hour, in his own room, if he can do so without molestation, and, if not, in the church; and likewise for half an hour in the evening.

Let him not omit also to make every day a Visit to the Most Holy Sacrament, and to the Most Blessed Virgin Mary, in order to obtain the grace of perseverance in his Vocation, and let him not omit to receive Holy Communion three times, or at least, twice a week.

His Meditations ought almost always to be on his Vocation, considering how great a favour he has received from God, in being thus called by Him; how much more easily he will secure his eternal salvation, if he be faithful in following it; and on the contrary, to how great a danger of being lost he exposes himself, if he be unfaithful. Let him then especially keep before his eyes the hour of death, and consider the contentment that he will then feel if he shall have obeyed God, and the pains and the remorse he will experience if he should die in the world. To this end I shall add some *Considerations* on which he may make his Meditation.\*

It is, moreover, necessary that all his prayers to Jesus and Mary, and especially those after Communion and in the Visits, be directed to obtain perseverance. In these prayers and Communions let him always renew the offering of himself to God, saying: \"Behold, O Lord! I am no longer mine own. I am Thine. Already have I given myself to Thee, and now I renew this my offering of my whole self. Accept of me and give me strength to be faithful to Thee and to retire as quickly as possible into Thy House.\"

\*These are the *Considerations* that commenced on the Second Monday of Advent, and are being given as Morning Meditations.

*C. Recollection*

In the third place, it is necessary to be recollected. This will not be possible unless he withdraws from worldly reunions and secular amusements. And, indeed, as long as we are in the world, what suffices to cause the loss of Vocation? A mere nothing. One day of dissipation, a word from a friend, a passion not mortified, a little attachment, some groundless fear, some slothfulness not overcome \-- any one of these suffices to bring to nought all one\'s good resolutions of retiring from the world, and of giving oneself entirely to God. Wherefore, he who is called to Religion ought to keep perfectly recollected, detaching himself from everything of this world. His occupation while waiting should be prayer and frequenting the Sacraments; and he should pass his time at home or in church. Let him who will not act thus, but who distracts himself by pastimes, be persuaded that he will undoubtedly lose his Vocation. He will, indeed, feel remorse for not following his Vocation, but he certainly will *not* follow it. Oh, how many by neglecting these precautions have lost their Vocation, and afterwards their souls!

*A PRAYER FOR PERSEVERANCE*\
*(To be said often and fervently)*

My Lord Jesus Christ, Who didst choose for Thyself the most bitter death of the Cross that I might die a happy death \-- ah, since Thou hast so loved me as to call me out of the world to follow in Thy footsteps and be thus always united to Thy loving Heart, bind me, I beseech Thee, dear Jesus, with the sweet chain of Thy love wholly to Thyself that I may never more be separated from Thee. O my beloved Redeemer, I do desire to be grateful, and faithful to Thy grace and to my Vocation, but I fear lest, through my own weakness, I should be faithless. My Jesus, do not allow that it should be so. No! Let me die rather than that I should ever abandon Thee. May I never forget the special love which Thou hast shown me. I love Thee, my dear Saviour. Thou art now and wilt ever be the only Master of my heart and soul. I quit all and choose Thee alone for my only Treasure.

Go, creatures \-- go far away! My God is my only Good. He is my Love. He is my All! My Jesus, I love Thee, and in loving Thee I wish to spend my whole life, be it long or short. I embrace Thee. I clasp Thee to my heart. In Thy loving arms I wish to die. This grace I ask for, and I care for nothing else.

Make me live always burning with Thy love, and when my end shall have at length come, let me give forth my last breath in an ardent act of love to Thee. O Mary Immaculate, do thou obtain for me this grace. My hope is in thy powerful intercession. Help me to forsake the world. Come to my rescue now. Succour me and obtain for me the grace to overcome myself and to become a Saint. Amen.

## Evening Meditation

*JESUS WISHED TO SUFFER SO MUCH IN ORDER TO GAIN OUR HEARTS.*

I.

*I have a baptism wherewith I am to be baptised and how am I straitened until it be accomplished?* (Luke xii. 50).

Consider how Jesus suffered even from the first moment of His life, and all for love of us. During the whole of His life He had no other interest, after the glory of God, than our salvation. He, as the Son of God, had no need to suffer in order to deserve Paradise; but whatever He suffered of pain, of poverty, of ignominy, He applied it all towards meriting for us eternal salvation. And even though He could have saved us without suffering, yet He chose to embrace a life of nothing but sufferings, poor, despised, and deprived of every comfort, with a death the most desolate and bitter that was ever endured by any Martyr or penitent, only to make us understand the greatness of the love He bore us, and to gain our affections.

He lived thirty-three years, and He lived sighing for the hour in which He was to sacrifice His life, which He desired to offer up to obtain for us divine grace and eternal glory, in order that He might have us with Him forever in Paradise.

My beloved Redeemer, I am also one of those ungrateful wretches who have repaid Thy immense love, Thy sorrows, and Thy death, with offences and contempt. O my dearest Jesus! how is it possible that, seeing as Thou didst the ingratitude that I should show Thee for all Thy mercies, Thou couldst yet love me so much, and resolve to endure so much contempt and suffering for me! But I will not despair. The evil is already done. Give me, therefore, O my Saviour, that sorrow which Thou hast merited for me by Thy tears; but let it be a sorrow equal to my iniquities. O loving Heart of my Saviour, once so afflicted and desolate for my sake, and now all burning with love for me, I beseech Thee change my heart, give me a heart that will make reparation for the offences I have committed against Thee \-- a love that will equal my ingratitude!

II\.

It was this desire which made Jesus say: *I have a baptism wherewith I am to be baptised; and how am I straitened until it be accomplished?* He desired to be baptised with His own Blood, not to wash out His own sins, since He was innocent and holy, but the sins of men whom He loved so much: *He loved us, and washed us in his own blood* (Apoc. i. 5). Oh, excess of the love of God, which all the men and Angels that ever existed will never succeed in understanding or praising as it deserves.

St. Bonaventure weeps at seeing the great ingratitude of men for so great a love: \"It is a cause for wonder that the hearts of men do not break for love of Thee.\" It is a marvel, says the Saint, to see a God endure such sufferings, shedding tears in a stable, poor in a workshop, languishing on a Cross; in short afflicted and tormented; the whole of His life for the love of men; and then to see these men, who not only do not burn with love towards such a loving God, but even have the boldness to despise His love and His grace. O Lord, how is it possible to conceive that a God should have given Himself up to so much suffering for men, and yet that there should be men who can offend, and not love this merciful God!

I give Thee thanks, my Saviour, because I see that Thy mercy has already changed my heart. I hate, above every evil, the insults I have offered Thee; I detest them, I abhor them. I now esteem Thy friendship above all the riches and kingdoms of the world. I desire to please Thee as much as it is possible for me; I love Thee, Who art infinitely amiable; but I see that my love is too feeble. Do Thou increase the flame, give me more love. Thy love for me ought to be responded to by a greater degreee of love in me, who have so much offended Thee, and who, instead of chastisement, have received so many special favours from Thee. O Sovereign Good, permit me not to be any longer ungrateful for all the favours Thou hast bestowed upon me. I will say with St. Francis: \"May I die, Lord, for the love of Thy love, Who for the love of my love didst deign to die!\" Mary, my hope, help me; pray to Jesus for me!
