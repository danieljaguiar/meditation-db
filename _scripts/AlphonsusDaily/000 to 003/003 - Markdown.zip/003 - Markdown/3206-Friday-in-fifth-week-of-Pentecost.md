# Friday\--Fifth Week after Pentecost

## Morning Meditation

THE VANITY OF THE WORLD.\--DEATH SHOWS US THE VANITY OF THE WORLD.

St. John Chrysostom says: \"Go to the tomb, and contemplate the dust and worms and\--sigh!\" O the great secret of death! Things the most desirable on this earth lose all their splendour when viewed from the bed of death.

O the great secret of death! How it brings to an end all worldly desires! How it shows all worldly grandeur as smoke and deceit! Things the most desired of this earth lose all their splendour when beheld from the bed of death. The shadow of death obscures the beauty of all things here below.

Of what profit are riches when nothing remains but a winding-sheet? Of what advantage bodily beauty, when all is reduced to a heap of worms? Of what avail is authority, when nothing remains but to be thrown into the grave, and be forgotten by all?

St. Chrysostom says: \"Go to a sepulchre, contemplate dust and worms\--and sigh!\" Look on the graves of the dead; see those skeletons gnawed by worms and crumbling into dust, and say, with a sigh: Ah, such must I become, and why do I not think of this? Why do I not give myself to God? Alas! who knows but that which I am now reading may be the last call for me?

O my dear Redeemer, I accept of my death, and I accept of it in whatever way it may please Thee to send it to me; but I beseech Thee, before Thou judgest me, to allow me time to bewail the offences I have committed against Thee. I love Thee, O my Jesus, and I am truly sorry for having despised Thee.

O my God, how many miserable beings, to obtain worldly goods, pleasures, vanities, have lost their souls, and, by losing their souls, have lost all!

Do we believe or not that we must one day die? And that only once? And why do we not leave all, to secure a happy death? Let us leave all, to secure all.

Is it possible we realize that the remembrance of a disorderly life will at the hour of death be an insufferable torment, and still continue to live on in sin?

O my God, I thank Thee for the light Thou affordest me. But, O Lord, what have I done? Have I multiplied my sins and hast Thou increased Thy graces? Woe to me, if I do not avail myself of them!

II\.

He who reflects that in a short time he must leave the world will not be attached to it.

Oh, with what peace of soul do those live and die who, despoiled of all things, are contented to say, *My God and my all!*

Solomon said that all the goods of this earth are only vanity and affliction of spirit; since the more one possesses of the goods of this world, the more he suffers.

St. Philip Neri used to call those fools whose hearts are attached to this world. Fools, because even here they lead miserable lives.

O my God, what now remains of the many sinful deeds of which I have been guilty, but the pain and remorse that torment me, and will torment me still more at the hour of death? Oh, do Thou, O Lord, make haste to pardon me! Thou desirest that I should be all Thine, and such do I desire to be. Behold, from this moment, I give myself to Thee, and I desire nothing in return but Thyself.

Let us not imagine that to be detached from all things, in order to love God alone, is to live an unhappy life. Who on this earth is so contented and happy as the man who loves Jesus Christ with his whole heart? Find me one amongst all the kings of the world, who is more happy than the man who gives himself entirely to God.

My soul, if now thou wert to depart out of this world, wouldst thou die satisfied with thy past life? And for what dost thou delay? Is it that the light which God in His mercy now affords thee may only serve to reproach thee at the great accounting day?

O Jesus, I renounce all to give myself to Thee. Thou didst seek me when I fled from Thee; and now that I seek Thee, do not reject me. Thou didst love me when I did not love Thee, nor even desire that Thou shouldst love me; and now that I have no other desire but to love Thee, and to be loved by Thee, cast me not away from Thy face. O my God, I am now convinced that Thou desirest to save me, and I desire to work out my salvation to please Thee. I leave all, and give my whole self to Thee. Mary, Mother of God, pray to Jesus for me.

## Spiritual Reading

VI.\--THE ADVANTAGE OF A RETREAT MADE IN SOLITUDE AND SILENCE.

I could add a thousand other examples, but I shall relate only one more\--the case of a nun in the Convent of Torre di Specchi in Rome. She pretended to be a learned woman, but led a very imperfect life. When the Spiritual Exercises were being conducted in the convent she began them, but very much against her will. The very first meditation on the \" End of Man\" made such an impression on her that, weeping, she went to the Spiritual Father, and said: \"Father, I wish to become a saint without delay.\" She wanted to say more, but sobs prevented her. Returning to her cell she wrote out a consecration of her entire self to Jesus Christ, and gave herself up to penance and retirement, and persevered until death.

If we had no other motive for attaching so much importance to the Spiritual Exercises, it would be enough to consider the esteem so many saintly men had for them. St. Charles Borromeo began to lead a perfect life after the first Retreat in Rome. St. Francis de Sales attributed to the Spiritual Exercises the first beginnings of a holy life. Louis of Granada, a man of very great virtue, used to say that a lifetime would not suffice to explain the knowledge of Divine things which he discovered in going through the Spiritual Exercises. Blessed John of Avila called the Exercises a school of heavenly wisdom, and exhorted all his spiritual children to make them. Father Louis Blosius, the holy Benedictine, used to say we should give God special thanks for having in these latter times made known to His Church the precious treasure of the Spiritual Exercises of a Retreat.

But if the Exercises are of great help to persons in every state and condition, they are of special help to him who wishes to make a proper choice of a state of life. For I find it laid down that the first end for which the Exercises were instituted was that of making the choice of a state of life, because upon this choice depends the eternal salvation of each one. We cannot expect that an Angel from Heaven should come to assure us of the state which, according to the will of God, we should choose. It is sufficient to put before us the state we are thinking of choosing, and then to consider the end we have in view in that choice, and weigh all the circumstances.

This is the principal reason for which I wish you to make the Exercises in silence; namely, for making the choice of the state of life.

## Evening Meditation

THE PRACTICE OF THE LOVE OF JESUS CHRIST

*\"Charity beareth all things.\"*

HE THAT LOVES JESUS CHRIST BEARS ALL THINGS FOR HIM, AND ESPECIALLY ILLNESS, POVERTY AND CONTEMPT.

I.

This love of poverty should be especially practised by Religious who have made the Vow of Poverty. \"Many Religious,\" says the great St. Bernard, \"wish to be poor; but on the condition of wanting for nothing.\" \"Thus, says St. Francis of Sales, \"they wish for the honour of poverty, but not the inconveniences of poverty.\" To such persons is applicable the saying of the blessed Solomea, a nun of St. Clare: \"That Religious will be a laughing stock to Angels and to men, who pretends to be poor, and yet murmurs when in want of anything.\" Good Religious act differently; they love their poverty above all riches. The daughter of the Emperor Maximilian II, a discalced nun of St. Clare, called Sister Margaret of the Cross, appeared on one occasion before her brother, the Archduke Albert, in a patched habit. He evinced some astonishment at it, as if it were unbecoming her noble birth; but she made him this answer: \"My brother, I am more content with this torn garment than all monarchs with their purple robes.\" St. Mary Magdalen de Pazzi said: \"O happy Religious, who, detached from all by means of holy poverty, can say: \'The Lord is the portion of my inheritance!\'\" My God, Thou art my portion and all my good! St. Teresa, having received a large alms from a certain merchant, sent him word that his name was written in the Book of Life; and that, in token of this, he should lose all his possessions; and the merchant actually failed, and remained in poverty till death. St. Aloysius Gonzaga said that there could be no surer sign of a person\'s being numbered among the elect than to see him fearing God, and at the same time undergoing crosses and tribulations in this life.

II\.

The bereavement of relations and friends by death belongs also, in some measure, to holy poverty; and in this we must especially practise patience. Some people, at the loss of a parent or friend, can find no rest; they shut themselves up to weep in their chamber, and giving free vent to their sorrow, become insupportable to all around them by their want of patience. I would ask these persons for whose gratification, or for whose sake, do they thus lament and shed tears? Is it for God\'s? Certainly not; for God\'s will is that they should be resigned to His dispensations. For that of the soul departed? By no means: if the soul be lost, she abhors both you and your tears; if she be saved, and already in Heaven she would have you thank God on her part; if still in Purgatory, she craves the help of your prayers, and wishes you to bow with resignation to the Divine will, and to become a saint, in order that she may one day enjoy your society in Paradise. Of what use, then, is all this weeping? On one occasion the Venerable Father Joseph Caracciolo, the Theatine, was surrounded by his relations, who were all bitterly lamenting the death of his brother, whereupon he said to them: \"Come! come! let us keep these tears for a better purpose, to weep over the death of Jesus Christ, Who has been to us a Father, a Brother, a Spouse, and Who died for love of us.\" On such occasions we must imitate Job, who, on hearing the news of the death of his sons, exclaimed, with full resignation to the Divine will: *The Lord gave, and the Lord hath taken away;* God gave me my sons, and God hath taken them away. *As it hath pleased the Lord, so is it done: blessed be the name of the Lord!* It hath pleased God that such things should happen, and so it pleaseth me; wherefore may He be blessed by me for ever (Job i. 21).
