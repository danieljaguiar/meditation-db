# Wednesday\--First Week of Advent

## Morning Meditation

*THE GREAT THOUGHT OF ETERNITY*

*Man shall go into the house of his eternity.* (Eccles. xii, 5).

He who builds a house for himself takes great pains to make it commodious, airy and handsome, and says: \"I labour and give myself a great deal of trouble about this house, because I shall have to live in it all my life.\" And yet how little is the *House of Eternity* thought of!

I.

Thus did St. Augustine designate the thought of eternity: \"The Great Thought\" \-- *Magna Cogitatio*. It was this thought that induced so many solitaries to retire into deserts; so many Religious, even kings and queens, to shut themselves up in cloisters; and so many Martyrs to sacrifice their lives in the midst of torments, in order to acquire a happy eternity in Heaven, and to avoid a miserable eternity in hell. The Blessed John of Avila converted a certain lady with these two words: \"Reflect,\" said he to her, \"on these two words: *Ever* and *Never*.\" A certain monk went down into a grave that he might meditate continually on Eternity, and constantly repeated, \"O Eternity! Eternity!\"

How frequently, my God, have I deserved the eternity of hell! Oh, that I had never offended Thee! Grant me sorrow for my sins; have compassion on me.

The same Blessed John of Avila says, that he who believes in eternity and becomes not a Saint should be confined as one deranged. When we shall have arrived at eternity there will be no question of our residing in a house more or less commodious, or more or less airy: the question will be of our dwelling in a palace over-flowing with delights, or in a gulf of endless torments. And for how long a time? Not for forty or fifty years, but forever, as long as God shall be God. The Saints, to obtain salvation, thought it little to give their whole life to prayer, penance, and the practice of good works. And what do we do for the same end?

O my God! many years of my life are already past; already death is near at hand, and what have I hitherto done for Thee? Give me light, and strength, to devote the remainder of my days to Thy service. Too much, alas! have I offended Thee; I desire henceforth to love Thee.

II\.

*With fear and trembling work out thy salvation* (Phil. ii, 12).

To obtain salvation we must tremble at the thought of being lost, and tremble not so much at the thought of hell, as of sin, which alone can send us thither. He who dreads sin avoids dangerous occasions, frequently recommends himself to God, and has recourse to the means of keeping himself in the state of grace. He who acts thus will be saved; but for him who lives not in this manner it is morally impossible to be saved. Let us attend to that saying of St. Bernard: \"We cannot be too secure where Eternity is at stake.\"

Thy Blood, O Jesus, my Redeemer, is my security. I should have been already lost on account of my sins, hadst Thou not offered me Thy pardon, on condition of my repentance for having offended Thee. I am sorry therefore, with my whole heart, for having offended Thee, Who art infinite Goodness. I love Thee, O sovereign Good, above every other good. I know that Thou willest my salvation and I will endeavour to secure it by loving Thee forever. O Mary, Mother of God, pray to Jesus for me.

## Spiritual Reading

*MENTAL PRAYER*

II\. ITS END AND OBJECT

In order to practise Mental Prayer, or Meditation, well, and to make it truly profitable to the soul, we must clearly ascertain the ends for which we make it.

1\. *We must meditate in order to unite ourselves more completely to God.* It is not so much good thoughts in the intelligence, as good acts of the will, or holy desires, that unite us to God; and such are the acts that we perform in Meditation, acts of humility, of confidence, self-sacrifice, resignation, and especially of love and of repentance for our sins. \"Acts of love,\" says St. Teresa, \"are those that keep the soul inflamed with holy love.\"

2\. *We must meditate in order to obtain from God, by prayer, the graces that are necessary in order to enable us to advance on the way of salvation, to avoid sin, and to take the means that will lead us to perfection.* The best fruit, then, that comes from Meditation is the exercise of prayer. Almighty God, ordinarily speaking, does not give grace to any but to those who pray. St. Gregory writes: \"God desires to be entreated, He desires to be constrained, He desires to be, as it were, conquered by importunity.\" At times, in order to obtain graces of special value, it is not enough simply to pray; we must pray urgently, and, as it were, compel God, by our prayers, to give them. It is true that at all times the Lord is ready to hear us; but at the time of Meditation, when we are most truly in converse with God, He is most bountiful in giving us His aid.

Above all, we must apply ourselves to Meditation, in order to obtain perseverance and the holy love of God. Final perseverance is not a single grace, but a chain of graces, to which must correspond the chain of our prayers; if we cease to pray, God will cease to give us His help, and we shall perish. He who does not practise Meditation will find the greatest difficulty in persevering in grace till death. Palafox, in his *Notes* on St. Teresa\'s Letters writes thus: \"How will the Lord give us perseverance if we do not ask it? And how shall we ask for it without Meditation? Without Meditation there is no communion with God.\"

Thus must we be urgent in prayer to obtain from God His holy love. St. Francis de Sales said that all virtues come in union with holy love. *All good things came to me together with her.* (Wis. vii, 7). Let our prayer for perseverance and love, therefore, be continual; and, in order to pray with greater confidence, let us ever bear in mind the promise made us by Jesus Christ, that whatever we seek from God through the merits of His Son, He will give us. Let us, then, pray, and pray always, if we would that God make us abound in every blessing. Let us pray for ourselves, and, if we have zeal for the glory of God, let us pray for others. God is most pleased to be entreated for unbelievers and heretics and all sinners. *Let the people confess to thee, O God! let all the people confess to thee.* (Ps. lxvi, 6). Let us say: O Lord! make them know Thee, make them love Thee. We read in the Lives of St. Teresa and St. Mary Magdalen de Pazzi how God inspired these holy women to pray for sinners. And to prayers for sinners let us also add prayers for the Holy Souls in Purgatory.

3\. *We must apply ourselves to Meditation, not for the sake of spiritual consolations, but chiefly in order to learn what is the will of God concerning us. Speak, Lord,* said Samuel to God, *for thy servant heareth.* (1 Kings iii, 9). Lord, make me know what Thou wilt, that I may do it. Some persons continue Meditation as long as consolations continue; but when these cease, they leave off Meditation. It is true that God is accustomed to comfort His beloved souls at the time of Meditation, and to give them some foretaste of the delights He prepares in Heaven for those who love Him. These are things which lovers of the world do not comprehend; they who have no taste except for earthly delights despise those that are celestial. Oh, if they were wise, how surely would they leave such pleasures to recollect themselves and speak alone with God! Meditation is nothing more than converse between the soul and God; the soul pours forth to Him its affections, its desires, its fears, its requests; and God speaks to the heart, causing it to know His goodness, and the love which He bears it, and what it must do to please Him. *I will lead her into solitude and speak to her heart.* (Osee, ii, 14).

But these delights are not constant, and, for the most part, holy souls experience much dryness of spirit in Meditation. \"With dryness and temptations,\" says St. Teresa, \"the Lord makes proof of those who love Him.\" And she adds: \"Even if this dryness lasts through life, let not the soul leave off Meditation; the time will come when all will be well rewarded.\" The time of dryness is the time for gaining the greatest rewards; and when we find ourselves apparently without fervour, without good desires, and, as it were, unable to do a good act, let us humble ourselves and resign ourselves, for this very Meditation will be more fruitful than others. It is enough then to say, if we can say nothing more: \"O Lord! help me, have mercy on me, abandon me not!\" Happy he, who does not leave off Meditation in the hour of desolation. God will make him abound in graces.

## Evening Meditation

*THE WORD WAS MADE MAN IN THE FULNESS OF TIME.*

I.

*When the fulness of time was come God sent his Son.* (Gal. iv, 4).

Consider that God allowed four thousand years to pass, after the transgression of Adam, before He sent His Son upon earth to redeem the world. And in the meantime, oh, what fatal darkness reigned upon the earth! The true God was not known or adored, except in one small corner of the world. Idolatry reigned everywhere; so that devils and stones and beasts were adored as gods.

But let us admire in this the Divine Wisdom: He deferred the coming of the Redeemer in order to render His advent more welcome to man, in order that the malice of sin might be better known, as well as the necessity of a remedy and the grace of the Saviour. If Jesus Christ had come into the world immediately after the fall of Adam, the greatness of this favour would have been but slightly appreciated. Let us therefore thank the goodness of God for having sent us into the world after the great work of Redemption had been accomplished. Behold, the happy time is come which was called the fulness of time: *When the fulness of time was come, God sent his Son\... that he might redeem them that were under the law.* (Gal. iv, 4).

O Divine Word, become Man for me, though I behold Thee thus humbled and become a little Infant in the womb of Mary, yet I confess and acknowledge Thee for my Lord and King, but a King of Love. My dearest Saviour, since Thou hast come down upon earth and clothed Thyself with our miserable flesh, in order to reign over our hearts, I beseech Thee come and establish Thy reign in my heart also, which was once, alas, ruled over by Thine enemies, but is now, I hope, Thine, as I desire that it may be always Thine, and that from this day forth Thou mayst be its only Lord: *Rule thou in the midst of thy enemies.* (Ps. cix, 2). Other kings reign by the strength of arms, but Thou comest to reign by the power of Thy love; and therefore Thou dost not come with regal pomp, or clothed in purple and gold, or adorned with sceptre and crown, or surrounded by armies of soldiers. Thou comest into the world to be born in a stable \-- poor, forsaken, placed in a manger on a little straw, because thus Thou wouldst begin to reign in our hearts.

II\.

It is called *fulness*, on account of the fulness of grace which the Son of God came to communicate to men by the Redemption of the world. Behold the Angel who is sent as ambassador into the town of Nazareth to announce to the Virgin Mary the coming of the Word, Who desires to become incarnate in her womb. The Angel salutes her, calls her *full of grace and blessed among women.* (Luke, i, 28). The humble Virgin, chosen to be the Mother of the Son of God, is troubled at these praises on account of her great humility: but the Angel encourages her, and tells her that she has *found grace* with God; that is to say, that grace which brought peace between God and man, and the reparation of the ruin caused by sin. He then tells her that she must give her Son the Name of Saviour: *Thou shalt call his name Jesus* (Ib. 31), and that this her Son is the very Son of God, Who is to redeem the world, and thus to reign over the hearts of men. Behold, at last Mary consents to be the Mother of such a Son: *Be it done unto me according to thy word.* (Ib. 38). And the Eternal Word takes flesh and becomes Man: *And the Word was made flesh.* (Jo. i, 14).

Let us thank this Son, and let us also thank His Mother, who, in consenting to be the Mother of such a Son, consented also to be the Mother of our salvation, and the Mother of sorrows, accepting at that time the martyrdom of sorrow that it would cost her to be the Mother of a Son Who was to come into the world to suffer and die for man.

Ah, my Infant King, how could I have so often rebelled against Thee, and lived so long Thy enemy, deprived of Thy grace, when, to oblige me to love Thee, Thou hast put off Thy divine majesty, and hast humbled Thyself even to appearing, first, as a Babe in a cave; then as a servant in a shop, and as a criminal on the Cross? Oh, happy me, if, now that I have been freed, as I hope, from the slavery of Satan, I allow myself forever to be governed by Thee and by Thy love! O Jesus, my King, Who art so amiable and so loving to our souls, take possession, I pray Thee, of mine; I give it entirely to Thee; accept it, that it may serve Thee forever, but serve Thee only for love. Thy majesty deserves to be feared, but Thy goodness still more deserves to be loved. Thou art my King, and shalt be always the only object of my love; and the only fear I have is the fear of displeasing Thee. That is what I hope. Do Thou help me with Thy grace. O Mary, my dear Lady! it is for thee to obtain for me that I may be faithful to this beloved King of my soul.
