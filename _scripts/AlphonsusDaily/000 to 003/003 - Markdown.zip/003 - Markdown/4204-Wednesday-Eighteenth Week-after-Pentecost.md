# Wednesday\--Eighteenth Week after Pentecost

## Morning Meditation

*THE FEAST OF THE GUARDIAN ANGELS*

(October 2)

*He hath given his angels charge over thee to keep thee in all thy ways.* (Ps. xc. 11).

St. Bernard says there are three ways by which we ought to honour our Angels: by *Reverence*, by *Devotion* and by *Confidence*.

I.

*He hath given his angels charge over thee to keep thee in all thy ways*. St. Bernard says that there are three ways by which we should honour our Guardian Angels: by Reverence, by Devotion, and by Confidence.

By *Reverence*; because these holy spirits and princes of Heaven are always present with us, and assist us in all our actions. And on this account, out of regard for our Guardian Angels, we should carefully refrain from every action that can displease them. St. Frances of Rome saw that the Angel who attended her in a human form used to cover his face every time he observed in any one anything improper in word or action.

O my holy Guardian Angel, how many times have I by my sins obliged thee to cover thy face! I ask thy forgiveness, and I beseech thee to implore pardon for me from God, for I am resolved not to offend God or thee any more by my negligences.

We ought to honour our good Angels by *Devotion* to them, because of the respect they deserve, and the love they bear us. No love of father, brother, or friend can equal the love our good Angels have for each one of us. Our worldly friends often love us from motives of interest, and on this account very easily forget us when we are in adversity, and much more when we offend them. Our Angel Guardians love us solely from motives of charity, and hence when we are in difficulties, they assist us more particularly, and will not cease to help us after we have rebelled against God. Then will they endeavour to enlighten us, in order that we may soon return to God by repentance.

O how much I should thank thee, my holy Guardian Angel, for the lights thou hast bestowed upon me! O that I had always obeyed thee! Continue to enlighten me; rebuke me when I fail, and do not forsake me even unto the last moment of my life.

II\.

We ought, lastly, to have great *Confidence* in the assistance of our good Angels. God\'s love for us was not satisfied with giving us His Son Jesus for our Redeemer, and Mary for our advocate; He has been pleased to give us also His Angels to be our Guardians, and has commanded them to assist us during the course of our lives: *He hath given his angels charge over thee: to keep thee in all thy ways* (Ps. xc. 11.)

O God of infinite mercy, what more canst Thou do for me that I may be saved? I thank Thee, O my Lord; and I thank thee also, O Prince of Paradise, my good Angel, who for so many years hast assisted and protected me. I have been unmindful of thee, but thou hast not forgotten me. Who knows how much longer I may have to live before I enter eternity? O my good Angel, guide me in the way to Heaven, and cease not to assist me, until thou seest me thy companion for ever in the Kingdom of Heaven. Amen.

## Spiritual Reading

*\"BECAUSE THEY ARE HUMBLED I WILL NOT DESTROY THEM.\"*

The Lord said to Jeremias: *Speak to all the cities of Juda; if so be they will hearken and be converted every one from his evil way, that I may repent me of the evil that I think to do unto them* (Jer. xxvi. 2, 3).

Go, God says, and tell sinners that if they cease from their sins I will spare them from sentence of punishment. St. Jerome says: \"God is wroth, not with us, but with our sins\"; and St. John Chrysostom adds, that if we remember our sins God will forget them. He desires that we being humbled should reform, and crave pardon of Him. \-- *Because they are humbled I will not destroy them* (2 Par. xii. 7).

In order to amend, we must fear punishment, otherwise we shall never be brought to change our lives. True it is, God protects him who hopes in His mercy. *He is the protector of all who trust in Him* (Ps. xvii. 31). But he who hopes in the mercy of the Lord always fears His justice. *They that fear the Lord have hoped in the Lord: He is their helper and their protector* (Ps. cxiii. 11). The Lord often speaks of the rigour of His judgment, and of hell, and of the great number who go thither. *Be not afraid of them who kill the body \... fear ye him who, after he hath killed, hath power to cast into hell* (Luke xii. 4, 5). *Broad is the way that leadeth to destruction, and many there are who go in thereat* (Matt. vii. 13). And why does God so often speak thus? In order that fear may keep us from vice, and from following our passions, and from occasions of sin; and that thus we may reasonably hope for salvation which is only for the innocent, and for the penitent who hope and fear.

Oh, what strength has not the fear of hell to hold us back from sin! To that end has God created hell. He created us, and redeemed us by His death, that we might be happy with Him. He has imposed upon us the obligation of hoping for eternal life, and on that account encourages us, by saying that all those who hope in Him shall be saved. *For none of them that wait on thee shall be confounded* (Ps. xxiv. 3). But it is His wish, too, and command that we should be in fear of eternal damnation. Some heretics hold, that all who are not in sin should consider themselves as justified and predestined; but these have with reason been condemned by the Council of Trent, because such a presumption is as perilous to salvation as fear is profitable. *And let him be your dread, and he shall be a sanctification to you* (Is. viii. 13, 14). The holy fear of God makes man holy. Wherefore David begged of God the gift of fear, in order that fear might destroy in him the inclinations of the flesh. *Pierce thou my flesh with thy fear* (Ps. cxviii. 120).

We should, then, fear on account of our sins, but this fear ought not to deject us: it should rather excite us to confidence in the Divine Mercy, as was the case with the Prophet himself. *For thy name\'s sake, O Lord, thou wilt pardon my sin; for it is great* (Ps. xxiv. 11). How is this? Pardon me because my sin is great? Yes, because the Divine Mercy is most conspicuous where there is the greatest misery; and he who has been the greatest sinner is he who glorifies most the Divine Mercy, by hoping in God, Who promises to save all those who hope in Him. *He will save them, because they have hoped in him* (Ps. xxxvi. 40). For this reason Ecclesiasticus says: *The fear of the Lord shall delight the heart, and shall give joy and gladness and length of days* (Ecclus. i. 12). Thus this very fear leads to the acquisition of a firm hope in God, which makes the soul happy: *He that feareth the Lord shall tremble at nothing, and shall not be afraid, for he is his hope. The soul of him that feareth the Lord is blessed* (Ecclus. xxxiv. 16, 17). Yes, blessed, because fear drives sin away from man. *The fear of the Lord driveth out sin* (Ecclus. i. 27), and at the same time infuses a great desire of observing the commandments: *Blessed is the man that feareth the Lord: he shall delight exceedingly in his commandments* (Ps. cxi. 1).

We must, then, persuade ourselves that God is not inclined by nature to punish. Because by His nature He is infinite goodness, says St. Leo, and has no other desire than to bless us, and to see us happy. When He punishes, He is obliged to do so in order to satisfy His justice, not to gratify His inclination. Isaias says that punishment is a work strange to the Heart of God. *The Lord shall be angry \... that he may do his work, his strange work; \... his work is strange to him* (Is. xxviii. 21). And therefore does the Lord say, that He sometimes almost feigns the intention of punishing us. And why does He do so? He does so for our reformation, and consequently to exempt us from the chastisement we deserve. God wishes to love us, but we force Him to condemn us. He calls Himself the Father of mercies, not of vengeance. Whence it comes that His tenderness all springs from Himself, and His severity from us.

## Evening Meditation

*LOVE OF SOLITUDE*

I.

God does not allow Himself to be found in the midst of the world\'s tumults, and hence the Saints have been wont to seek Him in the most rugged deserts and in solitary caves, that there they might converse with God alone. St. Hilarion made trial of many desert places, going from one to another, ever seeking the loneliest, where none could communicate with him. In the end he died in a desert in Cyprus, after having lived there for five years. When called by God to leave the world, St. Bruno went with his companions to find St. Hugh of Grenoble that he might assign them some desert place in his diocese. St. Hugh assigned them a district so wild and lonely as to be more fitted for the beasts of the forest than for men. There they went with joy to build themselves each a little cell at a distance from one another.

The Lord once said to St. Teresa: \"I would willingly speak to many souls, but the world makes such a noise in their hearts they cannot hear My voice.\" God does not speak to us in the midst of the clamours and affairs of the world, knowing that if He were to speak He would not be heeded. The voice of God are the holy inspirations and lights He sends. By these the Saints are enlightened and inflamed with Divine love, but those who are not lovers of solitude will not be able to hear these messages from God.

God Himself says: *I will lead her into the wilderness and I will speak to her heart* (Osee, ii. 14). When God desires to raise a soul to a high degree of perfection, He inspires it to retire to some solitary place, far from the converse of creatures, and there He speaks to the ears, not of the body, but of the heart; and thus He enlightens and inflames it with His Divine love.

St. Bernard said that he learned much more of the love of God in the midst of the oaks and beeches of the forest, than from books and from the servants of God. Therefore, St. Jerome left the pleasures of Rome, and shut himself up in the Cave of Bethlehem. Then it was he exclaimed: \"O solitude, in which God speaks and converses familiarly with His own!\" In solitude God converses familiarly with His beloved souls, and there He makes them hear words that melt their hearts with holy love, as the sacred spouse said: *My heart melted when my Beloved spoke* (Cant. v. 6).

II\.

We see by experience that conversing with the world, and occupying ourselves in the acquisition of earthly goods, lead us to forget God; but at the hour of death what do we get from all the toil and time we have spent on the things of earth, except pain and remorse of conscience? Our only comfort then will be what we have done and suffered for God. Why, then, do we not separate ourselves from the world, before death separates it from us?

*He shall sit solitary, and hold his peace, because he hath taken it up upon himself* (Lam. iii. 28). He who lives in solitude is not moved as he was formerly in the midst of worldly affairs; he sits in repose, and is at peace, and asks not for sensual delights to satisfy him, for he is lifted above himself, and above all created things; in God he finds every good, and all his contentment.

*Who will give me wings like a dove, and I will fly, and be at rest?* (Ps. liv. 7). David desired to have the wings of a dove, that he might leave this earth, and not touch it even with his feet, and thus give rest to his soul. But while we are in this life, it is not given to us to leave this earth. We must, however, take care to love retirement, so far as it is practicable, conversing alone with God; and thus gaining strength to avoid those defects that arise from our being obliged to have intercourse with the world; as David said, at the very time he was ruling his kingdom: *Lo, I have gone far off flying away, and abode in the wilderness* (Ps. liv. 8).

Oh that I had ever kept my thoughts on Thee, O God of my soul, and not on the goods of this world! I curse those days in which I went about seeking earthly pleasures, and offended Thee, my greatest Good. Oh that I had ever loved Thee! Oh that I had died, and not caused Thee displeasure! Miserable that I am, death draws near, while I find myself still attached to the world! No, my Jesus, from this day I resolve to leave all, and to be wholly Thine. Thou art almighty; Thou must give me strength to be faithful to Thee. O Mother of God, pray to Jesus for me!
