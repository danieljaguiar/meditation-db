# Monday\--Fifth Week After Pentecost

## Morning Meditation

LOSS OF THE SOUL, AN IRREPARABLE EVIL.

How long shall we delay? Until we have to weep with the damned, saying: *Ergo erravimus! We therefore have erred!* (Wis. v. 6), and there is now no longer, or ever shall be, any remedy for us? For every other misfortune in this world there is some remedy, but for the loss of the soul, there is none.

I.

And how long shall we delay? Until we have to weep with the damned, saying: *Ergo erravimus! We therefore have erred!*\--and there is now no longer, or ever shall be, any remedy for us?

For every other misfortune in this world there is some remedy, but for the loss of the soul there is none.

What pains and trouble men take to obtain wealth, dignities, pleasures! But what are they doing to save their souls? Nothing; as though the loss of the soul were but of little consequence!

How much diligence in preserving bodily health! The best physicians, the best remedies, the best climate, are sought after. And as regards the health of the soul, what great negligence!

O my God, I will no longer resist Thy calls! Who knows but that the words which I am now reading may be my last call from God!

Can we be sensible of the danger of being lost forever and not tremble? And do we delay to apply a remedy to the disorders of our consciences?

My soul, how many graces has not God bestowed upon you that you may be saved! He has caused you to be born in the bosom of the true Church. How many advantages for becoming a Saint. Sermons, confessions, the good example of companions. How many lights, how many loving calls in Spiritual Exercises, in Meditation, in Holy Communion! How many mercies has He not shown you! How long has He not waited for you! How many times has He not pardoned you!\--graces which He has not bestowed on so many others.

II\.

*What is there that I ought to do more to my vineyard that I have not done to it?* (Is. v. 4). What more, says Almighty God, ought I to do for your soul? For how many years have you been in the world and what fruit have you hitherto brought forth?

If we had been allowed to choose the means of salvation, what more easy and effectual means could we have chosen?

Alas! if we do not avail ourselves of so many graces, they will serve only to render our death the more miserable.

To become a saint it is not necessary to have ecstasies and visions; sufficient for you are the ordinary means which you possess. Meditate, communicate frequently, read spiritual books, fly all sinful occasions, and you will become a saint.

O God, already have I lived many years in the world, and what have I hitherto gained? O Jesus! Thy precious Blood, Thy death upon the Cross, are my hope!

If this night I were to die, should I be satisfied with my past life? No; and why do I delay? Death may come, and I may have to lament and say: Alas! my life is now at an end, and I have done nothing!

What a grace would it be for a sick man, already despaired of by his physicians, to be allowed another year, or even another month! And God grants me this time; and how shall I employ it for the future?

O Lord, since Thou hast waited for me until now, I will no longer disregard Thee. Here I am! Tell me what Thou requirest of me, and I will do it. I will not wait to give myself to Thee until time for me be no more. O Jesus! I will never more offend Thee. I will spend the remainder of my life in bewailing my past sins, and in loving Thee, the God of my soul.

## Spiritual Reading

II.\--THE ADVANTAGES OF A RETREAT MADE IN SOLITUDE AND SILENCE.

One day the Lord said to St. Teresa: \"There are many souls to whom I would willingly speak, but the world makes so great a noise in their hearts that My voice cannot be heard. Oh, if they would but separate themselves a little from the world!\" Thus, then, my very dear friend, the Lord wishes to speak to you, but alone and in solitude; since if He would speak to you in your own house, your relations, your friends, and your domestic occupations would continue to make a noise in your heart, and you would be unable to hear His voice. The Saints have for this reason left their homes and their country, and gone to hide themselves in caverns or deserts, or at least in a cell in some Religious house, there to find God and hear His voice. St. Eucherius relates that a certain person seeking a place in which he could find God, went for this purpose to ask counsel from a master of the spiritual life. The man of God led him to a solitary place and then said: \"Behold, here God may be found!\" adding nothing more. By this he wished him to understand that God is not to be found in the midst of the noise of the world, but in solitude. St. Bernard says that he learned to know God better amongst the beeches and oaks than in all the learned books he had ever studied.

Worldlings love to be in company with friends, to talk and divert themselves; but the desire of the Saints is to live in solitary places, in the midst of forests, or in caverns, there to converse alone with God Who in solitude familiarly converses with souls as a friend with his friend. \"Oh, Solitude,\" exclaims St. Jerome, \"in which God familiarly converses with His servants!\" The Venerable Vincent Caraffa said that if it had been free to him to wish for anything in this world, he would have asked for nothing but a little grotto with a piece of bread and a spiritual book, there always to live far from men, and conversing alone with God. The Spouse of the Canticles, praising the beauty of a soul living in solitude, compares it to the beauty of the turtle-dove: *Thy cheeks are beautiful as the turtle-dove\'s* (Cant. i. 9), precisely because the turtle-dove avoids the company of other birds, and always lives in the most solitary places. Hence it is that the holy Angels are filled with admiration and joy at the beauty and splendour of a soul ascending into Heaven after a life hidden and solitary as in a desert: *Who is this that cometh up from the desert, flowing with delights?* (Cant. viii. 5).

Now I have written all these things in order to inspire you with a love for holy solitude, for I hope that in the Exercises you are going to perform you will not have to torture your brains, as your pastor said, but that the Lord will make you taste so great a spiritual delight, that you will come out of your Retreat with such an affection for the Spiritual Exercises that you will not fail hereafter to go through them every year. This will be of immense advantage to your soul, whatever state of life you may choose, because in the midst of the world, its various occupations, disturbances, and distractions always produce dryness of spirit, so that it is necessary from time to time to refresh and renew it, as St. Paul exhorts: *Be ye renewed in the spirit of your mind* (Ephes. iv. 23).

King David, troubled by earthly cares, wished to have wings and to fly from the bustle of the world in order to find rest: *Who will give me wings \... and I will fly away and be at rest?* (Ps. liv. 7). But being unable to leave the world in body, he at least sought from time to time to withdraw himself from the affairs of the realm he governed and dwelt in solitude conversing with God, and thus his spirit found peace. *I have gone far off, flying away, and I abode in the wilderness* (Ps. v. 8).

## Evening Meditation

THE PRACTICE OF THE LOVE OF JESUS CHRIST.

*\"Charity beareth all things.\"*

HE THAT LOVES JESUS CHRIST BEARS ALL THINGS FOR HIM, AND ESPECIALLY ILLNESS, POVERTY AND CONTEMPT.

I.

You say you are unable even to pray, because your head is so weak. Be it so: you cannot meditate; but why cannot you make acts of resignation to the will of God? If you would only make these acts, you could not make a better prayer, welcoming with love all the torments that assail you. Thus did St. Vincent de Paul act. When attacked by a serious illness, he was wont to keep himself tranquilly in the presence of God, without forcing his mind to dwell on any particular subject; his sole exercise was to elicit some short acts from time to time, as of love, of confidence, of thanksgiving, and more frequently of resignation, especially in the crisis of his sufferings. St. Francis de Sales made this remark: \"Considered in themselves tribulations are terrifying; but considered in the will of God, they are lovely and delightful.\" You cannot make meditation, you say, and what more exquisite prayer than to cast a look from time to time on your crucified Lord, and to offer Him your pains, uniting the little that you endure with the overwhelming torments that afflicted Jesus on the Cross!

II\.

There was a certain pious lady lying bed-ridden with many ailments, and on the servant putting the Crucifix into her hands and telling her to pray to God to deliver her from her miseries, she made answer: \"But how can you desire me to seek to descend from the Cross, whilst I hold in my hands a God crucified? God forbid that I should do so! I will suffer for Him Who chose to suffer torments for me incomparably greater than mine.\" This was, indeed, precisely what Jesus Christ said to St. Teresa when she was labouring under serious illness; He appeared to her all covered with Wounds, and then said to her: \"Behold, My daughter, the bitterness of My sufferings, and consider if yours equal Mine.\" Hence the Saint was accustomed to say in the midst of all her infirmities: \"When I remember in how many ways my Saviour suffered, though He was innocence itself, I know not how it could enter my head to complain of my sufferings.\" During a period of thirty-eight years St. Lidwina was afflicted with numberless diseases\--fevers, gout in the feet and hands, and sores, all her life-time; nevertheless, from never losing sight of the sufferings of Jesus Christ, she maintained an unbroken cheerfulness and joy. In like manner, St. Joseph of Leonessa, a Capuchin, when the surgeon was about to amputate his arm, and his brethren would have bound him to prevent his stirring from vehemence of pain, seized hold of the Crucifix and exclaimed: \"Wherefore bind me? Wherefore bind me? Behold Who it is that binds me to support every suffering patiently for love of Him!\" And so he bore the operation without a murmur. St. Jonas the Martyr, after passing the entire night immersed in ice water by order of the tyrant, declared next morning that he had never spent a happier night, because he had pictured to himself Jesus hanging on the Cross; and thus, compared with the torments of Jesus, his own had seemed rather caresses than sufferings.
