# First Sunday after Epiphany

*(The Feast of the Holy Family)*

## Morning Meditation

*JESUS AT NAZARETH*

*And Jesus advanced in wisdom and age and grace with God and men* (Gospel of Feast. Luke ii. 42-52).

Every word, every action of Jesus was so holy that it filled all with love for Him, but especially Mary and Joseph who were constantly observing Him. A God serving as a boy! A God working, and sweating as He planes a piece of wood! Ought not the mere thought of this to move our hearts to love Him!

I.

St. Luke, speaking of the life of the Infant Jesus in the house of Nazareth, writes: *And Jesus advanced in wisdom and age, and grace with God and men* (Luke ii. 52). As Jesus grew in age, so did He increase in wisdom; not that He went on every year acquiring knowledge of things, as is the case with us; for, from the first moment of His life, Jesus was full of all Divine knowledge and wisdom: *In whom are hidden all the treasures of wisdom and knowledge* (Col. ii. 3). But it is said that He advanced, because every day as He advanced in age He manifested more and more His sublime wisdom.

Thus it is also said that He advanced in grace with God and men; with God, because all His divine actions, though they did not render Him more holy or increase His merit \-- since Jesus was from the first full of sanctity and merit, of Whose fulness we have received all graces; *of his fulness we have all received* (Jo. i. 16); \-- yet, nevertheless, these operations of the Redeemer were all sufficient in themselves to increase His grace and merit.

Grow, my beloved Jesus, grow continually for me; grow to teach me Thy virtues by Thy divine example; grow to consummate the great sacrifice on the Cross, on which depends my eternal salvation! Grant also my Saviour, that I, too, may grow more in Thy love and grace. Miserable that I have been, my ingratitude has only increased towards Thee Who hast loved me so much. O my Jesus, grant that in future it may be just the contrary with me; Thou knowest all my weakness, it is from Thee that I must receive light and strength. Make me know the claims which Thou hast to my love. Thou art a God of infinite beauty and of infinite majesty, Who didst not refuse to come down upon this earth and become Man for us, and for our sakes to lead a life abject and painful, and to end it by a most cruel death. And where can we ever find an object more amiable and more worthy of love than Thee? Fool that I was, in times past I refused to know Thee, and therefore I lost Thee. I implore Thy pardon; I am heartily sorry, and I am determined to be entirely devoted to Thee in future.

II\.

He advanced also in grace with men, increasing in beauty and amiability. Oh, how Jesus showed Himself more and more amiable every day of His youth, showing more and more every day the claims He had upon men\'s love! With what delight did the holy Youth obey Mary and Joseph! With what recollection of mind did He work! With what moderation did He partake of food! With what modesty did He speak! With what sweetness and affability did He converse with all! With what devotion did He pray! In a word, every action, every word, every movement of Jesus, inflamed with love the hearts of all those who beheld Him, and especially of Mary and Joseph, who had the good fortune to see Him always at their side. Oh, how these holy spouses remained always intent in contemplating and admiring the operations, the words, and gestures of this Man-God!

Look at Jesus growing towards manhood, how busily He toils and labours, in helping Joseph in his trade of a carpenter! Who can ever attentively consider Jesus, that beautiful Youth, fatiguing and exhausting Himself in bringing into form some rough-hewn piece of wood, and not exclaim: But, most sweet Youth, art Thou not that God, Who by a word didst create the world out of nothing? And how comes it that Thou hast laboured now for a whole day, bathed in sweat, to fashion this piece of wood; and even still Thy work remains unfinished? What has reduced Thee to such a state of weakness? O Holy Faith! O Divine Love! O God! O God! how such a thought as this, if once well mastered, would suffice, not only to inflame us, but to reduce us, so to speak, to ashes with the fire of love! Has a God, then, come to such a pass as this? And wherefore? To make Himself loved by men!

O most amiable Infant Jesus, God and Man, it was Thy burning love for me which urged Thee to do all this. I give Thee thanks; and I beseech Thee, by Thy Incarnation, to give me the grace to correspond to such great goodness.

O my sweetest Love, I am sorry that I have offended Thee. I desire to be always faithful in Thy service; enkindle in me Thy love; make me chaste and holy.

## Spiritual Reading

*MARY\'S POVERTY*

Our most loving Redeemer, that we might learn from Him to despise the things of the world, was pleased to be poor on earth: *Being rich*, says St. Paul, *he became poor for your sake, that through his poverty you might be rich* (2 Cor. viii. 9). Therefore doth Jesus Christ exhort each one who desires to be His disciple: *If thou wilt be perfect, go, sell what thou hast, and give to the poor \... and come, follow me* (Matt. xix. 21).

Behold Mary, His most perfect disciple, who indeed imitated His example. Father Canisius proves that Mary could have lived in comfort on the property she inherited from her parents, but she preferred to remain poor, and reserving only a small portion for herself, distributed the rest in alms to the Temple and the poor. Many authors are of opinion that Mary even made a Vow of Poverty; and we know that she herself said to St. Bridget: \"from the beginning I vowed in my own heart that I would never possess anything on earth.

The gifts received from the holy Magi cannot certainly have been of small value; but we are assured by St. Bernard that she distributed them to the poor through the hands of St. Joseph. That the divine Mother immediately disposed of these gifts is evident from the fact that, at her Purification in the Temple, she did not offer a lamb, which was the offering prescribed in Leviticus for those who could afford it, *for a son she shall bring a lamb* (Lev. xii. 6); but she offered two turtledoves, or two pigeons, which was the oblation prescribed for the poor: *And to offer a sacrifice, according as it is written in the law of the Lord, a pair of turtle doves or two young pigeons* (Luke ii. 24). Mary herself said to St. Bridget: \"All that I could get I gave to the poor, and only reserved a little food and clothing for myself.\"

Out of love for poverty she did not disdain to marry St. Joseph, who was only a poor carpenter, and afterwards to maintain herself by the work of her hands, spinning or sewing, as we are assured by St. Bonaventure. The Angel, speaking of Mary, told St. Bridget that \"worldly riches were of no more value in her eyes than mire.\" In a word, she lived always poor, and she died poor; for at her death we do not know that she left anything but her two poor gowns, to two women who had served her during her life, as it is recorded by Metaphrastes and Nicephorus.

St. Philip Neri used to say that \"he who loves the things of the world will never become a Saint.\" We may add what St. Teresa says on the same subject, that \"it justly follows that he who runs after perishable things, should also himself be lost.\" But, on the other hand, she adds, that the virtue of poverty is a treasure which comprises in itself all other treasures. She says the \"virtue of poverty\"; for, as St. Bernard remarks, this virtue does not consist only *in being poor*, but *in loving poverty*. Therefore did Jesus Christ say: *Blessed are the poor in spirit, for theirs is the kingdom of heaven* (Matt. v. 3). They are blessed because they desire nothing but God, and in God they find every good; in poverty they find their Paradise on earth, as St. Francis did when He exclaimed: \"My God and my All.\"

Let us, then, as St. Augustine exhorts us, \"love that one Good in which all good things are found,\" and address our Lord in the words of St. Ignatius: \"Give me only Thy love and Thy grace, and I am rich enough.\"

When we have to suffer from poverty, let us console ourselves, says St. Bonaventure, with the thought that Jesus and His Mother were also poor like ourselves.

Ah, my most holy Mother, thou hadst indeed reason to say that God was thy joy: *and my spirit hath rejoiced in God my Saviour* (Luke i. 47); for in this world thou didst desire and love no other good but God. *Draw me after thee* (Cant. i. 3). O Lady, detach me from the world, that I may love Him alone, Who alone deserves to be loved. Amen.

## Evening Meditation

*JOSEPH\'S LOVE FOR MARY AND JESUS*

I.

Consider, in the first place, the love which Joseph bore to his holy spouse. Of all the women who had ever lived, she was the most beautiful. She was more humble, more meek, more pure, more obedient, more inflamed with the love of God, than all Angels or all men who have been, or shall be, created. Hence she merited all the affections of Joseph, who was so great a lover of virtue. Add to this, the tenderness with which he saw himself loved by Mary, who certainly loved her own spouse above all creatures. Besides, Joseph regarded her as the beloved of God, chosen to be the Mother of His only-begotten Son. Consider how great must have been the affection which, for all these reasons, the just and grateful heart of Joseph entertained for so amiable a spouse as Mary.

Consider, secondly, the love which Joseph bore to Jesus. Having given to our Saint the place of father to Jesus, God must certainly have infused into the heart of Joseph the love of a father, and of a father of a Son so amiable, a Son Who was also God. Hence the love of Joseph was not purely human, like the love of other fathers, but a love superhuman; for he found in the same person One Who behaved like his son, and yet was his God. Joseph knew from the Angel, by a divine revelation, that the Child by Whom he was always accompanied was the Divine Word, Who had become Man for the love of men, and especially for the love of him. He knew that he himself had been chosen from among all men to be the guardian of the life of the divine Infant, and that the Infant wished to be called his Son.

Most holy Patriarch, I rejoice at thy happiness and greatness, in being made worthy to have power to command, with the authority of father, Him Whom Heaven and earth obey. My holy patron, since a God has served thee, I too wish to enrol myself in thy service. I wish henceforth to serve thee, to honour and love thee as my master. Take me under thy protection, and dispose of me as thou pleasest. I know that whatever thou shalt tell me to do, will be for my welfare, and for thy glory and that of my Redeemer.

II\.

Consider what a flame of holy love must have been kindled in the heart of Joseph by meditating on all these things, and in seeing his Lord performing for him all the little offices of a boy \-- at one time opening and closing the door; at another helping him to saw or plane; and at another, gathering fragments of wood, or sweeping the house; and finally, in seeing that He obeyed all his commands, and never did anything without his direction.

What affection must he have felt in carrying Jesus in his arms, caressing Him, and in receiving the caresses of that sweet Infant! In hearing from Him the words of Eternal Life, which, like so many loving darts, wounded his heart! And particularly in witnessing the holy examples of all virtues which the divine Child gave him. Long familiarity with persons who love one another cools their affection; for the longer men converse together, the more perfectly they learn one another\'s defects. This was not the case with Joseph; the more he conversed with Jesus, the better he became acquainted with His sanctity. Consider, then, how great was Joseph\'s love for Jesus, since, according to the authors, he enjoyed His company for the space of twenty-five years.

My holy St. Joseph, pray to Jesus for me. Having obeyed all thy commands on earth, He will certainly never refuse anything thou askest of Him. Tell Him to pardon me the offences that I have offered to Him. Tell Him to detach me from creatures and from myself; ask Him to inflame me with His holy love; and then let Him treat me as He pleases.

And thou, O most holy Mary, through the love which Joseph bore thee, take me under thy patronage, and beg of this thy spouse to accept me for his servant.

And Thou, O my dear Jesus, Who, to atone for my disobedience, didst wish to humble Thyself so as to obey a man, ah, through the merits of the obedience which Thou didst show on earth to Joseph, give me grace henceforth to obey all Thy wishes; and through the love Thou didst bear to Joseph, and which he bore to Thee, grant me a great love of Thee, O infinite Goodness, Who dost deserve the love of my whole heart; forget the injuries I have done Thee, and have mercy on me. I love Thee, O my Love; I love Thee, O my God; I wish always to love Thee.
