# Thursday\--Fifth Week after Epiphany

## Morning Meditation

*CONFIDENCE IN JESUS CHRIST*

The Divine Mercy is like a vast fountain from which he who has brought the largest vessel of confidence carries away the richest abundance of graces. This is according to what the Psalmist says: *Let thy mercy be upon us, O Lord, according as we have put our trust in thee* (Ps. xxxii. 22). Let us go with confidence, then, to the feet of Jesus Christ, and there we shall find mercy and pardon.

I.

Wonderfully great is the mercy of Jesus Christ to us; but for our greater good He desires that we should put our trust in His mercy with a lively confidence, trusting in His merits and His promises. Therefore St. Paul recommends us to preserve this confidence, saying that it has a great reward from God. (Heb. x. 35). When a fear, then, of the Divine Judgment seems to diminish this confidence in us, we ought to cast it away, and say to ourselves: \"My heart, dost thou tremble? Knowest thou not how to hope? Banish thy fear, and tremble not. Why wilt thou trouble me? Hope in the Lord that we may one day sing His praise and His glory.\"

The Lord revealed to St. Gertrude that our confidence so constrains Him that He cannot possibly refuse to hear us in whatever we seek of Him. The same was said by St. John Climachus: \"Prayer exerts a holy violence upon God.\" Every prayer offered with confidence, as it were, forces God; but this force is acceptable and pleasing to Him. Therefore, St. Bernard writes that the Divine mercy is like a vast fountain from which he who brings a larger vessel of confidence carries away a richer abundance of graces. And this is according to what the Psalmist wrote, *Let thy mercy be upon us, O Lord, according as we have put our trust in thee* (Ps. xxxii. 22).

God has declared by the Royal Prophet that He *protects and saves all who trust in him* (Ps. xvii. 31; xvi. 7). And again: *Let all them be glad that hope in thee: they shall rejoice for ever, and thou shall dwell in them* (Ps. v. 12). The same Prophet said: *Mercy is round about all who trust in God* (Ps. xxxi. 10). He that trusts in God shall ever be so guarded and encircled around that he is safe from all danger of perishing. Oh, what great promises the Holy Scriptures make to those who trust in God! Are we lost through our sins? Behold the remedy at hand! *Let us go with confidence*, says the Apostle, *to the feet of Jesus Christ, the throne of grace, and there shall we find mercy and pardon* (Heb. iv. 16). Let us not wait to go to Jesus Christ until He sits upon His *throne of Judgment*; let us hasten at once while He sits on His *throne of grace*.

II\.

But, says the sinner, if I beg for pardon I do not deserve to be heard. I reply, though he does not deserve pardon, his confidence in the Divine mercy will obtain grace for him; for this pardon is not dependent upon his merits, but upon the Divine promise to pardon those who repent; and this is what Jesus Christ says: *Every one that asketh receiveth* (Luke, xi. 10). A certain author commenting on the words *every one*, says that they mean every one, whether just or unjust. It is sufficient that they pray with confidence. Let us, then, learn from the lips of Jesus Christ Himself what great things are done by confidence: *All things whatsoever ye seek when ye pray, believe that ye shall receive, and they shall come unto you* (Mark xi. 24).

Whosoever, then, fears that through infirmity he shall fall again into his old sins, let him trust in God, and he shall not fall, as the Prophet assures us: *None of them that trust in him shall offend* (Ps. xxxiii. 23). Isaias says that *they who hope in the Lord shall renew their strength* (Is. xl. 31). Let us, then, be strong, not wavering in our confidence, because God has promised, as St. Paul says, to protect all who hope in Him; and when anything seems especially difficult to overcome, then let us say, *I can do all things in him that strengtheneth me* (Phil. iv. 13). And who that ever trusted in God was confounded? Yet, let us not search after some constant sensible confidence, a confidence we can feel. It is enough if we have *the will to trust*. This is true confidence, *the will to trust in God*, because He is good and desires to help us, is powerful and can help us, is faithful and has promised to help us. Above all, let us strengthen ourselves with the promise made by Jesus Christ: *Amen, amen, I say to you: if you ask the Father anything in my name, he will give it you* (John xvi. 23). Thus let us seek grace from God, through the merits of Jesus Christ, and we shall obtain what we wish.

O Eternal God, I know that I am poor in all things; I can do nothing, I have nothing, save what comes to me from Thy hands; all I can say to Thee is: O Lord, have mercy upon me! My misery is, that to my poverty I have added the sin of having responded to Thy graces with the sins I have committed against Thee. But, notwithstanding, I would hope from Thy mercy for this twofold blessing: first, that Thou wouldst pardon my sins; and then, that Thou wouldst give me perseverance, together with Thy holy love and grace to pray to Thee constantly for help even until death. I ask it all of Thee; I hope for it through the merits of Thy Son Jesus and the Blessed Virgin Mary. O my chief advocate, help me with thy prayers.

## Spiritual Reading

*HEROES AND HEROINES OF THE FAITH*

12\. \-- SS. PHILEAS, BISHOP OF THMUIS, AND PHILOROMUS, TRIBUNE

(February 4)

Among the many Martyrs of Egypt and Thebais Saints Phileas and Philoromus attract particular attention on account of their exalted rank and the high estimation in which, according to Eusebius, they were held in their own country. They shed their blood for the Faith at Alexandria, between the years 306 and 312.

Phileas had discharged some of the highest offices of state in the city of Thmuis, in Egypt. He was a pagan by birth, was married, and had chidren who were still pagans when the Saint laid down his life for Christ. He was somewhat advanced in life when he was converted, but the Lord filled him with such virtue, that he deserved to be appointed bishop of his native place.\* He was arrested during the persecution and was conducted to prison in Alexandria.

\*In the primitive times in which the Church was composed only of converts, it was not unusual to see married men raised to the dignity of the priesthood and even to that of the episcopate: but these were then obliged to live in perpetual continence. The ministers of the altar are consecrated to God, and can no longer belong to any one except to God alone. \-- ED.

We have a letter written by him to his flock, while he was in prison for the Faith and about to consummate his Martyrdom, which shows his holy zeal and pastoral solicitude. He there encourages the faithful to suffer every torture for Jesus Christ rather than renounce the Faith; adducing the examples of so many saintly heroes who, having the eyes of their souls fixed on God, went joyfully to encounter death, in the full confidence that God would comfort His servants in the trial that would win for them eternal life. He then exhorts them to confide in the merits of Jesus Christ, and to keep continually before their eyes His Passion and Death, as well as the eternal rewards Christ promises to those who will be constant in confessing Him before men.

A short time after the writing of this letter the Martyrs were brought before Culcian, the governor of Egypt, who exhorted them to have pity upon themselves, their wives and children, who, together with many relatives and friends in Alexandria, had come to dissuade them. But all their arts were incapable of shaking the constancy of the Martyrs. Phileas, standing upon the platform and being told by the governor to enter into himself and be wise, answered: \"I have never lost my judgment.\" Culcian: \"Then sacrifice to the gods.\" Phileas: \"I sacrifice to only One God, not to many.\"

\"Thy conscience,\" said the governor, \"should make thee sacrifice for thy wife and children.\" Phileas answered: \"Conscience obliges me to prefer God to all things; since the Scripture saith that thou shalt love thy God Who created thee above all things.\" \"Which God?\" said Culcian. The Saint stretching out his hand to Heaven, said: \"That God Who created Heaven and earth, and endureth forever.\" Culcian asked him: \"Was Christ God?\" The Saint replied: \"Yes, truly, for He hath raised the dead to life, and worked many other miracles.\" \"But how!\" exclaimed the governor; \"Was a God, then, crucified?\" \"Yes,\" replied Phileas; \"He was crucified for our salvation, for which He willingly suffered ignominy and death; all His sufferings were foretold in the Holy Scriptures. If any be desirous of further information, let them come forward and they shall see the truth!\"

The Saint then told the governor that he was anxious for him to execute his orders. \"Then,\" said Culcian, \"thou art anxious to die without reason.\" \"Not without reason,\" said Phileas, \"but for God and for the truth.\" \"I would wish,\" said the governor, \"to save thee for thy brother\'s sake.\"\* But Phileas replied: \"I beseech thee to execute that which hath been commanded thee.\" Culcian said: \"If I knew thee to be poor, I would not desire to save thee; but thou art possessed of great wealth, and canst support many; sacrifice, therefore and live.\" Phileas answered: \"I will not sacrifice.\" Culcian: \"Dost thou not see thy wife, how piteously she looks upon thee?\" Phileas: \"Jesus Christ Whom I serve, is our Saviour; as He has called me; He can also call her to the inheritance of His glory.\"

\*This brother, Alban Butler says, was one of the judges. \-- ED.

The governor here offered him time to consider; but the holy bishop said: \"I have given all these points sufficient consideration and am determined to suffer for Christ.\" Hereupon his relatives cast themselves at his feet, and besought him to have compassion upon his wife and children; but the Saint, raising his eyes to God, declared that he should not think of any relatives other than the Saints in Heaven.

Among the persons of distinction present at this spectacle was Philoromus, a military tribune, who held a very high office in the administration of justice. Having listened to the wailings of the bishop\'s relatives and the exhortations of the governor, he raised his voice and exclaimed: \"Why do you vainly endeavour to shake his constancy? Why do you fatigue yourselves uselessly with one whom you see faithful to his God? Do you not perceive that your entreaties and your tears are of no avail? Tears shed from human motives cannot move the soul of a Christian who has God before his eyes.\" The entire multitude, enraged at these words of Philoromus, cried out that he should be condemned to the same death as Phileas; whereupon the governor commanded that both should be beheaded.

As the entire crowd were proceeding with the Martyrs to the place of execution, the bishop\'s brother said with a loud voice that Phileas had demanded an appeal. Culcian instantly called them back; but Phileas said: \"I have not demanded any appeal. Give no ear to this wretched man. I am much beholden to the judges who have made me a co-heir with Jesus Christ.\"

Having said this he moved forward to the place of execution, where, having arrived together with his companion, he raised his voice and spoke to the Christians: \"My dear children, those of you that seek God in truth should be careful to abstain from sin, since the enemy goeth about seeking whom he may devour. As yet we had not suffered. We now commence to suffer, and to be truly disciples of Jesus Christ. Be ye attentive to the observance of His Commandments, and continually invoke the Creator of all things, to Whom be glory forever!\" At the termination of this exhortation both Martyrs were beheaded. In this manner did these two heroes consummate their sacrifice.

## Evening Meditation

*THE FOLLY OF LIVING AS ENEMIES OF GOD*

I.

Sinners call the Saints fools, who, in this life, fly from honours, riches, and the pleasures of sense, and embrace poverty, contempt, and mortification. But at the day of final retribution those sinners will confess that they themselves have been fools in judging the lives of the Saints to be folly: *We fools esteemed their life madness* (Wis. v. 4). And what greater folly can there be than to live without God? \-- which is to live a miserable life in this world, to be succeeded by a still more miserable life in hell.

No, I will not wait till the Last Day to confess my folly; I now confess it. How great has my folly been in offending Thee, my sovereign Good! *Father, I am not worthy to be called thy son* (Luke xv. 19). Father, I am not worthy to receive Thy forgiveness, but I hope for it through the Blood which Thou hast shed for my sake. My Jesus, I am sorry for having despised Thee, I love Thee above all things.

Unhappy sinners! Blinded by their sins, they lose all judgment. What would be said of a man who should sell a kingdom for the smallest coin? And what should be said of him who, for a momentary pleasure, a vapour, a caprice, sells Heaven and the grace of God? They think only of this life, which will shortly end; and in the meantime deserve hell for the life which will never end.

O my God, permit me not any more to become so blind as to prefer to Thee my own unlawful gratifications, and for the sake of them to despise Thee, my sovereign Good! I now detest them and love Thee above all things.

II\.

Miserable worldlings! The time will come when they will bewail their folly. But when? When there shall be no longer anything to prevent their eternal ruin. Then shall they say: *What hath pride profited us, or what advantage hath the boasting of riches brought us? All those things are passed away like a shadow* (Wis. v. 8, 9). Behold, they will exclaim, how all our delights have passed away like a shadow, and nothing now remains to us but suffering and eternal lamentation. Dear Jesus, have pity on me! I have forgotten Thee; but Thou hast not forgotten me. I love Thee with my whole soul, and I detest, above all evil whatsoever, the sins I have committed against Thee. Pardon me, O God and remember not my offences against Thee. And since Thou knowest my weakness, do not abandon me. Give me strength to overcome all things to please Thee. O Mary, Mother of God, in you do I place my hopes.
