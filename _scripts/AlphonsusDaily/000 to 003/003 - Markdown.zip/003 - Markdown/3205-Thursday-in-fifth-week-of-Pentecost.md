# Thursday\--Fifth Week after Pentecost

## Morning Meditation

THE VANITY OF THE WORLD\--THE GOODS OF THIS WORLD PASS QUICKLY.

Ye great ones of the world who are tormented in the fires of hell, what remains to you now of your honours and your wealth? They answer, weeping: Nothing! Nothing! *What advantage hath the boasting of riches brought us? All these things are passed away like a shadow!*

Ye great ones of the world, who are now tormented in the fires of hell, what remains to you now of your honours and riches? They answer, weeping: Nothing! nothing! We have nothing but torments and despair! All is passed but our punishment, which will never end!

At death men will say: *What hath pride profited us? or what advantage hath the boasting of riches brought us? All those things are passed away like a shadow* (Wis. v. 8). Alas! the remembrance of the good things we have enjoyed in the world will not, at the hour of death, inspire us with confidence, but will fill us with terror and confusion.

Woe to me! How many years have I been in the world, and what have I hitherto done for God? O Lord, have pity on me, and *cast me not away from thy face* (Ps. 1. 13).

The time of death is the time when all worldly things will appear as they really are\--vanity, smoke, and dust!

O my God! How frequently have I exchanged Thee for a nothing! I should not dare to hope for pardon, were it not that Thou hast died in order to pardon me. Now will I love Thee above all things, and will esteem Thy grace more precious than all the kingdoms of the earth.

Death is compared by St. Paul to *a thief* (1 Thess. v. 4), because it robs us of all things\--possessions, relations, beauty, dignity, and even of our own very flesh.

The day of death is also called *the day of destruction* (Deut. xxxii. 35). Then shall we lose all that we have ever acquired, and all that we can hope for from this world. O my Jesus! I am not concerned about the loss of earthly goods, but only lest I should lose Thee, the Infinite Good.

We extol the Saints, who, for the love of Jesus Christ, despise the goods of this earth; and do we continue to be attached to such vanities at the imminent danger of our salvation?

We have a great esteem for the treasures of this life; and why do we make so little account of the treasures of eternity?

Enlighten me. O my God! Make me realize that all creatures are nothing, and that Thou art my All, the Infinite Good. Grant that I may leave all things to possess Thee alone. My God! My God! Thee only do I desire, and besides Thee, nothing in this world!

II\.

St. Teresa says that our faults and our attachments to the goods of this earth, arise from a want of Faith. Let us then reanimate our Faith, and remember we shall one day have to leave all and go into eternity. And hence let us leave all now, while we can obtain merit by so doing. One day we shall have to leave them all. What are riches, honours, friends? God! God! Let us, seek God alone, and God will be our All.

That eminent servant of God, Sister Margaret of St. Ann, daughter of the Emperor Rudolf II, and a discalced Religious used to say: \"What will kingdoms avail at the hour of death?\"

The death of the Empress Isabella induced St. Francis Borgia to renounce the world, and to give himself entirely to God. At the sight of her corpse he said to himself: It is thus, then, that the grandeurs and the crowns of this world terminate!

O my God, Thou hast always loved me! Grant that I may be wholly Thine before death overtakes me.

## Spiritual Reading

V.\--THE ADVANTAGE OF A RETREAT MADE IN SOLITUDE AND SILENCE.

In order to form a true idea of the good produced by a Retreat, read some book on the subject, and see the wonderful conversions brought about by the Exercises. I will mention a few.

Father Maffei tells us there was in Sienna a priest who led a disedifying life. He made a Retreat under the direction of a missionary who happened to be in that town; and not only was he converted, but one day when there was a great multitude in the Church, he went into the pulpit weeping and with a rope round his neck, and there asked pardon for all the scandal he had given. He afterwards became a Capuchin and died a Saint. On his death-bed he made known that all the great graces he had received were due to the Spiritual Exercises.

Father Bartoli relates that a certain German knight, who, having abandoned himself to all kinds of vice, gave his soul to the devil by a document signed in his own blood. He afterwards performed the Spiritual Exercises, and he conceived so great a sorrow for his sins, that he often fainted from excess of grief. He thenceforth led a life of severe penance till the day of his death.

Father Rossignoli tells us that in Sicily a certain baron\'s son led so debauched a life that, having tried all means to make him amend, but in vain, his father was obliged to put him in a galley to work with the slaves. But a certain good Religious, moved to compassion, sought out the young man, and by his kind winning manners, induced him to meditate whilst at his work on the great Truths of Eternity. This he did, and soon he made his confession, and so changed his life that his father was glad to receive him back to his house again, and never again had any reason to be displeased with his son.

A young man in Flanders, having made a Spiritual Retreat, gave up his wicked life. Seeing his friends amazed at his conversion, he said to them: \"You wonder at my change of life, but I tell you that if the devil himself were capable of making the Spiritual Exercises, he would be converted to penance.\"

A Religious who had by his bad conduct become insupportable in his Community, was sent by his Superiors to make a Retreat. When he was going away he jestingly said to those about him: \"Get ready your Rosary beads to touch me when I return.\" But the Exercises did indeed change him so completely that he became an example for all the other Religious, and, seeing the change, they all wished to make the Exercises.

Some young men, seeing a number of their friends going to make a Spiritual Retreat, wished to accompany them, not to profit their souls, but in order afterwards to jest about the Exercises. Just the opposite happened; for during the Retreat they were so filled with compunction that they began to sigh and weep for their sins. They made good Confessions and changed their lives.

## Evening Meditation

THE PRACTICE OF THE LOVE OF JESUS CHRIST.

*\" Charity beareth all things.\"*

HE THAT LOVES JESUS CHRIST BEARS ALL THINGS FOR HIM, AND ESPECIALLY ILLNESS, POVERTY, AND CONTEMPT.

St. Bonaventure said that temporal goods were nothing more than a sort of bird-lime to hinder the soul from flying to God. And St. John Climacus said that poverty, on the contrary, is a path which leads to God free of all hindrances. Our Lord Himself said: *Blessed are the poor in spirit, for theirs is the kingdom of heaven* (Matt. v. 3). In the other Beatitudes, the Heaven of the life to come is promised to the meek and to the clean of heart; but to the poor, Heaven (that is heavenly joy) is promised even in this life: *theirs is the kingdom of heaven.* Yes, for even in the present life the poor enjoy a foretaste of Paradise. By the poor in spirit are meant those who are not merely poor in earthly goods, but who do not so much as desire them; who, having enough to clothe and feed them, live contented, according to the advice of the Apostle: *But having food and wherewith to be covered, with these, we are content* (1 Tim. vi. 8). Oh, blessed poverty, exclaimed St. Laurence Justinian, which possesses nothing and fears nothing! Ever joyous and ever in abundance, since she turns every inconvenience into advantage for the soul. St. Bernard said: \"The avaricious man hungers after earthly things as a beggar, the poor man despises them as a lord.\" The miser is always hungry as a beggar, because he is never satiated with possessing; the poor man, on the contrary, despises them all as a rich lord, inasmuch as he desires nothing.

II\.

One day Jesus Christ thus spoke to St. Angela of Foligno: \"If poverty were not of great excellence, I would not have chosen it for Myself, nor have bequeathed it to My Elect.\" And, in fact, the Saints, seeing Jesus poor, had therefore a great affection for poverty. St. Paul says that the desire of growing rich is a snare of Satan by which he has wrought the ruin of innumerable souls: *They that will become rich, fall into temptation, and into the snare of the devil, and into many unprofitable and hurtful desires, which drown men into destruction and perdition* (1 Tim. vi. 9). Unhappy beings who, for the sake of vile creatures of earth, forfeit an Infinite Good, which is God! St. Basil the Martyr was right, when the Emperor Licinius proposed to make him the chief among his priests, if he would renounce Jesus Christ; he was right, I say, to reply: \"Tell the emperor that were he to give me his whole kingdom, he would not give me as much as he would rob me of by depriving me of God.\" Let us be content, then, with God, and with the things He gives us, rejoicing in our poverty, when we stand in need of something we desire, and have it not; for herein consists our merit. \"Not poverty,\" says St. Bernard, \"but the love of poverty, is reckoned a virtue.\" Many are poor, but from not loving their poverty, they merit nothing; therefore St. Bernard says that the virtue of poverty consists not in being poor, but in the love of poverty.
