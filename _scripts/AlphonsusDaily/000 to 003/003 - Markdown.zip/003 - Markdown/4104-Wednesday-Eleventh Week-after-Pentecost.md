# Wednesday\--Eleventh Week after Pentecost

## Morning Meditation

*IV. \-- THE PASSING OF THE BLESSED VIRGIN OUT OF THIS WORLD.*

It is related that our Lord sent St. Gabriel, the same Archangel who announced to her that she was chosen to be the Mother of God, to announce now that her Divine Son willed to call her to Heaven. On this happy Annunciation, what could the most humble and holy Virgin do, but answer: *Behold the handmaid of the Lord!* Behold, I am ready!

I.

Nicephorus, Metaphrastes, and others relate that some days before her death, our Lord sent her the Archangel Gabriel, the same that announced to her that she was that blessed woman chosen to be the Mother of God: \"My Lady and Queen,\" said the Angel, \"God has already graciously heard thy holy desires, and has sent me to tell thee to prepare thyself to leave the earth; for He wills thee in Heaven. Come, then, to take possession of thy kingdom; for I and all its holy inhabitants await and desire thee.\" On this happy Annunciation, what else could our most humble and most holy Virgin do, but, with the most profound humility, answer again in the same words in which she had answered St. Gabriel when he announced to her that she was to become the Mother of God: *Behold the handmaid of the Lord* (Luke i. 38). Behold, she answered, the slave of the Lord. He in His pure goodness chose me and made me His Mother. He now calls me to Paradise. I did not deserve that honour, nor do I deserve this. But since He is pleased to show in my person His infinite liberality, behold, I am ready to go where He pleases. *Behold the handmaid of the Lord!* May the will of my God and Lord be ever accomplished in me!

After receiving this welcome intelligence she imparted it to St. John. We may well imagine with what grief and tender feelings he heard the news; he who for so many years had attended upon her as a son, and had enjoyed the heavenly conversation of this most holy Mother. She then once more visited the Holy Places of Jerusalem, tenderly taking leave of them, and especially of Mount Calvary, where her beloved Son had died. She then retired to her poor cottage, there to prepare for death.

II\.

During this time the Angels did not cease their visits to their beloved Queen, consoling themselves with the thought that they would soon see her crowned in Heaven. Many authors, such as Andrew of Crete, St. John Damascene, Euthymius, assert that, before her death, the Apostles, and also many Disciples who were scattered in different parts of the world, were miraculously assembled in Mary\'s room, and that when she saw all these dear children in her presence, she thus addressed them: \"My beloved children, through love for you and to help you my Son left me on this earth. The holy Faith is now spread throughout the world and already the fruit of the Divine seed is grown up; hence my Lord, seeing that my assistance on earth is no longer necessary, and compassionating my grief in being separated from Him, has graciously listened to my desire to quit this life and to go and see Him in Heaven. Do you remain, then, to labour for His glory. If I leave you, my heart remains with you; the great love I bear you I shall carry with me and always preserve. I go to Paradise to pray for you.\"

## Spiritual Reading

*TO THEE DO WE CRY, POOR BANISHED CHILDREN OF EVE*

4.-THE GREATNESS OF MARY\'S POWER TO DEFEND THOSE WHO INVOKE HER WHEN TEMPTED.

The Most Blessed Virgin is not only Queen of Heaven and of all Saints, but she is also Queen of hell and of all evil spirits; for she overcame them valiantly by her virtues. From the very beginning God foretold the victory and empire our Queen would one day obtain over the serpent, when He announced that a woman should come into the world to conquer him: *I will put enmities between thee and the woman \... she shall crush thy head* (Gen. iii. 15).

Who could this woman, Satan\'s enemy, be but Mary, who by her fair humility and holy life always conquered him and beat down his strength? The Mother of Our Lord Jesus Christ was promised in the person of that woman, as is remarked by St. Cyprian. Therefore God did not say, \"I place,\" but \"I will place\"; lest He might seem to refer to Eve. God said, *I will place enmities between thee and the woman*, to signify that the serpent\'s opponent was not to be Eve, who was then living, but would be another woman descending from her, and who, as St. Vincent Ferrer observes, \"would bring our First Parents far greater advantages than those which they had lost by their sin.\" Mary, then, was this great and valiant woman, who conquered the devil and crushed his head by bringing down his pride, as it was foretold by God Himself: *she shall crush thy head*. Some doubt as to whether these words refer to Mary, or whether they do not rather refer to Jesus Christ; for the Septuagint renders them, *He shall crush thy head*. But in the Vulgate, which alone was approved of by the Sacred Council of Trent, we find *She* and not *He*; and thus it was understood by St. Ambrose, St. Jerome, St. Augustine, and a great many others. However, be it as it may, it is certain that either the Son by means of the Mother, or the Mother by means of the Son, has overcome Lucifer; so that, as St. Bernard remarks, this proud spirit, in spite of himself, was beaten down and trampled under foot by this most Blessed Virgin; so that, as a slave conquered in war, he is forced always to obey the commands of this Queen. \"Beaten down and trampled under the feet of Mary, he endures a wretched slavery.\" St. Bruno says \"that Eve was the cause of death,\" by allowing herself to be overcome by the serpent, \"but that Mary,\" by conquering the devil, \"restored life to us.\" And she bound him in such a way that this enemy cannot stir so as to do the least injury to any of her clients.

## Evening Meditation

*CONSIDERATIONS ON THE PASSION OF JESUS CHRIST*

I.

The Divine Mother revealed to St. Bridget that the Crown of Thorns surrounded the whole sacred head of her Son, as low down as the middle of His forehead; and that the thorns were driven in with such violence that the Blood gushed out in streams over all His countenance, so that the whole face of Jesus Christ appeared covered with Blood.

Origen writes that this Crown of Thorns was not taken from the head of the Lord until He had expired upon the Cross. In the meantime, as the inner garment of Christ was not sewed together, but woven all in one piece, on this account it was not divided among the soldiers, like his outer garments, but it was given by lot, as St. John writes: *The soldiers, therefore, when they had crucified him, took his garments, and made four parts, to every soldier a part, and also his coat. Now the coat was without seam, woven from the top throughout. They said then one to another: Let us not cut it; but let us cast lots for it, whose it shall be* (Jo. xix. 23, 24). As this garment, then, must have been drawn off over the head, many authors write with great probability, that when Jesus was stripped of it, the crown of thorns was taken from His head, and was replaced before He was nailed to the Cross.

O my Jesus, what thorns have I added to this crown with my sinful thoughts to which I have consented! Would that I could die with grief! Pardon me, through the merit of the grief Thou didst then accept in order to pardon me. O my Lord, thus bruised and thus despised! Thou hast loaded Thyself with all these pains and mockeries in order to move me to have compassion upon Thee, that, at least through compassion, I may love Thee, and no more displease Thee.

II\.

In the book of Genesis it is written: *Cursed is the earth in thy work; thorns and thistles shall it bring forth to thee* (Gen. iii. 17). This curse was inflicted by God upon Adam and upon all his posterity; and by the earth here spoken of we must understand, not only the material earth, but the flesh of man, which, being infected by the sin of Adam, brings forth only the thorns of sin. In order to remedy this infection, says Tertullian, it was necessary that Jesus Christ should offer to God in sacrifice this great torment of the Crowning with Thorns.

This torture also, besides being in itself most acute, was accompanied by blows and spitting, and by the mockings of the soldiers, as St. Matthew and St. John relate: *And plaiting a crown of thorns, they put it upon his head, and a reed in his right hand. And bowing the knee before him, they mocked him, saying: Hail, King of the Jews! And spitting upon him, they took the reed, and struck his head* (Matt. xxvii. 29-30). *And the soldiers plaiting a crown of thorns, put it upon his head; and they put on him a purple garment. And they came to him and said: Hail, King of the Jews! and they gave him blows* (Jo. xix. 3).

It is enough, O my Jesus; cease to suffer more; I am convinced of the love Thou bearest to me, and I love Thee with all my heart. But now I see that it is not enough for Thee; Thou art not satisfied with thorns, until Thou findest Thyself dead with anguish upon the Cross. O Goodness! O infinite Love! Miserable is the heart that loves Thee not!
