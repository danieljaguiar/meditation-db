# Friday\--Twenty-fourth Week after Pentecost

## Morning Meditation

*JESUS CRUCIFIED!*

Jesus Crucified! Oh, what a spectacle to the Angels in Heaven to behold a God Crucified! And we? What sentiments should we conceive when we behold the King of Heaven hanging on a gibbet, covered with wounds, agonising, dying of pure unmitigated pain! O death of Jesus! O love of Jesus, take possession of all my thoughts and affections!

I.

Jesus Crucified! Oh, what a spectacle to the Angels in Heaven to behold a God Crucified! And we? What sentiments should we not conceive when we behold the King of Heaven hanging on a gibbet, covered with wounds, agonizing and dying of pure, unmitigated pain!

O God, why does this Divine Saviour, this innocent and Saintly One, suffer such torments? Ah, He suffers them to expiate the sins of men. And who has ever seen such an example? The Lord suffering for His slaves! The Shepherd dying for His sheep! The Creator immolated and offered as a holocaust for His creatures!

Jesus on the Cross! Behold the Man of Sorrows foretold by Isaias. Behold Him on that infamous tree, full of exterior and interior sorrows. In His body He is torn with scourges, thorns, and nails: blood flows from every wound, and each member suffers its own torment. In His soul He is afflicted with sadness and desolation; He is abandoned by all, even by His very Father. But what tormented Him most severely was the horrid sight of all the sins that the very men, redeemed by His blood, would commit after His death.

Ah, my Redeemer, among these ungrateful ones Thou didst see me, and all my sins. Then I too had a great part in all Thy afflictions on the Cross, when Thou wast dying for me. Oh that I had died, and had never offended Thee!

II\.

Oh, Jesus, my Hope, death terrifies me. I know I shall then have to render an account of all the insults I have offered to Thy love. But Thy death encourages me, and makes me hope for pardon. I am sorry with my whole heart for having offended Thee. If I have not hitherto loved Thee, I now wish to love Thee during the remaining days of my life, and I wish to do and suffer all things in order to please Thee. O my Redeemer, Who died on a Cross for me, assist me.

Lord, Thou hast said that when Thou wouldst be exalted on the Cross, Thou wouldst draw all hearts to Thee. *And I, if I be lifted up from the earth, will draw all things to myself* (Jo. xii. 32). By dying on the Cross for us, Thou hast already drawn to Thy love so many who, for Thy sake, have forsaken all things, their goods, their country, their relatives, and their life. Ah, draw also my poor heart, which, through Thy grace, now longs to love Thee. Permit me not to love mire, as I have hitherto done. O my Redeemer, would that I could see myself stripped of every worldly affection, so as to forget all things, to remember only Thee, and to love Thee alone! I hope for all things from Thy grace. Thou knowest my inability to do any good: through the love which made Thee submit to so cruel a death on Calvary for my sake, I pray Thee to assist me. O death of Jesus, O love of Jesus, take possession of all my thoughts and affections, and grant that, for the future, Thy pleasure, O Jesus, may be the sole object of all my thoughts and desires. O most amiable Lord, hear my prayer, through the merits of Thy death.

O thou, too, O Mary, who art the Mother of Mercy, hear me: pray to Jesus for me. Thy prayers can make me a saint. Such is my hope.

## Spiritual Reading

*PRAYERS TO JESUS*

TO HEAR US BY THE MERITS OF EACH PARTICULAR PAIN HE SUFFERED IN HIS PASSION

O my Jesus, by that humiliation which Thou didst practise in washing the feet of Thy disciples, I pray Thee to bestow upon me the grace of true humility, that I may humble myself to all, especially to such as treat me with contempt.

My Jesus, by that sorrow which Thou didst suffer in the garden, sufficient, as it was, to cause Thy death, I pray Thee to deliver me from the sorrow of hell, from living evermore at a distance from Thee, and without the power of ever loving Thee again.

My Jesus, by that horror which Thou hadst of my sins, which were then present to Thy sight, give me a true sorrow for all the offences I have committed against Thee.

My Jesus, by that pain which Thou didst experience at seeing Thyself betrayed by Judas with a kiss, give me the grace to be ever faithful unto Thee, and nevermore to betray Thee, as I have done in time past.

My Jesus, by that pain which Thou didst feel at seeing Thyself bound like a culprit to be taken before the judges, I pray Thee to bind me to Thyself by the sweet chains of holy love, that so I may nevermore see myself separated from Thee, my only Good.

My Jesus, by all those insults, buffetings, and spittings which Thou didst on that night suffer in the house of Caiphas, give me the strength to suffer in peace, for love of Thee, all the affronts I shall meet with from men.

My Jesus, by that ridicule which Thou didst receive from Herod in being treated as a fool, give me the grace to endure with patience all that men shall say of me, treating me as base, senseless, or wicked.

My Jesus, by that outrage which Thou didst receive from the Jews in seeing Thyself placed after Barabbas, give me the grace to suffer with patience the dishonour of seeing myself placed after others.

My Jesus, by that pain which Thou didst suffer in Thy most holy Body when Thou wast so cruelly scourged, give me the grace to suffer with patience all the pains of my sickness, and especially those of my death.

My Jesus, by that pain which Thou didst suffer in Thy most sacred head when it was pierced with the thorns, give me the grace never to consent to thoughts displeasing unto Thee.

My Jesus, by that act of Thine by which Thou didst accept of the death of the Cross, to which Pilate condemned Thee, give me the grace to accept of my death with resignation, together with all the other pains which shall accompany it.

My Jesus, by the pain which Thou didst suffer in carrying Thy Cross on Thy journey to Calvary, give me the grace to suffer with patience all my crosses in this life.

My Jesus, by that pain which Thou didst suffer in having the nails driven through Thy hands and Thy feet, I pray Thee to nail my will to Thy feet, that so I may will nothing save that which Thou dost will.

My Jesus, by the affliction which Thou didst suffer in having gall given Thee to drink, give me the grace never to offend Thee by intemperance in eating and drinking.

My Jesus, by that pain which Thou didst experience in taking leave of Thy holy Mother upon the Cross, deliver me from an inordinate love for my relatives, or for any other creature, that so my heart may be wholly and always Thine.

My Jesus, by that desolation which Thou didst suffer in Thy death in seeing Thyself abandoned by Thy Eternal Father, give me the grace to suffer all my desolations with patience, without ever losing confidence in Thy goodness.

My Jesus, by those Three Hours of affliction and agony Thou didst suffer upon the Cross, give me the grace to suffer with resignation, for love of Thee, the pains of my agony at the hour of death.

My Jesus, by that great sorrow which Thou didst feel when expiring, and Thy most holy soul separated itself from Thy most sacred body, give me the grace to breathe forth my soul in the hour of my death, offering up my sorrow then to Thee, together with an act of perfect love, that so I may go to love Thee in Heaven, face to face, with all my strength, and for all eternity.

And thou, most holy Virgin, and my Mother Mary, by that sword which pierced thy heart when thou didst behold thy Son bow down His head and expire; do thou assist me in the hour of my death, that so I may go to praise thee and to thank thee in Paradise for all the graces thou hast obtained for me from God. Amen.

## Evening Meditation

*JESUS DEAD UPON THE CROSS*

I.

O Christian, lift up your eyes, and behold your Jesus dead on the gibbet of the Cross. Look at His body full of wounds and streams of blood flowing. Faith teaches you that He is your Creator, your Saviour, your Life, your Deliverer; and that He, Whose love for you exceeds the love of all others, is the only Being that can make you happy.

Yes, my Jesus, I believe it; Thou hast loved me from eternity, without any merit of mine; and even with the foreknowledge of my constant ingratitude, Thou hast, through Thine own goodness, given me existence. Thou art my Saviour, Who, by Thy death, hast delivered me from hell, which I have so often deserved. Thou art my Life, by the grace Thou hast given me, without which I should have remained dead in hell. Thou art my Father, and a loving Father, Who hast pardoned me with so much mercy the many insults I have offered Thee. Thou art my Treasure, enriching me with so many lights and favours, instead of chastising me as I deserved. Thou art my Hope, for I can hope for no good from any one but from Thee. Thou art my true and only Lover; it is enough to say that Thou hast even died for me. In fine, Thou art my God, my sovereign Good, my All.

II\.

O men! O men! let us love Jesus Christ! Let us love a God Who sacrificed Himself entirely for the love of us. He has sacrificed the honours which were due to Him on this earth; He has sacrificed all the riches and pleasures He could have enjoyed, and was content to lead an abject life in poverty and tribulations; and finally in order to atone by His sufferings for our sins, He has voluntarily sacrificed His blood and His life, dying in an ocean of sorrows and ignominies.

Son, exclaims the Redeemer from the Cross to each of us \-- son, what more could I do than die for you, in order to gain your love? See if any one in this world has loved you more than I, your Lord and God, have loved you. Love Me, then, at least in return for the love which I have borne you.

Ah, my Jesus, how can I remember that my sins have made Thee die through pain on an infamous gibbet, and not weep unceasingly for having thus despised Thy love? And how can I behold Thee hanging on this Cross for my sake, and not love Thee with all my power?

But, O Lord, how does it happen that Thou hast died for all, that no one might live any longer to himself, and that afterwards, instead of living only to love Thee and give Thee glory, I have lived only to afflict and dishonour Thee? *Christ died for all, that they also who live may not now live to themselves, but unto him who died for them and rose again* (2 Cor. v. 15).

Ah, my crucified Lord, forget the insults I have offered Thee; I am sincerely sorry for them: draw me, by Thy grace, entirely to Thyself. I wish to live no longer to myself, but only to Thee, Who hast loved me so tenderly, and Who dost merit all my love. I give Thee myself and all that I possess, without reserve. I renounce all the honours and pleasures of this life, and I offer myself to suffer for Thy sake whatsoever Thou pleasest. I entreat Thee, Who dost give me this good will, to grant me strength to execute it. O Lamb of God, immolated on the Cross, O Victim of love, O enamoured God, would that I could die for Thee as Thou hast died for me!

O Mary, Mother of God, obtain for me the grace to sacrifice all the remaining hours of my life to the love of thy most amiable Son.
