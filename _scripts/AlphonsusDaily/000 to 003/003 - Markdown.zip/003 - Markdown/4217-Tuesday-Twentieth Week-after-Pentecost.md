# Tuesday\--Twentieth Week after Pentecost

## Morning Meditation

*FEAST OF ST. TERESA*\
(OCTOBER 15)

What makes the holy Mother, Teresa, an object of our admiration is the steadfastness of soul with which she strove to accomplish whatever she knew was acceptable to God. She taught her children that \"Divine love is to be acquired by a determination to work and suffer for God.\"

I.

Let us consider the burning love which this seraphic Saint entertained for God.

To her it seemed impossible that there could be in the world a single person who did not love God; and she would say; \"My God, art not Thou exceedingly lovable on account of Thine infinite perfections, and of the infinite love Thou bearest towards us? How, then, can there be any one that does not love Thee?\" Most humble though she was, yet in speaking of love she did not shrink from saying: \"I am all imperfection, excepting in desires and in love.\" The Saint has left us on record the following excellent instruction: \"Detach your heart from everything: seek God and you will find Him.\" On the other hand, she used to say, that it is easy for those who love God to detach themselves from the earth: \"Ah! my God, we only need to love Thee truly, for Thee to make everything easy to us.\" Again, she writes: \"Since live we must, let us live for Thee, so that our selfish interests may at last disappear. What greater advantage can any one gain than that which is to be found in pleasing Thee! O my delight and my God, what shall I do in order to please Thee?\" She even went so far as to say that she would not be made sorry at seeing others in Heaven more happy than herself; but that she could not make up her mind to see any one love God more than she should love Him.

What makes this Saint an object of our admiration, is the steadfastness of soul with which she strove to accomplish everything she knew to be acceptable to God. She used to say: \"There is nothing, however painful, that I am not prepared courageously to undertake, if it were set before me to do.\" Hence she gave it as her instruction, that \"Divine love is to be acquired by a determination to act and to suffer for God.\" \"For,\" said she in another place, \"the devil has no fear of irresolute souls.\" To please God, she even went so far, as is well known, as to make a vow of performing whatever was the most perfect. And since sufferings endured for God are the strongest proofs of love, she desired to live for nothing but to suffer. Therefore she wrote: \"It seems to me that there is no reason to live, except it be to suffer; and this it is for which I most fervently pray to God. To Him I say with my whole heart: Lord, either to suffer or to die! I ask of Thee for this, and nothing more.\" Her love became so ardent, that Jesus Christ one day appeared to her and said: \"Teresa, you are all Mine, and I am all yours.\"

II\.

So dear did Teresa become to her Spouse Jesus, that He sent one of the Seraphim to wound her heart with a dart of fire. At length she died as she had lived, all inflamed with love. When the end of her life was drawing near, all her sighs were for death, that she might go to unite herself to her God: \"O death!\" she said, \"I know not who can dread thee, for in thee is life. Serve thy God, O my soul, and hope that He will bring thee a remedy for thy pains.\" For this reason she composed the affectionate Canticle of love that opens with the following words:

\"I live, but from myself am far away:\

And hope to reach a life so high,\

That I\'m forever dying because I cannot die.\"

When the Holy Viaticum was brought to her, she exclaimed: \"O my Saviour, the longed-for moment is at last come! Now begins the time when we shall see each other face to face.\" Then she died of love, as she herself revealed after her death.

O my seraphic Saint, thou art now rejoicing in thy God, Whom thou didst love so much during thy lifetime, when in constant danger of losing Him. Obtain for us, by thy prayers, the grace that we may go to love our God in Paradise with thee for evermore. Amen.

*ACT OF CONSECRATION TO ST. TERESA*

O seraphic virgin, well-beloved spouse of the Divine Word, St. Teresa of Jesus I, (N.N.) though very unworthy to be thy servant, yet encouraged by thy great goodness and by the desire I have to serve thee, in the presence of the Most Holy Trinity, of my Guardian Angel, and of the whole heavenly court, choose thee today, after Mary, for my mother, my mistress, and my special patroness, and I take the firm resolution always to serve thee, and to do all I possibly can that others may serve thee. Therefore, O my seraphic Saint, I supplicate thee, by the Blood thy Divine Spouse shed for me, to receive me among the number of thy devoted servants. Assist me in my necessities, and obtain for me the grace to imitate thy virtues by walking in the true road of Christian perfection. Aid me particularly in prayer, and ask God to give me this glorious gift that thou didst receive in so eminent a degree, in order that, contemplating and loving the sovereign Good, I may avoid, in my thoughts, words, and deeds, all that might offend, or be even in the least displeasing to thee and to my God. Accept this little offering as a mark of my engagement to thy service, and assist me during my life, and above all at the hour of my death. Amen.

## Spiritual Reading

*THE TEACHING OF ST. TERESA ON THE LOVE OF GOD AND OUR NEIGHBOUR*

I. We must love God perfectly; that is,

We must love Him above all things, so as to be willing to die rather than commit the least wilful sin. St. Teresa says: \"May God deliver you from deliberately committing even the most trivial sin!\" \"For,\" she adds, \"the devil, by means of the smallest things, opens a way through which greater things may enter.\" Again, she has this admonition: \"True devotion consists in not offending God and in being resolved to do nothing but what is good and holy.\"

We must love God with our whole heart, ever desiring to arrive at a higher degree of perfection in order to please Him. St. Teresa observes: \"God will not suffer any good desire to go unrewarded even in this life.\" And she also says that our Lord, ordinarily, does not confer many signal favours, \"except upon those who have greatly desired to love Him.\" But to desires we must add actions, by overcoming with fortitude human respect, our own repugnances, and all worldly interests.

We must love God continually, and on all occasions; and for this end we must direct and offer all to Him, even our indifferent actions, such as our eating, diversions, walking, working, every breath we breathe, uniting all with the actions of Jesus Christ and of the Blessed Virgin when on earth. Moreover we must cheerfully suffer all adverse and painful things, conforming ourselves and uniting ourselves to the will of God in whatever He is pleased to do in us and for us. Upon this St. Teresa has left the following excellent sentiments: \"And what more can we wish to gain than the testimony of doing what is pleasing to God?\" And she explains what this testimony is: \"Whilst we live, our gain does not consist in endeavouring to enjoy God, but in doing His will. Great is the fruit of this giving of our will to God, for it induces God to unite Himself to our lowliness. True union is the union of our will with the will of God.\"

To promote this and keep alive the flame of Divine love, we must make frequent acts of love during the course of the day, but particularly when we approach holy Communion and during the time of Meditation, saying to God: My most beloved and only Treasure, my God, my All, I love Thee with my whole heart. I give my whole self to Thee without reserve, and I consecrate to Thee all my thoughts, desires, and affections. I desire, I sigh, I seek for nothing but Thee alone, my only life. To please Thee is my only delight. Do in me and with me whatever Thou pleasest. My God and only good, grant me but to love Thee, and I ask for nothing more.

II\. In order to maintain the union of the soul with God, we must exercise charity towards our neighbour.

As regards the *interior*, it consists in wishing the neighbour the same good that we wish ourselves; in not wishing him the evil we do not wish ourselves; in rejoicing in his good, and regretting the evil which befalls him, although we may naturally experience some repugnance in so doing.

As regards the *exterior*:

1\. We must not murmur against the neighbour, deride or laugh at him, but speak always well of him, and defend, or at least excuse his intention.

2\. We must console him under afflictions.

3\. We must succour him in his necessities of soul and body, particularly in sickness.

4\. We must condescend to the neighbour, as Saint Teresa expresses it, in all that is not sin.

5\. We must not give our neighbour bad counsel or bad example.

6\. We must occasionally reprove him, but mildly and seasonably, but not when we are agitated with passion.

We must above all endeavour to render good for evil, at least to speak well of those who injure us, treat them with meekness, and recommend them to God, turning away our thoughts from the annoyances, harshness, and provocations which we consider we have received from them.

As a conclusion to this short practice we must note, amongst others, the following maxims on perfection which St. Teresa has left us in various parts of her works:

\"All our efforts produce little result, if we we do not get rid of self-confidence, so as to place our confidence wholly in God.

\"Because we do not interiorly give all our affection to God, so neither does God give us all the treasures of His love.

\"May God deliver us from ostentatious devotion.

\"I have often found that there is nothing more efficacious than holy water for driving away the devils.

\"All that we can do is but nothing compared with a single drop of the Blood which the Saviour shed for us.

\"If we do not put an obstacle, God will not hesitate to grant us the assistance necessary in order to become saints.

\"God does not leave without reward a single glance towards Heaven accompanied by the remembrance of Him.

\"The Lord wishes for nothing from us but a resolute will, in order to go on to accomplish all that remains to be done on His part.

\"God never sends a pain which He does not afterwards repay by some favour.

\"If the soul does not keep itself apart from the pleasures of the world, it will soon become careless in the way of the Lord.

\"Do not mention your temptations to imperfect souls, for you will do an injury both to them and to yourself. Communicate them only to the perfect.

\"Let your desire be to see God; your fear be to lose God; your joy be whatever can conduct you to God.\"

*Live Jesus, Mary, Joseph, and Teresa, now and forever.* Amen.

## Evening Meditation

*CONFORMITY TO THE WILL OF GOD*

VIII\. SPECIAL PRACTICES OF THIS VIRTUE

I.

Let us come to the practice of this virtue of conformity to God\'s will, and consider in what we have to bring ourselves into conformity with the will of God.

In the first place, we must have this conformity as regards those things that come to us from without, such as great heat, great cold, rain, scarcity, pestilence, and the like. We must take care not to say: What intolerable heat! What terrible cold! What a misfortune! How unlucky! What wretched weather! or other words expressive of disagreement with the will of God. We ought to will everything to be as it is, since God it is Who wills it so. St. Francis Borgia, on going one night to a house of the Society when the snow was falling, knocked at the door several times; but, the Fathers being asleep, the door was not opened. They made great lamentations in the morning for having kept him so long waiting in the open air, but the Saint said that during the time he had been greatly consoled by the thought that it was God Who was casting the snowflakes down upon him.

In the second place, we must have this conformity as regards things that happen to us from within, as in the sufferings consequent on hunger, thirst, poverty, desolation, or disgrace. In all things, let us ever say: \"Lord, Thine it is to make and to unmake; I am content, I will only what Thou dost will.\" And thus, too, we ought, as F. Rodriguez says, to reply to those imaginary cases which the devil occasionally suggests to the mind, in order at least to dishearten us. If such a person were to say so-and-so to you, or if he were to do so-and-so to you, what would you say? What would you do? Let your answer always be: \"I would say and do that which God wills.\" And by this means we shall keep ourselves free from all fault and be at peace.

In the third place, if we have any natural defect either of mind or body \-- a bad memory, slowness of apprehension, mean abilities, a crippled limb, or weak health \-- let us not, therefore, make lamentation. What were our deserts, and what obligation was God under to bestow upon us a mind more richly endowed, or a body more perfectly framed? Could He not have created us mere brute animals? or have left us in our own nothingness? Who is there that ever receives a gift and tries to make bargains about it? Let us, then, return God thanks for what, through a pure act of His goodness, He has bestowed upon us; and let us rest content with the manner in which He has treated us. Who can tell whether, if we had had better abilities, more robust health, or greater personal attractions, we should not have possessed them to our destruction? How many there are whose ruin has been occasioned by their talents and learning, of which they have grown proud, and in consequence of which they have looked upon others with contempt \-- a danger which is easily incurred by those who excel others in learning and ability! How many others there are whose personal beauty or bodily strength have furnished the occasions of plunging them into innumerable acts of wickedness! And, on the contrary, how many there are who, in consequence of their poverty, infirmity, or ugliness, have sanctified themselves and been saved, who, had they been rich, strong, or handsome, might have been damned! And thus let us rest content ourselves with that which God has given us: *But one thing is necessary* (Luke x. 42). Beauty is not necessary, nor health, nor keenness of intellect; that which alone is necessary is the salvation of our soul.
