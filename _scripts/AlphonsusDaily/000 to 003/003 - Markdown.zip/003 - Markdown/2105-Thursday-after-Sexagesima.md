# Thursday after Sexagesima

## Morning Meditation

PROVOKING GOD BY SIN TO DEPART FROM US.

Thus does the Royal Prophet speak of sinners: *They tempted and provoked the most high God.*. (Ps. lxxvii. 65). God is not capable of grief; but were it possible for Him to grieve, every sin that men commit would deeply afflict Him. Our sins were the cause of Jesus sweating Blood, and suffering the agonies of death in the garden of Gethsemane, where He declared that His soul was *sorrowful unto death.* (Mark xiv. 34).

I.

Every soul that loves God is loved by Him in return, and God dwells within that soul, and leaves it not till He is expelled by sin. \"He forsakes not unless He is forsaken,\" says the Council of Trent. When a soul deliberately consents to mortal sin it expels God, and, as it were, says to Him: Leave me, O Lord, for I desire to possess Thee no longer. *The wicked have said to God: Depart from us.* (Job xxi. 14).

O my God, I have then had the audacity, when I committed sin, to expel Thee from my soul and to desire to have Thee no longer with me! But Thou wouldst not have me to despair, but repent and love Thee. Yes, my Jesus, I do repent of having offended Thee, and I love Thee above all things.

The sinner must be sensible that God cannot dwell in a soul together with sin. When, therefore, sin enters the soul, God must depart from it. So that the sinner, by admitting sin, says to God: As Thou canst not remain any longer with me, unless I renounce sin, depart from me; it is better to lose Thee than the pleasure of committing sin. At the same time that the soul expels God it gives possession to the devil. Thus does the sinner eject his God Who loves him, and makes himself the slave of a tyrant who hates him.

This, O Lord, is what I have hitherto done. Oh, give me some share of that abhorrence for my sins which Thou didst experience in the Garden of Gethsemane. Dearest Redeemer, would that I had never offended Thee!

II\.

When a child is being baptized, the priest commands the devil to depart from its soul: *Go forth, uncleanspirit, and give place to the Holy Ghost.* On the contrary, when a man falls from the state of grace into mortal sin, he says to God, *Go forth from me, O Lord, and give place to the devil!*

Such is the foul ingratitude, O Lord, with which I have frequently repaid Thy great love towards me. Thou didst come down from Heaven to seek me, the lost sheep; and I have fled from Thee and expelled Thee from my soul. But no, I will now embrace Thy sacred feet and will nevermore leave Thee, my beloved Lord. Help me with Thy holy grace. And, O blessed Mary, most holy Queen, do not abandon me.

## Spiritual Reading

JESUS BY HIS EXAMPLE TEACHES US MORTIFICATION.

St. John says, *All that is in the world is the concupiscence of the flesh, and the concupiscence of the eyes, and the pride of life.* (1 John ii. 16). Behold the three sinful loves which held dominion over man after the sin of Adam \-- the love of pleasures, the love of riches, the love of honours, which generate human pride. The Divine Word, to teach us by His example, the mortification of the senses, by which the love of pleasures is subdued, from being happy became afflicted; to teach us detachment from the goods of this earth, from being rich He became poor; and, finally, to teach us humility, which overcomes the love of honours, from being exalted He became humble.

Jesus came, then, to teach us the love of mortification of the senses more by the example of His life than by the doctrines He preached; and, therefore, from being happy He came to lead a suffering life.

Our Redeemer could, indeed, have rescued us from the hands of our enemies without suffering. He could have come on earth and continued in His happiness, leading here below a pleasant life, receiving the honour justly due to Him as King and Lord of all. It was enough, to offer to God one drop of His Blood, one single tear, to redeem the world and an infinity of worlds: \"the least degree of the suffering of Christ\" (says the Angelic Doctor) \"would have sufficed for Redemption, on account of the infinite dignity of His Person.\" But no: *Having joy set before him, he endured the cross.* (Heb. xii. 2). He renounced all honours and pleasures and made choice on earth of a life full of toils and ignominies. St. John Chrysostom says that any action whatever of the Incarnate Word sufficed for Redemption; but it did not suffice for the love which He bore to man. \"What was sufficient for Redemption was not sufficient for love.\" And whereas he that loves desires to see himself loved in return, Jesus Christ, in order to be loved by man, was pleased to suffer exceedingly, and to choose for Himself a life of continual suffering, to put man under an obligation of loving Him. Our Lord revealed to St. Margaret of Cortona that in His whole life He never experienced the smallest degree of sensible consolation: *Great as the sea is thy destruction.* (Lament. ii. 13).

Yes; because Jesus was born on purpose to suffer, He assumed a body particularly adapted for suffering. On entering the womb of Mary, as the Apostle tells us, He said to His Eternal Father: *Sacrifice and oblation thou wouldst not; but a body thou hast fitted to me.* (Heb. x. 5). My Father, Thou hast rejected the sacrifices of men, because they were not able to satisfy Thy Divine justice for the offences committed against Thee: Thou hast given Me a body, as I requested of Thee; a body delicate, sensitive, and made purposely for suffering; I gladly accept of this body, and I offer it to Thee; because by enduring in this body all the pains which will accompany me through My life, and will finally cause My death upon the Cross, I shall propitiate Thee towards the human race, and thus to gain for Myself the love of mankind.

And behold Him scarcely entered into the world, when He already begins His sacrifice by beginning to suffer; but in a manner far different from that in which men suffer. Other children, while remaining in the womb of their mothers, do not suffer, because they are only in their natural place; and if they do suffer in some slight degree, at least they are unconscious of what they feel, since they are deprived of understanding; but Jesus, while an Infant, endures for nine months the darkness of that prison, endures the pain of not being able to move, and is perfectly alive to what He endures. St. Bernard says that though yet unborn Jesus was a Man, not in age, but in wisdom.

When Jesus comes forth from the prison of His Mother\'s womb, was it, perhaps, to lead a pleasant life? He came forth to fresh sufferings, for He chose to be born in the depth of winter, in a cavern where beasts find stabling, and at the midnight hour. He was born in such poverty that He has no fire to warm Him, no clothes to screen Him from the cold. \"A grand pulpit is that manger!\" exclaims St. Thomas of Villanova. Oh, how well does Jesus teach us the love of suffering in the cave of Bethlehem!

The life of Jesus was one of continual affliction and sorrow \-- in Egypt, in Nazareth \-- until at last He died at the hands of His executioners on the Cross in a sea of sorrows and infamy. As Bellarmine says, Jesus had His Cross always before His eyes. When He slept His Heart watched; nor was it ever free from the vision of the Cross.

Learn, then, from Christ, how to love Christ, says St. Bernard. Be happy to suffer something for that God Who suffered so much for you. The desire of pleasing Jesus Christ, and of making known to Him the love they bore Him, made the Saints hungry and thirsty, not for honours and pleasures, but for sufferings and contempt. *God forbid that I should glory save in the cross of our Lord Jesus Christ.* (Gal. vi. 14).

## Evening Meditation

REFLECTIONS AND AFFECTIONS ON THE PASSION OF JESUS CHRIST.

I.

We read in history of a proof of love so prodigious, that it will be the admiration of all ages. There was once a king, lord of many kingdoms, who had one only son, so beautiful, so holy, so amiable, that he was the delight of his father, who loved him as he loved himself. This young prince had a great affection for one of his slaves; so much so, that the slave having committed a crime, for which he had been condemned to death, the prince offered himself to die for the slave; the father, being jealous of justice, was satisfied to condemn his beloved son to death, in order that the slave might remain free from the punishment he deserved: and thus the son died a malefactor\'s death, and the slave was freed from punishment.

This fact, the like of which has never happened in this world and never will happen, is related in the Gospels, where we read that the Son of God, the Lord of the universe, seeing that man was condemned to eternal death in punishment of his sins, chose to take upon Himself human flesh, and thus to pay by His death the penalty due to man: *He was offred because it was his own will.* (Is. liii. 7). And His Eternal Father caused Him to die upon the Cross to save us miserable sinners: *He spared not his own Son, but delivered him up for us us.* (Rom. viii. 32). What dost thou think, O devout soul, of this love of the Son and of the Father?

Thou didst, then, O my beloved Redeemer, choose by Thy death to sacrifice Thyself in order to obtain the pardon of my sins. And what return of gratitude shall I, then, make to Thee? Thou hast done too much to oblige me to love Thee; I should, indeed, be most ungrateful to Thee if I did not love Thee with my whole heart. Thou hast given for me Thy Divine life; I, miserable sinner that I am, give Thee my own life. Yes, I will at least spend that period of life which remains to me only in loving Thee, obeying Thee, and pleasing Thee.

II\.

O men, men, let us love this our Redeemer, Who, being God, has not disdained to take upon Himself our sins, in order to satisfy by His sufferings for the chastisement which we have deserved: *Surely he hath borne our infirmities, and carried our sorrows.* (Is. liii. 4). St. Augustine says, that our Lord in creating us formed us by virtue of His power, but in redeeming us He hath saved us from death by means of His sufferings \"He created us in His strength; He sought us back in His weakness.\" How much do I not owe Thee, O Jesus my Saviour! Oh, if I were to give my blood a thousand times over, if I were to spend a thousand lives for Thee, \-- it would yet be nothing. Oh, how could any one that meditated much on the love which Thou hast shown him in Thy Passion, love anything else but Thee? Through the love with which Thou didst love us on the Cross, grant me the grace to love Thee with my whole heart. I love Thee, Infinite Goodness; I love Thee above every other good; and I ask nothing more of Thee but Thy holy love.

\"But how is this?\" continues St. Augustine. How is it possible, O Saviour of the world, that Thy love has arrived at such a height, that when I had committed the crime, Thou shouldst have to pay the penalty? \"Whither has Thy love reached? I have sinned; Thou art punished.\" And what could it then signify to Thee, adds St. Bernard, that we should lose ourselves and be chastised, as we well deserved to be; that Thou shouldst choose to satisfy with Thy innocent flesh for our sins, and to die in order to deliver us from death? \"O good Jesus, what doest Thou? We ought to have died, and it is Thou who diest, We have sinned, and Thou sufferest. A deed without precedent, grace without merit, charity without measure!\" O deed, which never has had and never will have its match! O grace that we could never merit! O love which can never be understood!
