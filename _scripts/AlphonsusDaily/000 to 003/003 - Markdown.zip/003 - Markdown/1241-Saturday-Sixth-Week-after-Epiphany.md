# Saturday\--Sixth Week after Epiphany

## Morning Meditation

*CONFIDENCE IN MARY\'S INTERCESSION*

HER DESIRE TO HELP US

St. Bernard says that since the power to save us cannot be wanting to Mary as she is the Mother of God, so neither can the desire to help us be wanting because she is our Mother. O Mother of God, and my Mother, Mary, in thee do I place all my confidence.

I.

Of what use, says St. Bonaventure, would Mary\'s power be to us if she did not care to help us? But, adds the Saint, let us hold for certain that as the Virgin Mary is the most powerful of all the Saints before God, so she is the most solicitous of all for our salvation. \"And who, O Lady,\" says St. Germanus, \"after thy Son, feels greater solicitude for us than thou dost? Who defends us so powerfully in our afflictions? Who labours so hard for the conversion of sinners? O Mary, thy protection is so great that we cannot comprehend it.\" St. Andrew Avellino used to call Mary \"the agent of Paradise.\" For what does she do in Heaven? She prays continually for us and obtains for us all the graces that we ask. She said one day to St. Bridget: \"I am called, and I truly am, the Mother of Mercy; for such the Mercy of God has made me.\" And who but God in His Mercy, because He wishes to save all, has given us this great protectress? Miserable, and miserable for eternity, said the Blessed Virgin to St. Bridget, shall be the man who is damned, because when it was in his power in this life to invoke my intercession, he neglected to have recourse to me who am so compassionate to all.

Richard of St. Victor says that Mary is so full of mercy that when she sees our miseries she instantly assists us; she cannot behold a soul in want without coming to its relief.

It was thus she acted when she lived on earth as we learn from what happened at the Marriage in Cana of Galilee. If, then, says St. Bonaventure, Mary\'s compassion for the afflicted was so great while she lived in this world, her pity for us is certainly far greater now that she reigns in Heaven where she has a better knowledge of our miseries and greater compassion for our afflictions.

O Lady, if thou pray for me I shall be saved, for thou dost obtain by thy prayers whatever thou wishest. Pray, then, for me, O great Mother of God, for thy Son hears thee and grants whatever thou askest. It is true that I am unworthy of thy protection, but thou hast never abandoned a soul that had recourse to thee. O Mary, I consign my soul to thee. Thou hast to save it.

II\.

Let us not neglect to have recourse in all our necessities to the Divine Mother who is ever prepared to succour all who invoke her intercession. We shall always find her hands full of mercies and graces. Richard of St. Victor says that Mary\'s heart is so full of compassion, that as soon as she perceives the wants of the miserable, she anticipates their supplications, and obtains relief for them before they ask it. Why, then, says St. Bernard, should we fear that when we have recourse to Mary she will not console us? She is not austere; she does not inspire terror; she is all sweetness and benignity to those who recommend themselves to her. And can she be otherwise than beneficent to those who ask her prayers, when she herself goes in search of the miserable to save them? Behold how she invites all, and encourages them to hope for all good if they have recourse to her: *In me is all hope of life and of virtue: come over to me all ye that desire me, and be filled with my fruits* (Ecclus. xxiv. 25). On this passage Pelbart says: \"She calls all, the just and sinners.\" The devil, according to St. Peter, *goes about seeking whom he may devour* (1 Peter v. 8), but this Divine Mother, says Bernardine da Bustis, goes about seeking whom she may save.

To obtain salvation through her intercession it is enough to ask the aid of her prayers. St. Bonaventure has written that Mary\'s desire for our welfare and salvation is so great, that she is offended not only with those who do her a positive injury, but also with those who do not ask favours from her. Hence the Saint used to say that when he looked at Mary he beheld Mercy itself stretching out her hands to raise him up from his miseries. For this great Lady knows not, and has never known, how to behold without compassion, or to leave without succour, a person who in his misery recommends himself to her. Mary\'s constant occupation in Heaven consists in asking mercy for the miserable. St. Bridget once heard Jesus say to His holy Mother: \"My Mother, ask what you wish from Me.\" And what was Mary\'s request? \"I ask Mercy for the miserable.\" As if she said: My Son, since Thou hast made me Mother of Mercy and Advocate of the miserable, what else will I ask from Thee but Mercy for those who are in misery? And because poor sinners are the most miserable of all, she has her eyes always turned to them in order to assist them.

O Mary, my Mother, I cannot fear, seeing thy immense mercy and the very great desire of thy most sweet heart to help the most abandoned sinners. And who was ever lost who had recourse to thee? Therefore, I invoke thy aid, O my great advocate, my refuge, my hope, my Mother Mary! Into thy hands I entrust the cause of my eternal salvation. To thee I commit my soul. I implore thee, O Mary, for the love that thou bearest to Jesus, to preserve and increase in me more and more this sweet confidence in thy intercession. Amen.

## Spiritual Reading

*THE PRACTICE OF THE CHRISTIAN VIRTUES*

IV\. \-- DEVOTION TOWARDS THE GREAT MOTHER OF GOD

As regards this devotion, I hope the reader is fully persuaded that in order to insure eternal salvation, it is most important to be devout to the great Mother of God. And if he should wish to be still more convinced of it, I would beg him to read the book I have written, *The Glories of Mary*. I shall here speak only of the practices to be observed, that you may obtain the protection of this sovereign Lady. First, every morning and evening, when you get up and before you go to bed, say three *Hail Marys*, adding this short prayer: *By thy pure and Immaculate Conception, O Mary, make my body pure and my soul holy!* And put yourself beneath her mantle that she may keep you that day or that night from sin. And every time you hear the clock strike, say a *Hail Mary*. Do the same whenever you go in or out of the house, and when you pass by any statue or picture of the Blessed Virgin. So also when you begin and finish any of your occupations, such as study, work, eating, or sleeping, never omit to say a *Hail Mary*.

Secondly, say the *Rosary* every day, at least five decades, meditating on the Mysteries. Many devout people also say the Office of Our Lady. It would be well to say at any rate the Little Office of the Name of Mary, which is very short, and composed of five short psalms.

Thirdly, say an *Our Father* and *Hail Mary* every day to the ever-blessed Trinity in thanksgiving for the graces that have been bestowed upon Mary. The Blessed Virgin herself revealed to a person that this devotion was very pleasing to her.

Fourthly, fast on bread and water every Saturday in honour of Mary, or at least on the Vigils of her seven Feasts. At any rate fast in the ordinary way, or eat only of one dish, or abstain from something you like. In short, make use of some kind of mortification on Saturdays, and on the above-named Vigils, for the sake of this Queen, who (as St. Andrew of Crete says) repays these little things with great graces.

Fifthly, pay a *Visit* every day to some image of your Patroness, and ask her to give you holy perseverance and the love of Jesus Christ.

Sixthly, let no day pass without reading a little about Our Lady.

Seventhly, make the *Novenas* for the seven principal Feasts of Mary, and ask your confessor to tell you what devotions and mortifications you should practise during those nine days. Say at least nine *Hail Marys* and *Glory be to the Father*, and beg her each day of the Novena to give you some special grace of which you are in need.

Lastly, often recommend yourself to this Divine Mother during the day, and particularly in time of temptation, saying at such times, and often repeating with great affection: O Mary help me! Help me, O my Mother!

And if you love Mary, try to promote devotion to this great Mother of God among your relations, friends and servants.

## Evening Meditation

*PRAYER*

I. \-- ITS POWER

I.

*Ask and it shall be given you \... for every one that asketh receiveth* (Luke xi. 9, 10).

In a thousand places in the Old and the New Testament, God promises to hear all who pray to Him. *Cry to me and I will hear thee* (Jer. xxxiii. 3). *Call upon me \... and I will deliver thee* (Ps. xlix. 15). *If you ask anything in my name, that I will do* (Jo. xiv. 14). *You shall ask whatever you will, and it shall be done unto you* (Jo. xv. 7). Hence Theodoret has said that prayer is one, but can obtain all things. St. Bernard says that when we pray, the Lord will give either the grace we ask, or one that is more useful to us. The Prophet animates us to pray by assuring us that God is all mercy to those who invoke His aid. *Thou, O Lord, art sweet and mild and plenteous in mercy to all that call upon thee* (Ps. lxxxv. 5). The words of St. James are still more encouraging. *If any of you want wisdom, let him ask of God, who giveth abundantly to all men and upbraideth not* (James i. 5). This Apostle tells us that when we pray to the Lord, He opens His hands and gives us more than we ask. *He giveth to all men abundantly, and upbraideth not*. He does not reproach us with the offences we have offered to Him; but, when we pray to Him, He appears to forget all the injuries we have done Him.

St. John Climacus used to say that prayer in a certain manner forces God to grant us whatsoever we ask of Him. \"Prayer piously offers violence to God.\" But it is, as Tertullian says, a violence which is pleasing to Him, and which He desires from us. Yes; for as St. Augustine says, God has a greater desire to give us His graces, than we have to receive them. The reason is, because God is of His own nature infinite Goodness. Hence He feels an infinite desire to impart His benefits to us. St. Mary Magdalen de Pazzi used to say that God feels as it were under an obligation to the soul that prays to Him; because by prayer it opens to Him the way by which He can satisfy His desire of dispensing His graces to us.

O Eternal God, I adore Thee and I thank Thee for all the benefits Thou hast bestowed upon me, \-- for having created me, for having redeemed me, through Jesus Christ, for having made me a Christian, for having waited for me when I was in sin, and for having so often pardoned me. Ah, my God, I should never have offended Thee, if in my temptations I had recourse to Thee.

II\.

David says that the goodness of God, in instantly hearing all who pray to Him, proves that God was his true God. *In what day so ever I shall call upon thee, behold, I know thou art my God* (Ps. lv. 10). Some, observes St. Bernard, complain that God fails them; but the Lord may far more justly complain that many fail Him when they neglect to ask His graces. Of this precisely the Redeemer appears to have complained one day to His disciples. *Hitherto you have not asked anything in my name: ask and you shall receive, that your joy may be full* (Jo. xvi. 24). As if He said: Do not complain of Me if you do not enjoy complete happiness; complain of yourselves for not having asked My graces. Ask Me for them henceforth, and you shall be satisfied.

There is no exercise more conducive to salvation than to pray always and say: Lord, assist me! *Incline unto my aid, O God* (Ps. lxix. 2). The Venerable Paul Segneri used to say that in his Meditations he was at first accustomed to spend his time in *pious affections*; but, having afterwards learned the great efficacy of prayer, he endeavoured generally to employ himself in *petitions to God*. Let us always do the same. We have a God Who loves us to excess, and Who is solicitous for our salvation, and therefore He is ever ready to hear all who ask His graces. The earthly princes, says St. Chrysostom, give audience only to a few; but God gives audience to all who wish.

I thank Thee, O God, for the light by which Thou now makest me understand that my salvation consists in praying to Thee and in asking graces of Thee. Behold I entreat Thee in the Name of Jesus Christ, to give me a great sorrow for my sins, holy perseverance in Thy grace, a good death, Heaven, but above all, the great gift of Thy love and perfect resignation to Thy most holy will. I well know that I do not deserve these graces, but Thou has promised them to all who ask them of Thee through the merits of Jesus Christ. Through these merits I hope and ask for them. O Mary, thy prayers are always heard; pray for me.
