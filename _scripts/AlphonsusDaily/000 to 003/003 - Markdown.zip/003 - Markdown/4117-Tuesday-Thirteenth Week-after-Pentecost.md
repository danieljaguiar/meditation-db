# Tuesday\--Thirteenth Week after Pentecost

## Morning Meditation

*THE VANITY OF ALL EARTHLY THINGS*

*What is your life?* St. James answers: *It is a vapour*. After death the rich man is carried out of his palace to return no more! His servants accompany him to the grave, and leave him there to be devoured by worms! *Why is earth and ashes proud?*

I.

*What is your life?* St. James answers: It is only a vapour which appears for a little time and then is seen no more! For what is your life? *It is a vapour which appeareth for a little while, and afterwards shall vanish away* (James iv. 15). The vapours which arise from the earth and are raised into the air and surrounded by the rays of the sun appear brilliant and beautiful; but the least wind disperses them, and they are seen no more. Such is the grandeur of this world. Behold that prince; to-day he is feared, attended upon, and honoured by thousands; tomorrow he will be dead, despised and hated by all. In a word, honours, pleasures, and riches must all end in death.

O my God, make me sensible of the immensity of Thy goodness, that I may love nothing but Thee.

Death deprives man of whatever he may posses in this world. What a sad sight, to behold a rich man, after death, carried out of his palace, to return thither no more! How sad to behold others taking possession of the estates he has left, of his wealth, and of whatever else he so lately enjoyed! His servants, after having accompanied him to the grave, abandon him, and leave him there, to be devoured by worms; no one esteeming him, no one flattering him. Formerly everyone obeyed his nod, but now no one takes the least notice of his orders.

How wretched have I been, O Lord, in having, for so many years, gone after the vanities of the world, and left Thee, my sovereign Good! But from this day forward I desire to possess Thee as my only treasure, as the only love of my soul.

II\.

*Why is earth and ashes proud?* (Ecclus. x. 9). O man, says the Almighty, seest thou not that in a short time thou wilt become dust and ashes? And on what dost thou fix thy thoughts and affections? Reflect that death will soon rob thee of everything, and separate thee from the whole world. And if, when thou givest in thy account, thou be found wanting, what will become of thee for eternity?

I give Thee thanks, my Lord and my God. Thou speakest thus to me, because thou desirest to save me. Let Thy mercies now prevail. Thou hast promised to pardon such as repent of their offences against Thee. From the bottom of my heart do I repent: grant me therefore pardon. Thou hast promised to love those who love Thee: and I now love Thee above all things. Wherefore do Thou love me also, and hate me not any more, as I have deserved. O Mary, my advocate, in thy protection is my hope.

## Spiritual Reading

*4. \-- \"WHEN I WAS A LITTLE ONE I PLEASED THE MOST HIGH.\"*

The second argument by which it is proved that Mary was more holy in the first moment of her existence than all the Saints together, is founded on the great office of Mediatress of men, with which she was charged from the beginning; and which made it necessary that she should possess a greater treasure of grace from the beginning than all other men together. It is well known with what unanimity Theologians and holy Fathers give Mary this title of Mediatress, on account of her having obtained salvation for all, by her powerful intercession and her merit of \"congruity,\" thereby procuring the great benefit of Redemption for the lost world. I say by her merit of congruity, for Jesus Christ alone is our Mediator by way of justice and by merit, \"de condigno,\" as the Scholastics say, He having offered His merits to the Eternal Father, Who accepted them for our salvation. Mary, on the other hand, is a Mediatress of grace, by way of simple intercession and merit of congruity, she having offered to God, as Theologians say with St. Bonaventure, her merits, for the salvation of all men; and God, as a favour, accepted them with the merits of Jesus Christ. On this account Arnold of Chartres says that \"she effected our salvation in common with Christ.\" And Richard of St. Victor says that \"Mary desired, sought, and obtained the salvation of all; nay, even she effected the salvation of all.\" So that everything good, and every gift in the order of grace, which each of the Saints received from God, Mary obtained for them.

And the holy Church wishes us to understand this when she honours the Divine Mother by applying the the following verses of Ecclesiasticus to her: *In me is all grace of the way and of the truth. Of the way*, because by Mary all graces are dispensed to wayfarers. *Of the truth*, because the light of truth is imparted by her. *In me is all hope of life and of virtue. Of life*, for by Mary we hope to obtain the life of grace in this world, and that of glory in Heaven. *And of virtue*, for through her we acquire virtues, and especially the theological virtues which are the principal virtues of the Saints. *I am the mother of fair love, and of fear, and of knowledge, and of holy hope* (Ecclus. xxiv. 24-25). Mary, by her intercession, obtains for her servants the gifts of Divine love, holy fear, heavenly light, and holy perseverance. From which St. Bernard concludes that it is a doctrine of the Church that Mary is the universal Mediatress of our salvation. He says: \"Magnify the finder of grace, the mediatress of salvation, the restorer of ages. This I am taught by the Church proclaiming it; and thus also she teaches me to proclaim the same thing to others.\"

St. Sophronius, Patriarch of Jerusalem, asserts that the reason for which the Archangel Gabriel called her full of grace \-- *Hail, full of grace!* \-- was because only limited grace was given to others, but it was given to Mary in all its plenitude: \"Truly was she full, for grace is given to other Saints partially, but the whole plenitude of grace poured itself into Mary.\" St. Basil of Seleucia declares that she received this plenitude that she might thus be a worthy Mediatress between men and God: \"Hail, full of grace, Mediatress between God and men, and by whom Heaven and earth are brought together and united.\" \"Otherwise,\" says St. Laurence Justinian, \"had not the Blessed Virgin been full of Divine grace, how could she have become the ladder to Heaven, the advocate of the world, and the most true Mediatress between men and God?\"

## Evening Meditation

*CONSIDERATIONS ON THE PASSION OF JESUS CHRIST*

*I thirst!*

I.

St. John writes: *Afterwards Jesus, knowing that all things were now accomplished, that the Scripture might be fulfilled, said: I thirst!* (Jo. xix. 28). Scripture here refers to the words of David: *They gave me gall for my food, and in my thirst they gave me vinegar to drink* (Ps. lxviii. 22).

Most severe was this bodily thirst which Jesus Christ endured on the Cross through loss of Blood, first in the Garden, and afterwards in the Hall of Judgment, at His scourging and crowning with thorns; and lastly upon the Cross, where four streams of Blood gushed forth from the Wounds of His pierced hands and feet as from four fountains. But far more terrible was His spiritual thirst, that is, His ardent desire to save all mankind and to suffer still more for us, as Blosius says, in order to show us His love. On this St. Laurence Justinian writes: \"This thirst came from the ardour of His charity.\"

O my Jesus, Thou hast thus desired to suffer for me; and I, when my sufferings at all increase, become so impatient that I am insupportable both to others and to myself. O my Jesus, through the merits of Thy patience, make me patient and resigned in the sicknesses and crosses which befall me; make me like unto Thyself before I die.

II\.

Jesus, drawing nigh unto death, said: *Sitio \-- I thirst!* Tell me, Lord, says Leo of Ostia, for what dost Thou thirst? Thou makest no mention of those immense pains Thou dost suffer upon the Cross; but Thou complainest only of thirst: \"Lord, what dost Thou thirst for? Thou art silent about the Cross, and criest out about the thirst.\" \"My thirst is for your salvation,\" is the reply which St. Augustine makes for Jesus. O soul, says Jesus, this thirst of Mine is nothing but the desire I have for thy salvation. Yes, the loving Redeemer, with extremest ardour, desired our souls, and therefore He panted to give Himself wholly to us by His death. This was His thirst, wrote St. Laurence Justinian: \"He thirsted for us, and desired to give Himself to us.\" St. Basil of Seleucia says, moreover, that Jesus Christ, in saying that He thirsted, would give us to understand that He, for the love which He bore us, was dying with the desire of suffering for us even more than what He had suffered: \"O that desire of His, greater than the Passion!\"

O most lovely God, because Thou lovest us, Thou dost desire that we should desire Thee! \"God thirsts to be thirsted for,\" as St. Gregory says. Ah, my Lord, dost Thou thirst for me, most vile worm that I am? And shall I not thirst for Thee, my infinite God? Oh, by the merits of this thirst endured upon the Cross, give me a great thirst to love Thee, and to please Thee in all things. Thou hast promised to grant us whatever we seek from Thee: *Ask, and ye shall receive* (Jo. xvi. 24). I ask of Thee but this one gift \-- the gift of loving Thee. I am, indeed, unworthy of it; but in this has to be the glory of Thy Blood, \-- the turning of a heart into a great lover of Thee, a heart which at one time, so greatly despised Thee; to make a perfect flame of charity of a sinner who is altogether full of mire and of sins. Much more than this hast Thou done in dying for me. Would that I could love Thee, O Lord infinitely good, as much as Thou dost deserve! I delight in the love that is borne Thee by the souls that are enamoured of Thee, and still more in the love Thou bearest towards Thyself. With this I unite my own wretched love. I love Thee, O Eternal God; I love Thee O infinite Loveliness. Make me ever to increase in Thy love, repeating frequent acts of love of Thee, and striving to please Thee in everything, without intermission and without reserve. Make me, wretched and insignificant though I am, make me at least to be all Thine own.
