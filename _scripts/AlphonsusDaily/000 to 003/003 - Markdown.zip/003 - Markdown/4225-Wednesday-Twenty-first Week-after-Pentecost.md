# Wednesday\--Twenty-first Week after Pentecost

## Morning Meditation

*\"THE ENEMIES OF THE LORD SHALL VANISH LIKE SMOKE.\"*

Holy Job enquires why the wicked are allowed to live, and why are they advanced and strengthened in prosperity? And why instead of dying in poverty and tribulation they continue to enjoy health and honours and riches? The holy man himself gives the answer: *They spend their days in wealth, and in a moment they go down to hell*.

I.

St. Jerome says that there cannot be a greater punishment for a sinner than that he should not be punished in this life. And St. Isidore of Pelusium says that sinners who are punished in this life do not deserve pity, but those only who die without having been punished. It is not so bad, continues the Saint, to be simply sick as to have no one to cure you. St. Augustine says, in another part, that when God does not chastise the sinner in this world, He chastises him most severely; whence he concludes that there is no greater misfortune than impunity for a sinner. After England had rebelled against the Church, God did not visit her with temporal scourges: her riches have been increasing from that time; but her chastisement is all the greater on that account, as she is left to perish in her sin. The absence of punishment is the greatest punishment, says the same holy Doctor. Not to receive chastisement for sin in this life is a great punishment, but prosperity in sin is a still greater punishment.

*Why then*, Job inquires, *do the wicked live, are they advanced and strengthened with riches?* How comes it, O Lord, that sinners, instead of being taken out of this life in poverty and tribulation, enjoy health, and honours, and riches? The holy man answers: *They spend their days in wealth, and in a moment they go down to hell* (Job xxi. 7, 13). Wretched men! they enjoy their riches for a few days, and when the hour of chastisement comes, when they least expect it, they are condemned to burn forever in that place of torments. Jeremias makes the same inquiry: *Why doth the way of the wicked prosper?* and then adds, *Gather them together as sheep for a sacrifice* (Jer. xii. 1-3). Animals destined for sacrifice are kept from all labour, and fattened for slaughter. Thus does God act towards the obstinate: He abandons them, and suffers them to fatten on the pleasures of this life in order to sacrifice them in the other to His eternal justice; for these, says Minutius Felix, are fed like victims for the slaughter.

II\.

Poor wretched sinners, says David, shall not be punished in this life, but they shall enjoy their fleeting pleasures. By and by their dream shall cease: *Neither shall they be scourged like other men; \... they have suddenly ceased to be; as the dream of them that awake, O Lord, so in thy city thou shalt bring their image to nothing* (Ps. lxxii. 5, 18, 20). How painful is not the case of a poor sick man, who dreams that he has grown rich and great, and upon awaking finds himself a miserable and sick creature still? *And the enemies of the Lord shall \... vanish like smoke* (Ps. xxxvi. 20). The happiness of sinners is as suddenly dissipated as is smoke by a breath of air. \"Smoke,\" observes St. Gregory, \"vanishes in its ascent.\" And the same is the case with sinners: *I have seen the wicked highly exalted, \... and I passed by, and lo! he was not* (Ps. xxxvi. 35). These unhappy men are exalted the higher, that their fall may be the greater. The Lord allows the sinner to be exalted for his greater punishment, in order that his fall may be the more grievous, as is said by David. *When they were lifted up thou hast cast them down* (Ps. lxxii. 18). If the sick man, says St. John Chrysostom, suffer hunger or thirst by order of his physician, it is a sign that the physician has hope of him; but if the doctor allow him to eat what he pleases, and drink as much as he likes, what are we to conclude from that? It is plain that the physician has given him over. And thus, says St. Gregory, it is a manifest sign that God abandons the sinner to perdition, when He never thwarts his evil purposes: and in the Book of Proverbs we read that *the prosperity of fools shall destroy them* (Prov. i. 32). As lightning precedes thunder, says St. Bernard, so is prosperity the forerunner of damnation for the sinner.

## Spiritual Reading

*HOLY HUMILITY*

II\. ITS ADVANTAGES

The proud are objects of hatred and abomination before God. *Every proud man*, says the Holy Ghost, *is an abomination to the Lord* (Prov. xvi. 5). Yes; for the proud man is a robber, and is blind; he is a liar, and the truth is not in him. He is a robber, because he appropriates to himself what belongs to God. *What hast thou that thou hast not received?* (1 Cor. iv. 7). Would it not be the extreme of folly in a brute animal, were it gifted with reason, to glory in the gilded trappings of which it knows it may be stripped at the beck of its master? The proud man is blind, as we learn from the Apocalypse of St. John. *Thou sayest: I am rich \... and knowest not that thou art wretched and blind* (Apoc. iii. 17). And what has man of his own but nothingness and sin? Even the little good he does, when examined with rigour, will appear full of imperfection. \"All our justice,\" says St. Bernard, \"if rigorously judged, will be found to be injustice.\" Lastly, the proud man is a liar, and the truth is not in him. For all his advantages, whether of nature \-- such as health, talent, beauty, and the like; or of grace \-- such as good desires, a docile heart, and an enlightened mind, are all the gifts of God. *By the grace of God*, says St. Paul, *I am what I am* (1 Cor. xv. 10). The same Apostle tells us that of ourselves we are not capable of even a good thought. *Not that we are sufficient to think anything of ourselves as of ourselves* (2 Cor. iii. 5).

To preserve His servants from pride, the Lord sometimes permits them to be afflicted with the shameful solicitations of the flesh; to their repeated prayers to be delivered from the suggestions of Satan and of their own corruption He appears deaf, and leaves them to combat with the temptation. It was thus God treated St. Paul; and, says the Saint, *lest the greatness of the revelations should exalt me, there was given to me a sting of my flesh, an angel of Satan, to buffet me. For which thing thrice I besought the Lord that it might depart from me, and he said to me, my grace is sufficient for thee* (2 Cor. xii. 7, 8, 9). \"To keep him humble,\" says St. Jerome, \"the Almighty refused to deliver the Apostle from the molestation of the flesh by which he was tormented.\" Moreover, to teach them humility, the Lord sometimes permits the elect to fall into sin. Thus David acknowledges that he sinned because he had not been humble. *Before I was humbled, I offended* (Ps. cxviii. 67).

\"God,\" says St. Augustine, \"sits on high; you humble yourself, and He descends to you; you exalt yourself, and He flies from you.\" The royal Prophet says that *the Lord looketh on the low, and the high he knoweth afar off* (Ps. cxxxvii. 6). He regards the humble with the affectionate eye, but the proud He beholds only at a distance. As we cannot recognize a person whom we see afar off, so the Lord appears to tell the proud, in the words of the Psalmist, that He knows them not.

The proud are hateful before God; He cannot bear them. As soon as the Angels yielded to pride, He banished them from Paradise and sent them into hell, far distant from His presence. The words of God must be fulfilled: *Whosoever*, says the Lord, *shall exalt himself, shall be humbled* (Matt. xxiii. 12). St. Peter Damian relates that a certain proud man had resolved to assert his right to an estate by single combat; before the time appointed for the duel he went to Mass, and hearing in the church the above-mentioned words of the Gospel: *Whosoever shall exalt himself, shall be humbled*, he exclaimed: This cannot be true: for had I humbled myself I should have lost my property and my character. But when he came to the combat, his sacrilegious tongue was cut across by the sword of his antagonist, and he instantly fell dead.

*God*, says St. James, *resisteth the proud, and giveth grace to the humble* (James iv. 6). The Lord has promised to hear the prayers of all. *Every one that asketh, receiveth* (Luke xi. 10). The proud God hears not; according to the Apostle, He resists their petitions. But to the humble He is liberal beyond measure: *He giveth grace to the humble*. To them God opens His hands, and grants whatsoever they ask or desire. *Humble thyself to God*, says the Holy Ghost, *and wait for his hands* (Ecclus. xiii. 9). Humble your soul before the Lord, and expect from His hands whatever you seek.

\"Give me, O Lord,\" exclaims St. Augustine, \"the treasure of humility.\" Humility is a treasure, because upon the humble the Lord pours every blessing in abundance. A heart full of self cannot be replenished with the gifts of God. To receive the Divine favours, the soul must be first emptied by the knowledge of her own nothingness. *Thou sendest forth*, says David, *springs in the vales: between the midst of the hills the waters shall pass* (Ps. viii. 10). God makes the waters of His graces abound in the valleys, that is, in humble souls, but not on the mountains, the emblems of the proud and the haughty. In the midst of these, His graces pass, but remain not on them. *Because*, says Mary, *he hath regarded the humility of his handmaid \... He that is mighty hath done great things to me* (Luke i. 48, 49). The Lord, looking upon my humility, and my sense of nothingness, hath bestowed great favours on me.

## Evening Meditation

*CONFORMITY TO THE WILL OF GOD*

XIV\. SPECIAL PRACTICES OF THIS VIRTUE

I.

We must bring our will into conformity to the Divine Will even as regards our degree of grace and of glory. Highly as we ought to esteem the glory of God, we ought to esteem His will yet more. It would be good to desire to love God more than the very Seraphim, but it would not be right to desire to ascend to a higher degree of love than what the Lord has determined for us. Blessed John of Avila says: \"I do not think there ever was a Saint who succeeded in becoming as holy as he had wished to be. But that never disturbed a Saint, because Saints wish to become holy only to please God, and not for their own satisfaction. Therefore, they were satisfied with that degree of holiness to which God\'s grace raised them, even though it was not as high as what they aimed at. They believed that there was more true love in being content with what God gave than in wishing for more.\"

All this means, as Father Rodriguez explains it, that we should be diligent in trying to reach the highest perfection possible so as not to turn our own lukewarmness and laziness into an excuse, as those do who say that God must make them a present of holiness if He wants them to be holy, since they themselves can do little or nothing. Nevertheless, when we fail in our efforts we must not lose our peace of mind, nor our conformity to God\'s will, nor our courage. God\'s will permits our fall. What we have to do is to rise at once, to humble ourselves by repentance, and with greater earnest than ever in prayer pursue the way of perfection.

It would, moreover, be but too evident a fault to desire to possess gifts of supernatural prayer \-- such, especially, as ecstasies, visions, and revelations; whereas, on the contrary, spiritual writers say that those souls on whom God bestows such graces ought to pray to Him to deprive them of them, in order that they may love Him by the way of pure Faith, which is the safest way of all. There are many who have attained perfection without these supernatural favours. Chief amongst the virtues that raise the soul to highest sanctity stands conformity to the will of God. If God does not choose to raise us to a high degree of perfection and of glory, let us conform ourselves in all respects to His holy will, praying that He would at least save us through His mercy. And if we act in this manner, the reward will not be small which, of His goodness, our good Lord will give us, for above everything He loves those souls that are resigned.

II\.

In short, we ought to regard whatever comes to us as proceeding from God\'s hand, and everything we do we should direct to this one end, the fulfilment of God\'s will, and to do it simply because God wills it to be done. And in order to proceed with greater security in this, we must follow the guidance of our superiors as regards what is external, and of our directors with regard to what is internal, that so we may, through them, understand what God desires of us, having great faith in those words of Jesus Christ: *He that heareth you heareth me* (Luke x. 16). And, above all, let it be our study to serve God in the way it is His will that we should serve Him. I say this, that we may not deceive ourselves as many do who say: \"Oh, if I were in a desert; if I could enter into a monastery; if I could go somewhere, and not have to remain in this house, away from these relatives or these companions of mine \-- I would sanctify myself; I would do so much penance; I would say so many prayers.\" He says: \"I would do this; I would do that\"; but in the meantime, as he bears with a bad will the cross God sends him, and does not walk in the way God wills, he not only does not sanctify himself, but goes from bad to worse. These desires are mere temptations of the devil, for they are not in accordance with the will of God; we must, therefore, drive them away, and brace ourselves up to the service of God in that one way which He has set before us. By doing His will, we shall certainly sanctify ourselves in any state wherein God places us. Let us, then, ever will only that which God wills, so that He may take and press us to His Heart; and, for this end, let us make ourselves familiar with some of those passages of Scripture that invite us to unite ourselves ever more and more to the Divine will: *Lord, what wilt thou have me to do?* (Acts ix. 6). My God, tell me what Thou desirest of me; for I desire to do it all. *I am thine: save thou me* (Ps. cxviii. 94). O my Lord, I am no longer mine own, but Thine; do with me whatsoever Thou pleasest. And at such times especially as any very grievous calamity befalls us \-- as in the case of the death of parents, the loss of property, and such like \-- *Yea, Father, for so hath it seemed good in thy sight* (Matt. xi. 26). Yes, my God and my Father, let it be even so; for so it hath pleased Thee. And, above all, let us love that prayer which Jesus Christ has taught us: *Fiat voluntas tua sicut in coelo et in terra! \-- Thy will be done on earth as it is in Heaven!* The Lord told St. Catharine of Genoa that whenever she said the *Our Father*, she was to pay particular attention to these words, and pray that His holy will might be fulfilled by her with the same perfection with which it is fulfilled by the Saints in Heaven. Let us, too, act in this manner, and we shall certainly become saints ourselves.

May the Divine will, and the Blessed and Immaculate Virgin Mary, be ever loved and praised. Amen.

O WILL OF GOD! O WILL DIVINE!

\'Tis Thy good pleasure, not my own,\

In Thee, my God, I love alone;\

And nothing I desire of Thee\

But what Thy goodness wills for me.\

O will of God! O will Divine!\

All, all our love be ever thine.

In love no rival canst Thou bear,\

But Thou art full of tenderest care;\

And fire and sweetness all Divine\

To hearts which once are wholly Thine.\

O will of God! O will Divine!\

All, all our love be ever thine.

In Thee all pure affections live,\

To love Thou dost perfection give;\

While ever burning with desires\

The loving soul to Thee aspires.\

O will of God! O will Divine!\

All, all our love be ever thine.

Thou makest crosses soft and light\

And death itself seem sweet and bright.\

No cross nor fear that soul dismays\

Whose will to Thee united stays.\

O will of God! O will Divine!\

All, all our love be ever thine.

To all the glorious choirs of Heaven\

Their very bliss by Thee is given;\

And Heaven itself deprived of Thee\

Would be a land of misery.\

O will of God! O will Divine!\

All, all our love be ever thine.

Yea, to the lost who burn in hell,\

If in their souls Thy love could dwell,\

The very flames and torments there\

Would seem but sweet and light to bear.\

O will of God! O will Divine!\

All, all our love be ever thine.

Oh! that one day my life may end\

In closest bonds to Thee enchained\

For thus to die is not to die,\

But live, and live eternally.\

O will of God! O will Divine!\

All, all our love be ever thine.

To Thee I consecrate and give\

My heart and being while I live;\

Jesus, Thy Heart alone shall be\

My Love for all eternity.\

O will of God! O will Divine!\

All, all our love be ever thine.

Alike in pleasure and in pain\

To please Thee is my joy and gain;\

That, O my Love, which pleases Thee\

Shall ever more seem best to me.\

May heaven and earth with love fulfil,\

My God, Thy ever-blessed will!
