# Friday in Easter Week

### (First Friday of April)

## Morning Meditation

\"THE CLEFTS OF THE ROCK.\"

Oh, what a safe place of refuge shall we not find in the sacred \"clefts of the rock,\" that is to say, in the Wounds of Jesus Christ? \"The clefts of the rock,\" says St. Peter Damian, \"are the Redeemer\'s Wounds; in these my soul has placed its hope.\"

I.

There is no means which can more surely kindle in us Divine love than to consider the Passion of Jesus Christ. St. Bonaventure says that the Wounds of Jesus Christ, because they are Wounds of love, are darts which wound hearts the most hard, and flames which set on fire souls the most cold: \"O Wounds, wounding stony hearts, and inflaming frozen minds!\" It is impossible that a soul which believes and thinks on the Passion of the Lord should offend Him and not love Him, nay, rather that it should not run into a holy madness of love, at seeing a God as it were mad for love of us: \"We have seen,\" says St. Laurence Justinian, \"Wisdom infatuated by too much love.\" Hence it is that the Gentiles, as the Apostle says, when hearing him preach the Passion of Jesus crucified, thought it a folly: *We preach Christ crucified, to the Jews indeed a scandal, but to the Gentiles foolishness* (1 Cor. i. 23). How is it possible, said they, that a God, almighty and most happy, such as He Who is preached to us, could have been wiling to die for His creatures?

Ah, my Jesus, if I gaze upon Thy body, without I see only Wounds and Blood. If within in Thy Heart, I find nothing but bitterness and anguish which make Thee suffer the agonies of death. Ah, God enamoured of men, how is it possible that goodness so great, and such a love, should remain so badly corresponded to by men? It is wont to be said that love is repaid by love; but Thy love \-- with what manner of love can it be ever repaid? It would be necessary that a God should die for Thee to make recompense for the love which Thou hast borne towards us in dying for us. O Cross, O Wounds, O Death of Jesus, you bind me closely to love my loving Jesus!

II\.

Behold your Redeemer expiring, and with His dying breath saying: *It is consummated* (John xix. 30). As if He had said: O men, all has been completed and done for your redemption. Love Me, then, since I have nothing more that I can do to make you love Me. My soul, look up at thy Jesus Who is now going to die. Look at those eyes growing dim, that face grown pale, that Heart which is beating with languid pulse, that Body which is now abandoning itself to death: and look at that beautiful Soul which is just on the point of forsaking that Sacred Body. The heavens are darkened, the earth trembles, the sepulchres are opened; signs that now the Maker of the world is about to die. Lo, at last, Jesus, after having commended His Blessed Soul to His Father, first giving a deep sigh from His afflicted Heart, and then bowing His head in sign of the offering of His life, which at this moment He renewed for our salvation, at length, by the violence of His sorrow, expires and renders up His Spirit into the hands of His beloved Father.

Approach, my soul, to this holy Cross. Embrace the feet of thy dead Saviour, and think that He is dead through the love which He bore to thee. Ah, my Jesus, to what has Thy affection towards me reduced Thee? And who, more than I, has enjoyed the fruits of Thy death? Make me, I beseech Thee, understand what love that must have been that a God should die for me, to the end that from this day forth I may love none other than Thee. I love Thee, O greatest Good; O true Lover of my soul, into Thy hands I here commend it. I beseech Thee, by the merits of Thy death, make me to die to all earthly loves, in order that I may love Thee alone, Who art alone worthy of all my love. Mary, my hope, pray to Jesus for me.

Hail, Jesus, our Love, and Mary, our hope!

\"O riven Heart, O Love for me now crucified! Give to my soul repose within Thy wounded side!\"

## Spiritual Reading

CONFESSION.

IV\. \-- PURPOSE OF AMENDMENT: FIRM, UNIVERSAL, EFFICACIOUS.

In the third place, a purpose to sin no more is necesary for a good Confession; and this purpose must be *firm*, *universal*, and *efficacious*.

First, it must be *firm*. Some say: I would wish never more to commit this sin: I would wish never more to offend God. Alas this expression, *I would wish*; denotes that the purpose is not firm. In order to have; a firm purpose, you must say with a resolute will: *I will never more commit this sin: I will never more deliberately offend God.*

Secondly, it must be *universal*. The penitent must purpose to avoid all sins without exception, that is, all mortal sins. With regard to venial sins, it is sufficient for the validity of the Sacrament to have sorrow for one species of them, and to have a firm purpose to avoid it. Spiritual souls should purpose to avoid all deliberate venial sins; and with regard to indeliberate venial sins, it is enough to resolve to guard against them according to the best of their ability; for it is impossible to avoid all indeliberate sins.

Thirdly, the purpose of avoiding sin must be *efficacious*; that is, it must make the penitent adopt the means of not relapsing into the sins that he confesses, and must make him avoid the proximate occasions of a relapse. An occasion is called proximate in which a person has frequently fallen into grievous sin, or has been, without a just cause, an occasion of sin to others. It is not enough for penitents to purpose merely to renounce sin: it is necessary also to resolve to remove the occasion of it; otherwise all their confessions, though they should receive a thousand absolutions, will be invalid: for not to remove the proximate occasion of mortal sin is in itself a mortal sin. And, as I have already shown in my *Moral Theology* (Lib. 6, n. 454), he that receives absolution without a firm purpose of removing the proximate occasion of mortal sins, commits a new mortal sin, and is guilty of sacrilege.

But some one may say: If I separate from such a person, if I give up such a familiarity, scandal will be the consequence, and it will be an occasion of talk. I answer: You are wrong; you will, on the contrary, give scandal by not removing the occasion, to those who are aware of the friendship; and be assured, that although they may not speak in your presence, they think your conduct deserving of blame. But you will say: To separate from such a one would be an act of incivility, and even of ingratitude, for such a one assists, serves me, and relieves me. Yes, such a one helps to remove you from God, and to make you lead an unhappy life here, and a more unhappy life hereafter. Is it incivility or ingratitude to avoid such a person?

Civility and gratitude are first due to Jesus Christ, Who is a Sovereign of infinite Majesty, and from Whom we have received immense benefits. Do you not then see that it is passion makes you speak in this manner, and makes you seek pretexts in order to bring you to eternal perdition? Ah! give no more pain to the Heart of Jesus Christ. To St. Ludgard, while she was miserably entangled in a dangerous friendship, Jesus appeared, and showed her His Heart grievously wounded. The Saint began to weep over her fault, and took leave of her friend, saying that she could love no other than Jesus Christ, to Whom she had been espoused. Thenceforward she consecrated herself entirely to the love of her Spouse, and became a Saint.

## Evening Meditation.

THE PRACTICE OF THE LOVE OF JESUS CHRIST.

III\. \-- HOW DESERVING JESUS CHRIST IS OF OUR LOVE ON ACCOUNT OF THE LOVE HE HAS SHOWN US IN HIS PASSION.

I.

The Divine Son of God, through His love towards us, has given Himself wholly to us: *Who loved me, and delivered himself for me* (Gal. 20). In order to redeem us from everlasting death, and to recover for us the Divine grace and Heaven which we had forfeited, He became Man, and assumed flesh like our own: *Et verbum caro factum est; And the word was made flesh.* Behold, then, a God reduced to nothingness: *But emptied himself, taking the form of a servant\... and in habit found as a man* (Philipp. 7). Behold the Sovereign Lord of the world humbling Himself so low as to subject Himself to all the miseries which the rest of men endure.

But what is more astonishing still is that He could very well have saved us without dying and without suffering at all; and yet He chose a life of sorrow and contempt, and a death of bitterness and ignominy even so far as to expire on a Cross \-- the gibbet of infamy, the award of vilest criminals: *He humbled himself, becoming obedient unto death, even to the death of the cross* (Philipp. ii. 8). But why, if He could have ransomed us without suffering, why should He choose to die, and to die on a Cross? To show us how He loved us. Who loved me, and delivered himself far me. He loved us, and because He loved us He delivered Himself up to sorrows, and ignominies, and to a death more cruel than ever any man endured in this world.

II\.

That great lover of Jesus Christ, St. Paul, has written: *The charity of Christ presseth us* (2 Cor. v. 14); wishing to show us by these words that it is not so much the sufferings themselves of Jesus Christ as His love in enduring them that obliges us and, as it were, constrains us to love Him. Let us hear what St. Francis de Sales says on this text: \"When we remember that Jesus Christ, true God, has loved us to such an excess as to suffer death, and the death of the Cross for us, our hearts are, as it were, put in a wine-press, and suffer violence, until love be extorted from them; but a violence which, the stronger it is, becomes the more delightful.\" He then goes an to say: \"Ah! why do we not therefore cast ourselves on Jesus crucified, to die on the Cross with Him, Who has chosen to die for love of us? I will hold Him, we should say, and I will never let Him go; I will die with Him, and will be consumed in the flames of His love. One flame shall consume this Divine Creator and His miserable creature. My Jesus gives Himself unreservedly to me, and I will give myself unreservedly to Him. I will live and die on His loving Breast; neither life nor death shall ever separate me from Him. O eternal Lover my soul longs after Thee, and makes choice of Thee for ever! Come, O Holy Spirit, and inflame our hearts with love. O love, O death, to die to all other loves, to live solely to that of Jesus Christ! O Redeemer of our Souls, grant that we may eternally sing: \'Live, Jesus! I love Jesus; live, Jesus, Whom I love! Yes, I love Jesus, Who reigns for evermore.\'\"
