# Monday\--Sixth Week after Pentecost

## Morning Meditation

*OUR JOURNEY INTO ETERNITY\--THE FOLLY OF THOSE WHO DO NOT CONSIDER IT*

O my God, the months and years pass! We are hastening towards Eternity and we do not concern ourselves to think about it! And who knows but this may be the last warning I may receive from God!

I.

Either we believe or we do not believe. If we do not believe, we are doing too much for things we regard as fables. But if we do believe, then we do too little to obtain a happy Eternity, and to avoid eternal misery.

Father Vincent Carafa said that if men thoroughly knew the Truths of Eternity, and compared the goods and evils of this life with those of the next, the earth would become a desert, because there would be none at all who would attend to the affairs of this world.

When the last moment is near at hand, how we shall tremble at the thought that on that moment will depend our eternal happiness or misery!

O my God, the months and years pass! We are hastening towards eternity, and we do not concern ourselves to think about it! And who knows but that this year or month may be my last? Who knows but that this may be the last warning I may receive from God?

O my God, I will no longer abuse Thy graces! Behold, I am ready! Make known to me what Thou wouldst have me do, and in all things I will obey Thee.

And why should we delay after so many lights and calls from God, unless we desire to lament with the damned, saying: *The summer is ended, and we are not saved* (Jer. viii. 20). Now is the time for reconciliation with God, for after death no remedy will be left.

With good reason did Father John of Avila say that Christians who believe eternal life, and live at a distance from God, ought to be shut up in an asylum as insane.

The business of Eternity is indeed important. It is not whether we shall inhabit a house more or less commodious or lightsome; but whether we shall dwell in a palace of all delights, or in an abyss of the most terrible torments. It is whether we shall be happy with the Saints and Angels, or live in despair with the multitude of the enemies of God. And for how many years? For a thousand? No; forever, forever, as long as God shall be God.

If, then, O God, I had died in my sins, should I not have lost Thee forever? If as yet, O Lord, Thou hast not pardoned me, pardon me now, I beseech Thee. I love Thee with all my soul, and I am sorry above every other evil for having offended Thee. I will never lose Thee more. I love Thee with all my heart, and will forever love Thee. Have pity on me.

II\.

There are many upon whom, during life, it makes little impression to hear of Judgment, Hell, Eternity. But in death what dread and terror do these Truths excite! But, alas! with but little fruit; because then they serve only to increase their remorse and confusion.

St. Teresa used to say to her Religious: \"Daughters, one soul, one Eternity!\" By which she meant that if the soul is lost, all is lost, and that the soul once lost, is lost forever.

O Lord, wait yet awhile, that I may weep for my sins. Too many years have I spent in displeasing Thee! The time which yet remains to me shall be given all to Thee. Accept of me, that I may serve Thee, O my God, my God!

The Lord waits for us; let us highly prize the time which, in His mercy, He bestows upon us, that we may not have to lament when for us time shall be no more.

O God, what would not a dying man give for another day, or even another hour! Another day or hour in his sound senses! Alas, the time which remains to the dying man is but little adapted to the settling of the affairs of conscience. Giddiness of head, pains of body, oppressions at the chest, hinder the mind from doing anything in a proper manner. Then the soul, as it were, buried in obscurity, is alive to nothing but the distress which overpowers it, and which it cannot alleviate. It longs to have a little time, but sees that there is no more time for it.

*At what hour you think not, the Son of Man will come* (Luke xii. 40). God conceals from us the time of death, that we may always be ready. The time of death is not the time to *prepare ourselves* to give an account of our souls, but the time when we should find *ourselves prepared* to do so. St. Bernard said: \"In order to die well, we must be ever prepared to die.\"

O Jesus, too long have I offended Thee! It is surely now time to resolve henceforth to prepare for death. I will no longer abuse Thy patience. I desire to love Thee with all my power. I have very much offended Thee; I desire now to love Thee very much.

## Spiritual Reading

*PRAYER, ITS NECESSITY*

I-IT IS A MEANS NECESSARY FOR SALVATION

One of the errors of Pelagianism was the assertion that *Prayer is not necessary for salvation*. Pelagius, the impious author of that heresy, said that man will only be damned for neglecting to know the truths necessary to be learned. How astonishing! St. Augustine said: \"Pelagius discussed everything except how to pray,\" though, as the Saint held and taught,\--Prayer is the only means of acquiring the science of the Saints, according to the words of St. James: *lf any man want wisdom, let him ask of God, who giveth to all men abundantly, and upbraideth not* (James i. 5).

The Scriptures are clear enough in pointing out how necessary it is to pray, if we would be saved. *We ought always to pray, and not to faint* (Luke xviii. 1). *Watch and pray, that ye enter not into temptation* (Matt. xxvi. 41). *Ask, and it shall be given you* (Matt. vii. 7). The words *we ought, pray, ask*, according to the general consent of Theologians, impose the precept, and denote the *Necessity of Prayer*. Wickliffe said that these texts are to be understood, not of the necessity of Prayer, but of the *necessity of good works*, for in his system Prayer was only well-doing; but this was his error, and was expressly condemned by the Church. Hence Lessius wrote that it is heresy to deny that Prayer is necessary for salvation in adults, as it is evident from Scripture that Prayer is the means, without which we cannot obtain the help necessary for salvation.

The reason of this is clear. Without the assistance of God\'s grace we can do no good work: *Without me, ye can do nothing* (John xv. 5). St. Augustine remarks on this passage that our Lord did not say: \"Without Me, *ye can complete nothing*,\" but, \"*Without Me, ye can do nothing*\"; giving us to understand, that without grace we cannot even begin to do a good work. Nay more, St. Paul writes, that of ourselves we cannot even have the wish to do good. *Not that we are sufficient to think anything of ourselves \... but our sufficiency is from God* (2 Cor. 6). If we cannot even think a good thought, much less can we wish to carry it out. The same thing is taught in many other passages of Scripture: *God worketh all in all* (1 Cor. xii. 6). *I will cause you to walk in my commandments, and to keep my judgments, and do them* (Ezech. xxxvi. 27). So that, as St. Leo I. says: \"Man does no good thing, except that which God, by His grace, enables him to do\"; and hence the Council of Trent says: \"If any one shall assert that without the previous inspiration of the Holy Ghost, and His assistance, man can believe, hope, Love, or repent, as he ought, in order to obtain the grace of justification, let him be anathema.\"

The author of the *Opus Imperfectum* says that God has given to some animals swiftness, to others claws, to others wings, for the preservation of their life; but He has so formed man that God Himself is his only strength. So that man is absolutely unable to provide for his own safety, since God has willed that whatever he has, or can have, should come entirely from the assistance of His grace.

But this grace is not given in God\'s ordinary Providence, except to those who pray for it; according to the celebrated saying of Gennadius, \"We believe that no one comes to be saved, except at the invitation of God; that no one who is invited works out his salvation, except by the help of God; that no one merits this help, unless he prays.\" From these two premises, first, that *we can do nothing without the assistance of grace*; and secondly, *that this assistance is only given ordinarily by God to the man that prays*\--who does not see that the consequence follows, that *prayer is absolutely necessary to us for salvation*? And although the first graces that come to us without any co-operation on our part, such as the call to Faith or to penance, are, as St. Augustine says, granted by God even to those who do not pray; yet the Saint considers it certain that the other graces, and specially the grace of perseverance, are not granted except in answer to Prayer: \"God gives us some things, as the beginning of Faith, even when we do not pray. Other things, such as perseverance, He has only provided for those who pray.\"

Hence it is that the generality of Theologians, following St. Basil, St. Chrysostom, Clement of Alexandria, St. Augustine, and other Fathers, teach that Prayer is necessary to adults, not only because of the obligation of the precept, as we have seen, but because Prayer is necessary as a means of salvation. That is to say, in the ordinary course of Providence, it is impossible that a Christian should be saved without recommending himself to God, and asking for the graces necessary for salvation. St. Thomas teaches the same: \"After Baptism, continual Prayer is necessary for man, in order that he may enter Heaven; for though by Baptism our sins are remitted, there still remain concupiscence to assail us from within, and the world and the devil to assail us from without.\" The reason, then, which makes us certain of the necessity of Prayer is briefly this: In order to be saved we must fight and conquer: *He that striveth for the mastery is not crowned except he strive lawfully* (2 Tim. 5). But without the Divine assistance we cannot resist the might of so many and such powerful enemies; now this assistance is granted only to Prayer; therefore, without Prayer there is no salvation.

Moreover, that Prayer is the only ordinary means of receiving the Divine gift, is very distinctly proved by St. Thomas in another place, where he says that whatever graces God has from all eternity determined to give us, He will only give them if we pray for them. St. Gregory says the same thing: \"Man by Prayer merits to receive that which God had from all eternity determined to give him.\" Not, says St. Thomas, that Prayer is necessary in order that God may know our necessities, but in order that we may know the necessity of having recourse to God to obtain the help necessary for our salvation, and may thus acknowledge Him to be the Author of all our good. As, therefore, it is God\'s law that we should provide ourselves with bread by sowing corn, and wine by planting vines, so has He ordained that we should receive the graces necessary to salvation by means of Prayer: *Ask and it shall be given you; seek, and ye shall find* (Matt. vii. 7).

We, in a word, are merely beggars, who have nothing but what God bestows on us as alms: *But I am a beggar and poor* (Ps. xxxix. 18). The Lord, says St. Augustine, desires and wills to pour forth His graces upon us, but does not give them except to him who prays. \"God wishes to give, but only to him who asks.\" This is declared in the words, *Ask, and it shall be given to you*. Whence it follows, says St. Teresa, that he who seeks not, does not receive. As moisture is necessary for the life of plants, to prevent them from drying up, so, says St. Chrysostom, is Prayer necessary for our salvation. Or, as he says in another place, Prayer vivifies the soul as the soul vivifies the body: \"As the body without the soul cannot live, so the soul without Prayer is dead and emits an offensive odour.\" \"*Graviter olens*.\" He uses these words because the man who omits to recommend himself to God at once begins to be defiled with sins. Prayer is also called the food of the soul, because the body cannot be supported without food; nor can the soul, says St. Augustine, be kept alive without Prayer: \"As the flesh is nourished by food, so is man supported by prayers \" All these comparisons used by the holy Fathers are intended by them to teach *the absolute necessity of Prayer for the salvation of every one*.

## Evening Meditation

*THE PRACTICE OF THE LOVE OF JESUS CHRIST*

*\"Charity believeth all things\"*

HE THAT LOVES JESUS CHRIST BELIEVES ALL HIS WORDS

I.

Whoever loves a person believes all that proceeds from the lips of that person; consequently, the more a soul loves Jesus Christ, the more lively and unshaken is her Faith. When the Good Thief beheld our Redeemer, though He had done no ill, suffering death upon the Cross with such patience, he began at once to love Him; under the influence of this love, and of the Divine light which then broke upon his soul, he believed that Jesus was truly the Son of God, and begged not to be forgotten by Him when He should have passed into His Kingdom.

Faith is the foundation of Charity; but Faith afterwards receives its perfection from Charity. His Faith is most perfect whose love of God is most perfect. Charity produces in man not merely the Faith of the understanding, but the Faith of the will also; those who believe only with the understanding, but not with the will, as is the case with sinners who are perfectly convinced of the Truths of the Faith, but do not choose to live according to the Divine Commandments\--such as these have a very weak Faith; for had they a more lively belief that the grace of God is a priceless treasure, and that sin, because it robs us of this grace, is the worst of evils, they would assuredly change their lives. If, then, they prefer the miserable creatures of this earth to God, it is because they either do not believe or because their Faith is very weak. On the contrary, he who believes not only with the understanding but also with the will, so that he not only believes in God but has the will to believe in Him, the Revealer of truth, from the love he has for Him, and rejoices in so believing\--such a one has a perfect Faith, and consequently seeks to make his life conformable to the truths he believes.

Weakness of Faith, however, in those who live in sin, does not spring from the obscurity of Faith; for though God, in order to make our Faith more meritorious, has veiled the objects of Faith in darkness and secrecy, He has at the same time given us so clear and convincing evidence of their truth, that not to believe them would argue not merely a lack of sense, but sheer madness and impiety. The weakness of the Faith of many persons is to be traced to their wickedness of living. He who, rather than forego the enjoyment of forbidden pleasures, scorns the Divine friendship, would wish there was no law to forbid, and no chastisement to punish, his sin. On this account he strives to blind himself to the eternal truths of Death, Judgment, and Hell, and of Divine justice; and because such subjects strike too much terror into his heart, and are too apt to mix bitterness in his cup of pleasure, he sets his brain to work to discover proofs, which have at least the look of plausibility; and by which he allows himself to be flattered into the persuasion that there is no soul, no God, no hell, in order that he may live and die like the brute beast, without law and without reason.
