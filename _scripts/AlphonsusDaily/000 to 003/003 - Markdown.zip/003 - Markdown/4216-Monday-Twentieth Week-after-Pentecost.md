# Monday\--Twentieth Week after Pentecost

## Morning Meditation

*ST. TERESA\'S PRECIOUS DEATH*

The dying Saint conversed lovingly with her Divine Spouse: \"O my Lord, and my Spouse, the hour so earnestly longed for has at last arrived! It is time now that we should see each other, O Lord! The day has dawned at last when I am to leave my place of exile to go to share with Thee in that joy which I have so ardently desired.\"

I.

The holy Mother Teresa, on leaving Burgos, was desirous of going to her dear convent of Avila, that she might rest awhile in that her first and favourite abode, where she began her reform; but her heavenly Spouse summoned her to another home, and to eternal repose. The Lord wished to have her in the land of the Blessed; therefore He permitted that, as she was on her way, her Provincial should send her an order to repair to the convent of Alba. There God was awaiting her, to deliver her from the prison of this life, and to conduct her to the everlasting nuptials.

Come, O my Saint! Come! your Spouse deems that your labours have now been sufficient; and His Heart is touched with compassion by your sighs. Come to the repose that you desire; come to the haven after having encountered the storm. Come to begin that new life of love which you will enter by a death of love, which the Lord is preparing for you in this favoured spot.

The Saint obeyed, and reached Alba on St. Matthew\'s Day, at six o\'clock in the evening, in the year 1582. Her daughters welcomed her with great reverence and great affection, perhaps not without some presentiment that they should lose her before long. They received her benediction and kissed her hand, whilst the Saint was tenderly and affectionately speaking with them.

When she arrived she was fatigued from her journey, and unwell from an attack of fever; so that she retired immediately to her bed at the entreaty of her children with these words: \"Oh! may God assist me, my dear daughters, as I feel quite overpowered! It is now more than twenty years since I retired to rest at so early an hour. Blessed be the Lord that my sickness has fallen upon me while I am amongst you.\"

During the eight subsequent days her illness continued, but she never allowed it to prevent her from rising to receive her Jesus in Holy Communion, Who was to her the only Life of her life.

But, on St. Michael\'s day, still suffering from the sickness that was to bring her to her grave, she took to her bed in the infirmary, never more to leave it. There she remained for a day and a night in an ecstasy of prayer, and having learned then through a revelation, the hour and the moment of her decease, she told the Venerable Sister Ann of St. Bartholomew, her beloved companion in all her travels, that the hour of her departure had come. Three days before her death, when Father Anthony of Jesus had come to hear her confession, he told her to pray to God to preserve her life for the good of the Reform; but the Saint replied that there was no longer any need to think of this, because her death was a certainty, and her presence upon earth was no longer necessary. The doctors ordered her to be bled, and to this she willingly submitted, not out of any desire for recovery, but from the fervent wish she had to suffer, and to close her life in the midst of sufferings, as she had ever desired, for the love of her dearest Spouse, Whose will it had been to expire amidst so many torments on the Cross.

On the eve of the Feast of St. Francis, she asked for the Most Holy Viaticum, and whilst they were bringing It, all her Religious being assembled in her chamber, she burst into tears, and clasping her hands together, said to them: \"My daughters and my mothers, pardon me for the bad example I have set you, and do not imitate me who am the greatest sinner in the world, and who have observed my Rule less than all others. For the love of God, my children, I pray you to observe that Rule perfectly, and to be obedient to your Superiors.\" She who had been so great a lover of obedience, recommended nothing but this virtue when at the point of death, knowing, as she did, that the perfection of Religious depends on the perfection of their obedience.

II\.

The Holy Viaticum having been brought, she had the courage, at the coming of her Spouse, to raise herself into a sitting posture, although her feebleness was such that she could scarcely stir. The ardour with which her love inspired her was so great that she appeared ready to throw herself from her bed to go to meet the only Beloved of her soul, and receive Him. Her countenance became so inflamed and radiant that they could not gaze upon her. She clasped her hands together, burning, like the phoenix, with the liveliest ardour the nearer she approached the end of her life, and the more she lovingly conversed with her Spouse, so that she drew tears from all present. Amongst other things, she said: \"O my Lord and my Spouse, the hour so earnestly longed for has at last arrived! It is time now that we should see each other, O Lord! The day has dawned at last when I am to leave my place of exile to go to share with Thee in that joy which I have so ardently desired.\"

What gave her most consolation in that hour, and chiefly called forth her thankfulness towards God, was the fact of her being a child of the Holy Church. She could not refrain from saying over and over again: *After all, O Lord, I am a daughter of the Church*. She also frequently repeated the versicle of David: *A contrite and humbled heart, O God, thou wilt not despise* (Ps. 1. 19). On the following day, after receiving Extreme Unction, she held the Crucifix tight in her embrace, and remained fourteen hours in an ecstasy, with a countenance shining like fire, and immovable, beginning from that time to experience a foretaste of the great glory God had prepared for her in Heaven, where her Spouse was summoning her in these words: *Arise, make haste, my love \... and come* (Cant. ii. 10). Then it was that, before the Saint expired, Sister Ann, her companion, saw her Spouse, Jesus, and a multitude of angels, come and take up their position at the foot of her bed, awaiting the moment when they should conduct her to Heaven. Beside Teresa\'s bed was her sweet Mother Mary and St. Joseph, her beloved Father. Lastly, she saw a multitude of persons, clothed in white and all shining with light, entering with great joy into the cell of the dying Saint. It is supposed that these were the Ten Thousand Martyrs\* who had promised her that they would accompany her to Paradise. They drew near at the moment when Teresa, her beautiful life being consumed in a furnace of love, expired sweetly through the force of that love. Her blessed soul issued forth from its prison and flew away like a dove to its Beloved in Paradise. Indeed, at the very moment they saw her soul, as a white dove, flying to Heaven. At the same time she appeared in glory to Sister Catharine of Jesus, and told her that her life had been terminated through the vehemence of her love, and that she had gone to rejoice in God. Her virgin body forthwith exhaled a delightful fragrance, which diffused itself throughout the whole convent.

\*Of whom mention is made in the Martyrology on June 22. \-- ED.

Behold what a blessed reward the labours of the Saints receive at the hour of death! While sinners experience at death sadness, confusion, remorse, despair \-- the foretaste of their damnation \-- the Saints, on the contrary, are filled with confidence, peace, light and joy \-- a foretaste of Paradise. Come, ye senseless ones, come and see in this poor cell of Teresa, how contentedly those die, and leave this earth, who have already abandoned the world to give themselves wholly to God.

Oh, devout soul, fail not to keep your eyes on the closing scenes that will take place at the hour of your own death. Do now what you will wish to have done, but will not have the power to do then, and you will become a saint, and your death will be a happy one.

Behold, then, O Teresa, thy sighs are heard, thy desires are fulfilled, thy love satisfied! Thou art now released from banishment and hast reached thy place of rest. Thou art now rejoicing with that Good Who was the object of thy love, loving that God Whom thou didst sigh after. But amidst thy splendours, do not be unmindful of us, wretched as we are. Have compassion on us who go on our way weeping as travellers in this valley of tears, and ever in danger of losing God. For pity sake, address thy Jesus in our behalf that He may pardon the many sins we have committed. Pray to Him to deliver us from every attachment to the things of this world which would hinder us from going to join thee in loving God in Paradise.

## Spiritual Reading

LITTLE CHAPLET IN HONOUR OF ST. TERESA\
*(To be recited every day during the Novena.)*

I.

O most amiable Lord, Jesus Christ, we thank Thee for the great gift of Faith and of devotion to the Holy Sacrament, which Thou didst grant to Thy beloved Teresa. We pray Thee, by Thy merits, and by those of Thy faithful spouse, to grant us the gift of a lively Faith and of a fervent devotion towards the most Holy Sacrament of the altar where Thou, O infinite Majesty, hast obliged Thyself to abide with us even to the end of the world, and wherein Thou dost so lovingly give Thy whole self to us.

*Our Father, Hail Mary,* and *Glory,* etc.

O Jesus, Who didst pierce with love\

Teresa\'s beauteous heart,\

Of her sweet love upon my soul\

Let fall a flaming dart.

II\.

O most merciful Lord, Jesus Christ, we thank Thee for the great gift of Hope which Thou didst grant to Thy beloved Teresa. We pray Thee, by Thy merits, and by those of Thy holy spouse, to give us a great confidence in Thy goodness, by reason of Thy Precious Blood, that Thou hast shed to its last drop for our salvation.

*Our Father, Hail Mary,* and *Glory,* etc.

O Jesus, Who didst pierce with love\

Teresa\'s beauteous heart,\

Of her sweet love upon my soul\

Let fall a flaming dart.

III\.

O most loving Lord, Jesus Christ, we thank Thee for the great gift of Love which Thou didst grant to Thy beloved Teresa. We pray Thee, by Thy merits, and by those of Thy most loving spouse, to give us the great, the crowning gift of Thy perfect Charity.

*Our Father, Hail Mary,* and *Glory,* etc.

O Jesus, Who didst pierce with love\

Teresa\'s beauteous heart,\

Of her sweet love upon my soul\

Let fall a flaming dart.

IV\.

O most sweet Lord, Jesus Christ, we thank Thee for the gift of great desire and resolution which Thou didst grant to Thy beloved Teresa, that she might love Thee perfectly. We pray Thee, by Thy merits and by those of Thy most generous spouse, to give us a true desire and a true resolution of pleasing Thee to the utmost of our power.

*Our Father, Hail Mary,* and *Glory,* etc.

O Jesus, Who didst pierce with love\

Teresa\'s beauteous heart,\

Of her sweet love upon my soul\

Let fall a flaming dart.

V.

O most kind Lord, Jesus Christ, we thank Thee for the great gift of humility that Thou didst grant to Thy beloved Teresa. We pray Thee, by Thy merits, and by those of Thy most humble spouse, to grant us the grace of a true humility, which may make us ever find our joy in humiliations, and prefer contempt to every honour.

*Our Father, Hail Mary,* and *Glory,* etc.

O Jesus, Who didst pierce with love\

Teresa\'s beauteous heart,\

Of her sweet love upon my soul\

Let fall a flaming dart.

VI\.

O most bountiful Lord, Jesus Christ, we thank Thee for the gift of devotion towards Thy sweet Mother, Mary, and her holy spouse, Joseph, which Thou didst grant to Thy beloved Teresa. We pray Thee, by Thy merits, and by those of Thy most dear spouse, to give us the grace of a special and tender devotion towards Thy most holy Mother, Mary, and towards Thy beloved foster-father, Joseph.

*Our Father, Hail Mary,* and *Glory,* etc.

O Jesus, Who didst pierce with love\

Teresa\'s beauteous heart,\

Of her sweet love upon my soul\

Let fall a flaming dart.

VII\.

O most loving Lord, Jesus Christ, we thank Thee for the wonderful gift of the wound in the heart that Thou didst grant to Thy beloved Teresa. We pray Thee, by Thy merits, and by those of Thy seraphic spouse, to grant us also a like wound of love, that, henceforth, we may love Thee, and give our mind to the love of nothing but Thee.

*Our Father, Hail Mary,* and *Glory,* etc.

O Jesus, Who didst pierce with love\

Teresa\'s beauteous heart,\

Of her sweet love upon my soul\

Let fall a flaming dart.

VIII\.

O most beloved Lord, Jesus Christ, we thank Thee for the eminent gift of the desire for death which Thou didst grant to Thy beloved Teresa. We pray Thee, by Thy merits, and by those of Thy most constant spouse, to grant us the grace of desiring death, in order to go and possess Thee eternally in the country of the Blessed.

*Our Father, Hail Mary,* and *Glory,* etc.

O Jesus, Who didst pierce with love\

Teresa\'s beauteous heart,\

Of her sweet love upon my soul\

Let fall a flaming dart.

IX\.

Lastly, O dearest Lord, Jesus Christ, we thank Thee for the gift of the precious death which Thou didst grant to Thy beloved Teresa, giving her to die a sweet death of love. We pray Thee, by Thy merits, and by those of Thy most affectionate spouse, to grant us a good death; and that if we do not die of love, we may, at least, die burning with love for Thee, that so dying, we may be able to go and love Thee for evermore with a perfect love in Heaven.

*Our Father, Hail Mary,* and *Glory,* etc.

O Jesus, Who didst pierce with love\

Teresa\'s beauteous heart,\

Of her sweet love upon my soul\

Let fall a flaming dart.

## Evening Meditation

*CONFORMITY TO THE WILL OF GOD*

VII\. GOD WISHES ONLY OUR GOOD.

I.

What greater satisfaction can a soul enjoy than in knowing that by suffering with a good will whatever it may have to suffer, it gives to God the greatest pleasure it can give Him? The masters of the spiritual life teach that, though the desire which certain souls have of suffering to give God pleasure is acceptable to Him, He is yet more pleased with the conformity of those who wish for neither joy nor pain, but, in perfect resignation to His holy will, have no other desire than to fulfill whatever the will of God may be.

If, then, O devout soul, you would please God, and live a life of contentment, unite yourself always and in everything to the Divine will. Consider that all the sins you have committed, when leading a life of disorder and unhappiness, have come to pass in consequence of having separated yourself from the will of God. Unite yourself from this day forward, with His good pleasure; and always say, in everything that may befall you: *Yea, Father; for so hath it seemed good in thy sight* (Matt. xi. 26). So may it be, O Lord, as it is pleasing unto Thee. Whenever you are troubled on account of some adversity, consider that it has come from God; and therefore say at once: \"God wills it so\" \-- and remain in peace. *I was dumb, and I opened not my mouth, because thou hast done it* (Ps. xxxviii. 10). To this end you must direct all your thoughts and prayers to God, in Meditations, in Communions, in Visits to the Most Holy Sacrament, that He would make you accomplish His will. Strive to make continually an offering of yourself, saying: O my God, behold, here I am; do what Thou willest with me, and with all that I have. This was St. Teresa\'s continual exercise; fifty times a day at least did the Saint offer herself to the Lord, that He might dispose of her according to His pleasure.

II\.

Oh, happy will you be if you act ever thus! You will certainly become a saint; your life will be peaceful, and your death most happy. When any one is passing to the other life, our hopes of his salvation depend on whether he has died resigned or not. If, after having during life welcomed all things as coming from God, you in like manner embrace death also in order to accomplish the Divine will, you will certainly secure your salvation and die the death of a saint. Let us, then, abandon ourselves in everything to the good pleasure of that Lord Who, being most wise, knows what is best for us; and being most loving, since He has sacrificed His life through love of us, wills also that which is most for our good. Let us be thoroughly assured and convinced that God works for our good incomparably beyond all we can do or desire for ourselves.
