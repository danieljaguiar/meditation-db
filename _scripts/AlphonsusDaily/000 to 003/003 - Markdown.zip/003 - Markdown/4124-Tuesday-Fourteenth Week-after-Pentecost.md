# Tuesday\--Fourteenth Week after Pentecost

## Morning Meditation

*THE CERTAINTY OF BEING SAVED OR LOST*

God desires all men to be saved, and He gives His graces to all, but many will not use these means of salvation and are lost, for \"Heaven is not for the slothful.\"

I.

*With fear and trembling work out your salvation*, wrote St. Paul to the Philippians (Phil. ii. 12). In order to be saved we should tremble lest we be lost, for there is no middle course. We must be either saved or lost forever. He who trembles not is in great danger of being lost, because he takes but little care to employ the means of obtaining salvation. God desires that all should be saved, and He gives to all His grace; but He requires that all should co-operate for this end. All desire to be saved, yet multitudes, because they will not employ the means of salvation, are lost. St. Philip Neri used to say: *Heaven is not made for the slothful*.

Enlighten me, O Lord, that I may know what I ought to do, and what to avoid, for I desire to do all Thou requirest of me. I am determined, by Thy grace, to save my soul.

St. Teresa said to her Religious: *One soul*! my daughters, one *Eternity*! She meant that in this world we ought not to attend to anything but the salvation of our souls; because if the soul be lost, all is lost; and if once lost, it is lost forever! Benedict XII, being asked by a prince for a favour that he could not grant without committing sin, answered the ambassador: \"Tell your prince that if I had two souls I would give him one; but as I have only one I cannot consent to lose it for his sake.\" Thus should we answer the devil or the world when they offer us forbidden fruit.

O God, how often have I lost my soul by forfeiting Thy grace! But since Thou offerest me pardon, I detest all the offences I have committed against Thee, and will love Thee above all things.

II\.

Would that we were fully impressed with the meaning of that great maxim of St. Francis Xavier: *There is but one evil, and there is but one good in the world!* The only evil is damnation; the only good, salvation. Poverty, infirmity, ignominies are not evils. No; for these when embraced with resignation will increase our glory in Heaven. On the other hand, health, riches, and honours are not really *goods* for too many Christians, because they become to them greater occasion of losing their souls.

Save me, then, O my God, and do with me what Thou pleasest. Thou knowest and willest what is best for me. I abandon myself to Thy mercy: *Into thy hands, O Lord, I commend my spirit* (Ps. xxx. 6). I am sorry for having been hitherto opposed to Thy will, and am ready to die in order to expiate my offences; but now I love Thee, and wish for nothing but what Thou willest. Grant me Thy love, that I may be faithful to Thee. And Mary, give me thy powerful assistance.

## Spiritual Reading

*THE EVIL EFFECTS OF A BAD HABIT*

I.-IT BLINDS THE UNDERSTANDING.

Speaking of those who live in the habit of sin, St. Augustine says: \"The very habit itself does not allow them to see the evil they do.\" The habit of sin blinds sinners, so that they no longer see the evil which they do, nor the ruin which they bring upon themselves; hence they live in blindness as if there was neither God, nor Heaven, nor hell, nor eternity. \"Sins,\" adds the Saint, \"however enormous, when habitual, appear to be small, or not to be sins at all.\" How, then, can the soul guard against them when she is no longer sensible of their deformity, or the evil which they bring upon her?

St. Jerome says that habitual sinners \"are not even ashamed of their crimes.\" Bad actions naturally produce a certain shame; but this feeling is destroyed by the habit of sin. St. Peter compares habitual sinners to swine wallowing in mire. *The sow that was washed is returned to her wallowing in the mire* (2 Pet. ii. 22). The very mire of sin blinds them; and, therefore, instead of feeling sorrow and shame at their uncleanness, they revel and exult in it. *A fool worketh mischief as it were for sport* (Prov. x. 23). *They are glad when they have done evil* (Prov. ii. 14). Hence the Saints continually seek light from God; for they know that, should He withdraw His light, they may become the greatest of sinners. How, then, do so many Christians, who know by Faith that there is a hell, and a just God Who cannot but chastise the wicked, how, I say, do they continue to live in sin till death, and thus bring themselves to perdition? *Their own malice blinded them* (Wis. 21). Sin blinds them, and thus they are lost.

Job says that habitual sinners are full of inquities. *His bones shall be filled with the vices of his youth* (Job xx. 11). Every sin produces darkness in the understanding. Hence the more sins are multiplied by a bad habit, the greater the blindness they cause. The light of the sun cannot enter a vessel filled with clay; and a heart full of vices cannot admit the light of God, which would make visible to the soul the abyss into which she is running. Bereft of light, the habitual sinner goes on from sin to sin, without ever thinking of repentance. *The wicked walk round about* (Ps. xi. 9). Fallen into the dark pit of evil habits, he thinks only of sinning, he speaks only of sins, and no longer sees the evil of sin. In fine, he becomes like a brute beast, devoid of reason, and seeks and desires only what pleases the senses. *And man, when he was in honour, did not understand; he is compared to senseless beasts, and is become like to them* (Ps. xlviii. 13). Hence the words of the Wise Man are fufilled with regard to habitual sinners. *The wicked man when he comes into the depth of sins, contemneth* (Prov. xviii. 3). This passage St. John Chrysostom applies to habitual sinners, who, shut up in a pit of darkness, despise sermons, calls of God, admonitions, censures, hell, and God, and become like the vulture that waits to be killed by the fowler, rather than abandon the corrupt carcass on which it feeds.

Let us tremble, as David did when he said: *Let not the tempest of water drown me, nor the deep swallow me up; and let not the pit shut her mouth upon me* (Ps. lxviii. 16). Should a person fall into a pit there is hope of deliverance as long as the mouth of the pit is not closed; but as soon as it is shut, he is lost. When a sinner falls into a bad habit, the mouth of the pit is gradually closed as his sins are multiplied; the moment the mouth of the pit is shut he is abandoned by God. If you have contracted a habit of any sin, endeavour instantly to go out of that pit before God deprives you entirely of His light, and abandons you; for, as soon as He abandons you by the total withdrawal of His light, all is over and you are lost.

## Evening Meditation

*CONSIDERATIONS ON THE PASSION OF JESUS CHRIST*

I.

Jesus came into the world, not only to redeem us, but by His own example to teach us all virtues, and especially humility, and holy poverty which is inseparably united with humility. On this account He chose to be born in a cave; to live a poor Man in a workshop for thirty years; and finally to die, poor and naked, upon a Cross, and seeing His garments divided among the soldiers before He breathed His last. While after His death He had to receive His winding-sheet for burial as an alms from others. Let the poor be consoled, on seeing Jesus Christ, the King of Heaven and earth, thus living and dying in poverty in order to enrich us with His merits and gifts, as the Apostle says: *Being rich he became poor for your sakes, that through his poverty you might be rich* (2 Cor. viii. 9). For this cause, the Saints, to become like Jesus in His poverty, have despised all earthly riches and honours, that they might go one day to enjoy with Jesus Christ the riches and honours prepared by God in Heaven for them that love Him; of which blessings the Apostle says that eye hath not seen, nor ear heard, nor has it entered into the mind of man to conceive what God has prepared for them that love Him. (1 Cor. ii. 9).

II\.

Jesus Christ, then, rose with the glory of possessing all power in Heaven and earth, not as God alone, but as man; wherefore all Angels and men are subject to Him. Let us rejoice in thus seeing in glory our Saviour, our Father, and the best Friend we possess. And let us rejoice for ourselves, because the Resurrection of Jesus Christ is for us a sure pledge of our own resurrection and of the glory we hope one day to have in Heaven, both in soul and in body. This hope gave courage to the holy Martyrs to suffer with gladness all the evils of this life, and the most cruel torments of tyrants. We must rest assured, however, that none will rejoice with Jesus Christ but they who are willing to suffer with Him; nor will he obtain the crown who does not fight as he ought to fight. *He that striveth for the mastery is not crowned unless he strive lawfully* (2 Tim. ii. 5). At the same time let us remember what the same Apostle says, that all the sufferings of this life are short and light in comparison with the boundless and eternal joys we shall enjoy in Paradise (2 Cor. iv. 17). Let us labour the more to continue in the grace of God, and to pray continually for perseverance in His grace and favour; for without prayer, and persevering prayer, we shall not obtain this perseverance; and without perseverance we shall not obtain salvation.

O sweet Jesus, worthy of all love, Thou hast so loved men that, in order to show Thy love, Thou hast not refused to die wounded and dishonoured upon an infamous tree! O my God, how is it that there are so few among men who love Thee with all their heart? My dear Redeemer, of these few I will be one! Miserable that I am, for in my past life I have forgotten Thy love, and given up Thy grace for miserable pleasures. I know the evil I have done; I grieve for it with all my heart; I would die of grief. Now, O my beloved Redeemer, I love Thee more than myself; and I am ready to die a thousand times rather than lose Thy friendship. I thank Thee for the light Thou hast given me. O my Jesus, my Hope, leave me not in my own hands; help me until my death.

O Mary, Mother of God, pray to Jesus for me.
