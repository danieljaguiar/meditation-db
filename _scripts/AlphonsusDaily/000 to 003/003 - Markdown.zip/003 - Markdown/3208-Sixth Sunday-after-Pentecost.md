# Sixth Sunday after Pentecost

## Morning Meditation

OUR JOURNEY INTO ETERNITY.\--WE ARE ONLY PILGRIMS ON THIS EARTH.

*We have not here a lasting city, but we seek one that is to come.* In this world we are not citizens, but pilgrims, for we are on our way to Eternity. *Man shall go into the house of his eternity.*

*We have not here a lasting city, but we seek one that is to come* (Heb. xiii. 14). In this world we are not citizens, but pilgrims, for we are on our way to Eternity: *Man shall go into the house of his eternity* (Eccles. xii. 5).

Very soon, therefore, we shall have to leave this world. The body must soon go into the grave, and the soul into Eternity.

Would not that traveller be guilty of great folly, who should waste his time and his wealth in building himself a dwelling in a place he must soon leave?

O my God, my soul is eternal; I must, then, either enjoy Thee or lose Thee for Eternity.

In Eternity there are two places of abode\--one overflowing with every delight, the other replete with every torment. And these delights and torments will be eternal. *If the tree fall to the south, or to the north, in what place soever it shall fall there shall it be* (Eccles. xi. 3). If the soul be saved, it will be happy forever; but if it fall into hell, it will remain there to weep and lament as long as God shall be God.

There is no middle state: either a king forever in Heaven, or forever a slave of Lucifer; either blessed forever in Paradise, or in despair forever in hell.

Which of these abodes will fall to the lot of each of us? That which each one voluntarily chooses. *Man shall go\--Ibit homo.* He who goes to hell, goes of his own free will. Every one that is damned, is damned because he wills his own damnation.

O my Jesus, would that I had always loved Thee! Too late have I known Thee! Too late have I loved Thee! O Thou, *the God of my heart, and the God that is my portion forever!* (Ps. lxxii. 26).

II\.

Every Christian, in order to live well, should always keep Eternity before his eyes. Oh, how well regulated is the life of that man who lives and sees all things in the light of Eternity!

If Heaven, Hell, and Eternity were even only doubtful things, surely we ought to do all in our power not to run the risk of being lost forever. But no; they are not doubtful things, but Articles of Faith.

To what will all the greatness of this world come? To a funeral; to a descent into the grave. Blessed in that hour is he who obtains eternal life!

O Jesus! Thou art my life, my riches, my love. Grant me a great desire to please Thee during the remainder of my life; and give me Thy assistance to fulfil it.

The thought of Eternity is sufficient to make a saint. St. Augustine called it the *Great Thought*. It is this thought that has sent so many young persons into cloisters, so many anchorites into deserts, and so many Martyrs to cruel deaths.

Father John of Avila converted a lady who was attached to the world, by only saying: Consider: *Always and Forever!*\"

Oh, how much depends on the last moment of our lives! On our last breath depends an Eternity, either of happiness or of misery; a life of eternal bliss, or of eternal woe. Jesus Christ died upon the Cross, in order to secure for us His grace at this last moment.

My dear Redeemer, if then Thou hadst not died for me, I should have been lost forever! I thank Thee, O my Love! I confide in Thee and I love Thee!

## Spiritual Reading

PRAYER, THE GREAT MEANS OF SALVATION.

I have published several spiritual works, the *Visits to the Blessed Sacrament, The Passion of Jesus Christ, The Glories of Mary*, and, besides, a work against the Materialists and Deists, with other devout little treatises. I have recently brought out a work on the Infancy of our Saviour entitled *Novena for Christmas*; and another entitled *Preparation for Death*, besides the one on the *Eternal Maxims*, most useful for meditation and sermons \... But I do not think that I have written a more useful work than the present, in which I speak of prayer as a necessary, and a certain means of obtaining salvation, and all the graces which we require for that object. If it were in my power, I would distribute a copy of it to every Catholic in the world, in order to show him the absolute necessity of prayer for salvation.

I say this, because on the one hand I see that the absolute necessity of prayer is taught throughout the Holy Scriptures, and by all the Holy Fathers of the Church, while, on the other hand, I see that Christians are very careless in their practice of this great means of salvation. And, sadder still, I see that preachers take very little care to speak of it to their flocks, or confessors to their penitents; I see, moreover, that even the spiritual books now popular do not speak sufficiently of it; yet there is nothing which preachers, and confessors and spiritual books should insist upon with more warmth and energy than prayer; not but that they teach many excellent means of keeping ourselves in the grace of God, such as avoiding the occasions of sin, frequenting the Sacraments, resisting temptations, hearing the Word of God, meditation on the Eternal Truths, and other means\--all of them, I admit, most useful; but, I say, what profit is there in sermons, meditations, and all the other means pointed out by masters of the spiritual life, if we forget to pray? Has not our Lord declared that He will grant His graces to no one who does not pray? *Ask and ye shall receive*. Without prayer, in the ordinary course of providence, all the meditations we make, all our resolutions, all our promises, will come to naught. If we do not pray, we shall be always unfaithful to the inspirations of God, and to the promises we make Him. Because, in order actually to do good, to conquer temptations, to practise virtues, and to observe God\'s law, it is not enough to receive illumination from God, and to meditate and make resolutions, but we require, moreover, the actual assistance of God; and, as we shall see, He does not give this assistance except to those who pray, and pray with perseverance. The light we receive, and the considerations and good resolutions we make, are of use to incite us to the act of prayer when we are in danger and are tempted to transgress God\'s law; for, then prayer will obtain for us God\'s help, and we shall be preserved from sin; but if in such moments we do not pray, we shall be lost.

My intention in thus prefacing my book is, that my readers may thank God for giving them an opportunity, by means of this little book, to receive the grace of reflecting more deeply on the importance of prayer; for all adults who are saved, are ordinarily saved by this single means of grace. And therefore I ask my readers to thank God; for surely it is a great mercy when He gives the light and the grace to pray. I hope, then, that you, my beloved brother, after reading this little work, will never from this day forward, neglect to have continual recourse to God in prayer, whenever you are tempted to offend Him. If ever in times past you have had your conscience burdened with many sins, know that the cause of this has been your neglect of prayer, your not asking God for help to resist the temptations which assailed you. I pray you, therefore, to read my words again and again with the greatest attention; not because I write them, but because this book is a means which God offers you for the good of your salvation, thereby giving you to understand that He wishes you to be saved. And after having read it yourself, induce as many of your friends and neighbours as you can to read it also. Now let us begin in the Name of the Lord.

The Apostle writes to Timothy: *I desire, therefore, first of all that supplications, prayers, intercessions and thanksgivings be made* (1 Tim ii. 1). St. Thomas explains that prayer is properly the lifting up of the soul to God. *Petition* is that particular kind of prayer which begs for determinate objects, but when the thing sought is indeterminate (as when we say, \"Incline unto my aid, O God!\"), it is called *supplication. Obsecration* is a solemn adjuration or representation of the grounds on which we dare to ask a favour; as when we say,\" By Thy Cross and Passion, O Lord, deliver us !\" Finally, *thanksgiving* is the returning of thanks for benefits received, whereby, says St. Thomas, we merit to receive greater favours. Prayer, in a strict sense, says the holy Doctor, means recourse to God; but in its general signification it includes all the kinds just enumerated. It is in this latter sense that the word is used in this book.

We will here treat:

1.\--Of the Necessity of Prayer; the Power of Prayer, and the Conditions of Prayer;

2.\--We will show that God gives the grace of Prayer to all men.\*

\*Only a part, but we think the most important part, of St. Alphonsus\' Treatise on Prayer will be given here. The entire Treatise is included in Vol III. Centenary Edition of the Saint\'s works, which may be obtained from Editor of present work.\--ED.

## Evening Meditation

THE PRACTICE OF THE LOVE OF JESUS CHRIST.

*\" Charity beareth all things.\"*

HE THAT LOVES JESUS CHRIST BEARS ALL THINGS FOR HIM, AND ESPECIALLY ILLNESS, POVERTY, AND CONTEMPT.

I.

But wherefore does Almighty God load us with so many crosses, and take pleasure in seeing us afflicted, reviled, persecuted, and ill-treated by the world? Is He perchance, a tyrant, whose cruel disposition makes Him rejoice in our suffering? No; God is by no means a tyrant, nor cruel; He is all compassion and love towards us; suffice it to say that He has died for us. He indeed does rejoice at our suffering, because suffering is for our good; inasmuch as by suffering here we are released hereafter from the debt of punishment justly due from us to His Divine justice; He rejoices in our sufferings because they detach us from the sensual pleasures of this world: when a mother would wean her child she puts gall on the breast in order to create a dislike in the child; He rejoices in sufferings because we give Him, by our patience and resignation in bearing them, a token of our love; in fine, He rejoices in them, because they contribute to our increase of glory in Heaven. Such are the reasons for which the Almighty, in His compassion and love towards us, is pleased when we suffer.

I love Thee with my whole heart, O my Redeemer! I love Thee, my sovereign Good! I love Thee, my own Love, worthy of infinite love. I am grieved at any displeasure I have ever caused Thee, more than for any evil whatever. I promise Thee to receive with patience all the trials Thou mayest send me; but I look to Thee for help to be faithful to my promise, and especially to be enabled to bear in peace the sorrows of my last agony and death.

II\.

Let us conclude. That we may be able to practise patience to advantage in all our tribulations, we must be fully persuaded that every trial comes from the hands of God, either directly, or indirectly through men; we must therefore render God thanks whenever we are beset with sorrows, and accept, with gladness of heart, of every event, prosperous or adverse, that proceeds from Him, knowing that all happens by His disposition and for our welfare: *To them that love God all things work together unto good* (Rom. viii. 28). In addition to this, it is well in our tribulations to glance a moment at that hell we formerly deserved: for assuredly all the pains of this life are incomparably less than the awful pains of hell. But above all, prayer, by which we gain the Divine assistance, is the great means by which we may suffer patiently all affliction, scorn, and contradictions, and is that which will furnish us with the strength we have not of ourselves. The Saints were persuaded of this; they recommended themselves to God, and so overcame every kind of torments and persecutions.

O Lord, I am fully persuaded that without suffering, and suffering with patience, I cannot win the crown of Paradise. David said: *From him is my patience* (Ps. lxi. 6). And I say the same; my patience in suffering must come from Thee. I make many resolutions to accept all tribulations in peace; but no sooner are trials at hand than I grow sad and alarmed; and if I suffer, I suffer without merit and without love, because I know not how to suffer them so as to please Thee. O my Jesus, through the merits of Thy patience in bearing so many afflictions for love of me, grant me the grace to bear crosses for the love of Thee!

O Mary, my Queen, vouchsafe to obtain for me a true resignation in all the anguish and trials that await me during life and at death.
