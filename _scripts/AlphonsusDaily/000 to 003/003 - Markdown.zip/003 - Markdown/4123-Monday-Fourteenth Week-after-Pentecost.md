# Monday\--Fourteenth Week after Pentecost

## Morning Meditation

*EARNEST LABOUR FOR ETERNAL SALVATION*

\"No security is too great where Eternity is at stake,\" says St. Bernard. We should, therefore, resolve: \"I will save my soul, cost what it may!\" Perish all things else \-- property, friends, even life itself, if I can but only save my soul!

I.

To be saved it is not sufficient to profess to do merely what is absolutely necessary. If, for example, a person wishes to avoid only mortal sins, without taking any account of those which are venial, he will easily fall into mortal sins and lose his soul. He who desires to avoid only such dangers as are absolutely the immediate occasions of sin will most probably one day discover that he has fallen into grievous crimes and is lost. O my God, with what attention are the princes of this world served! Everything is avoided that can possibly give them the least offence for fear of losing their favour; but with what carelessness Thou art served! Everything that can endanger the life of the body is shunned with the greatest caution, while the dangers which threaten the life of the soul are not feared!

O my God, how negligently have I hitherto served Thee. Henceforth I will serve Thee with the greatest attention; be Thou my helper and assist me.

O my brother, if God should act as sparingly with you as you do with Him, what would become of you? If He should grant you only the grace barely sufficient \-- would you be saved? You would be able to obtain salvation, but you would not obtain it; because in this life temptations frequently occur so violent that it is morally impossible not to yield to them without a special assistance from God. But God does not afford His special assistance to those who deal sparingly with Him: *He who soweth sparingly shall also reap sparingly* (2 Cor. ix. 6).

But, O God, Thou hast not dealt sparingly with me: while I have been so ungrateful towards Thee as to repay Thy many favours with offences, Thou, instead of chastising me, hast redoubled Thy graces towards me. No, my God, I will never more be ungrateful to Thee, as I have hitherto been.

II\.

To save our immortal souls is not an easy task, but a difficult, and indeed a very difficult one. We carry about us the rebellious flesh, which allures to the gratification of sense; and we have, moreover, numberless enemies to contend with in the world, in hell, and even within our own selves, who are ever tempting us to evil. It is true, the grace of God is never wanting to us; but still this grace demands of us a hard struggle to overcome temptations, and fervent prayer in order to obtain more powerful assistance as the danger becomes greater.

O Jesus, I desire never more to be separated from Thee or deprived of Thy love. Hitherto I have been ungrateful to Thee and have turned my back upon Thee, but I will now love Thee with my whole soul, and fear nothing so much as to cease to love Thee. Thou knowest my weakness; assist me, therefore, Thou Who art my only hope and confidence. And thou, O ever-blessed Virgin Mary, cease not to intercede for me.

## Spiritual Reading

*DANGERS TO SALVATION*

A General Confession is a powerful help to a change of life. When the tempest is violent the burden of the vessel is diminished, and each person on board throws his goods into the sea in order to save the ship and save his life. O folly of sinners, who, in the midst of so great dangers of eternal perdition, instead of diminishing the burden of the vessel \-- that is, instead of unburdening the soul of her sins \-- load her with a greater weight. Instead of flying from the dangers of sin, they fearlessly continue to put themselves voluntarily into dangerous occasions; and, instead of having recourse to God\'s mercy for the pardon of their offences, they offend Him still more, and compel Him to abandon them.

Another means is to labour strenuously to prevent ourselves becoming the slaves of irregular passions. *Give me not over to a shameless and foolish mind* (Ecclus. xxiii. 6). Do not, O Lord, deliver me up to a mind blinded by passion. He who is blind sees not what he is doing, and therefore he is in danger of falling into every crime. Thus so many are lost by submitting to the tyranny of their passions. Some are slaves to the passion of avarice. A person who is now in the other world said: Alas! I perceive that a desire of riches is beginning to tyrannize over me. So said the unhappy man; but he applied no remedy. He did not resist the passion in the beginning, but nurtured it till death, and thus at his last moments left but little reason to hope for his salvation. Others are slaves to sensual pleasures. They are not content with lawful gratifications, and therefore they pass to the indulgence of those that are forbidden. Others are subject to anger; and because they are not careful to check the fire at its commencement, when it is small, it increases and grows into a spirit of revenge.

Disorderly affections, if they are not beaten down in the beginning, become our greatest tyrants. Many, says St. Ambrose, after having victoriously resisted the persecutions of the enemies of the Faith, were afterwards lost because they did not resist the first assaults of some earthly passion. Of this, Origen was a miserable example. He fought for, and was prepared to give his life in defence of the Faith; but afterwards, yielding to human respect, he was led to deny the Faith, as we are told by Natalis Alexander. We have still a more miserable example in Solomon, who, after having received so many gifts from God, and after being inspired by the Holy Ghost, was, by indulging a passion for certain pagan women, induced to offer incense to idols. The unhappy man who submits to the slavery of his wicked passions resembles the miserable ox that is sent to the slaughter after a life of constant labour. During their whole lives worldlings groan under the weight of their sins, and, at the end of their days they fall into hell.

When the winds are strong and violent the pilot lowers the sails and casts anchor. So when we find ourselves assailed by any bad passion, we should lower the sails; that is, we should avoid all the occasions which may increase the passion, and should cast anchor by uniting ourselves to God, and by begging of Him to give us strength not to offend Him.

But some of you will say: What am I to do? I live in the midst of the world where my passions continually assail me even against my will. I will answer in the words of Origen: \"The man who lives in the darkness of the world and in the midst of secular business, can with difficulty serve God.\" Whoever, then, wishes to insure his eternal salvation, let him retire from the world and take refuge in one of those exact Religious Communities which are the secure harbours in the sea of this world. If he cannot actually leave the world, let him leave it at least in affection by detaching his heart from the things of this world, and from his own evil inclinations: *Go not after thy lusts, says the Holy Ghost, but turn away from thy own will* (Ecclus. xviii. 30). Follow not your own concupiscence; and when your will would impel you to evil, you must not indulge, but must resist its inclinations.

*The time is short \... the fashion of this world passeth away* (1 Cor. vii. 29-31). The time of life is short; we should then prepare for death which is rapidly approaching; and to prepare for that awful moment let us reflect that everything in this world shall soon end.

## Evening Meditation

*CONSIDERATIONS ON THE PASSION OF JESUS CHRIST*

I.

The soldiers came, and broke the legs of the two thieves who were crucified with Jesus, but when they came to Jesus, they saw that He was already dead, and abstained from doing the same to Him. One of them, however, with a spear pierced His side, from which immediately came forth Blood and water (Jo. xix. 34).

St. Cyprian says that the spear pierced straight into the Heart of Jesus Christ, and the same was revealed to St. Bridget. From which we understand that, as both Blood and water flowed forth, the spear, in order to strike the heart, must first have pierced the pericardium.

St. Augustine says that St. John used the words *opened the side*, because in the Heart of the Lord the way of life was opened, whence came forth the Sacraments by means of which we enter upon eternal life. Further, it is said that the Blood and water which came from the side of Jesus were figures of the Sacraments; the water, of Baptism, which is the first of the Sacraments; and the Blood, of the Eucharist, which is the greatest.

St. Bernard further says that, by receiving this visible stroke, Jesus Christ wished to signify the invisible stroke of love by which His Heart was pierced for us.

St. Augustine, speaking of the Eucharist, says that the Holy Sacrifice of the Mass today is not less efficacious before God than the Blood and water which flowed that day from the side of Jesus Christ.

II\.

*Blotting out the handwriting of the decree that was against us, which was contrary to us. And he hath taken the same out of the way, fastening it to the cross* (Colos. ii. 14). The sentence was already recorded against us that was to condemn us to eternal death, as rebels against the offended Majesty of God. And what has Jesus Christ done? With His Blood He has cancelled the writing of the condemnation, and, to deliver us from all fear, He has fastened it to His own Cross, on which He died to satisfy for us to the Divine justice. My soul, behold the obligation thou art under to thy Redeemer; and hear how the Holy Spirit now reminds thee: *Forget not the kindness of thy surety* (Ecclus. xxix. 19). Forget not the kindness of thy Surety, Who, taking upon Himself thy debts, has paid them for thee, and behold, the pledge of the payment has been already fixed to the Cross. When, therefore, thou dost remember thy sins, look upon the Cross, and have confidence; look on that sacred wood stained with the Blood of the Lamb of God sacrificed for thy love, and hope in and love a God Who has loved thee so much.
