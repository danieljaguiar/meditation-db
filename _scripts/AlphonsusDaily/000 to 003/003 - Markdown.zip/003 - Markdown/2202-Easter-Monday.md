# Monday in Easter Week

## Morning Meditation

THE LOVE OF JESUS IN DYING FOR US.

Jesus died for us that by His love for us He might gain the entire dominion of our hearts. *For to this end, wrote St. Paul, Christ died and rose again, that he might be Lord both of the dead and of the living.* (Rom. xiv. 9). Contemplating the death of Jesus Christ, and the love with which He died for men, the Saints esteemed it little to forfeit for His sake, property, honours, and life itself.

I.

Who could have conceived that the Son of God, the Lord of the Universe, to show His love for us, would suffer and die upon the Cross, if He had not really done so? With reason did Moses and Elias on Mount Tabor speak of the death of our Lord Jesus Christ as of an *excess*. (Luke ix. 31). And what could be greater excess of love than for the Creator to die for His creatures?

To make Thee an adequate return for Thy love, my dear Redeemer, it would be necessary for another God to die for Thee. It would therefore be but little, it would be nothing, were we poor miserable worms of the earth to give up our whole lives for Thee, Who hast given Thine for us.

What should still more excite us to love Him is the ardent desire with which, through the course of His life, He longed for the hour of His death. By this desire He indeed proved how great His love was for us. *I have a baptism*, He said, *wherewith I am to be baptized; and how am I straitened until it be accomplished* (Luke xii. 50). I must be baptized with the Baptism of My own Blood, to wash away the sins of men, and how am I dying with the desire of My bitter Passion and Death! My soul, lift up your eyes, and behold your Lord hanging upon a disgraceful Cross; behold the Blood which trickles down from His Wounds. Behold His mangled body, all inviting you to love Him. Your Redeemer in His sufferings would have you love Him at least through compassion.

O Jesus, Thou didst not refuse me Thy life and precious Blood, and shall I refuse Thee anything that Thou requirest of me? No, Thou hast given Thyself to me without reserve. I will give myself to Thee without reserve.

II\.

St. Francis de Sales, speaking of these words of the Apostle, *The charity of Christ presseth us* (2 Cor. v. 14), says: \"Knowing that Jesus Christ, being true God, has loved us even to the laying-down of His life for us, and this upon a Cross, do we not feel our hearts as it were in a press, forcibly straitened, and love pressed from them by a violence which is the more powerful as it is the more amiable?\" And he adds: \"Why, therefore, do we not cast ourselves upon Jesus Christ crucified, to die on the Cross for the love of Him Who has willingly died upon the Cross for the love of us? I will cling to Him, should we say, and will never abandon Him; I will die with Him, and be consumed in the fire of His love. My Jesus has given Himself entirety to me. and I will give myself entirely to Him. I will live and die upon His bosom; neither life nor death shall ever separate me from Him. O Eternal Love, my soul seeks Thee and espouses Thee forever!\"

## Spiritual Reading.

THE HAPPY LIFE OF THOSE WHO LOVE GOD.

*Justice and peace, have kissed* (Ps. lxxxiv. 11). Peace resides in every soul in which justice dwells. Hence David said: *Delight in the Lord, and he will give thee the requests of thy heart.* (Ps. xxxvi. 4). To understand these words we must consider that worldlings seek to satisfy the desires of their hearts with the goods of this earth; but, because these cannot make them happy, their hearts continually make fresh demands; and how much soever they may acquire of these goods, they are not content. Hence the Prophet says: Delight in the Lord, and he will give thee the requests of thy heart. Give up creatures, seek your delight in God, and He will satisfy all the cravings of your heart.

This is what happened to St. Augustine, who, as long as he sought happiness in creatures, never enjoyed peace; but, as soon as he renounced them and gave to God all the affections of his heart, he exclaimed: \"All things are hard, O Lord, and Thou alone art repose.\" As if he had said: Ah, Lord I I now know my folly. I expected to find felicity in earthly pleasures; but now I know that they are only vanity and affliction of spirit, and that Thou alone art the peace and joy of our hearts.

The Apostle says that the peace which God gives to those who love Him surpasses all the sensual delights a man can enjoy on this earth. *The peace of God, which surpasseth all understanding.* (Phil. iv. 7). St. Francis of Assisi, in saying \"My God and my All!\" experienced on this earth an anticipation of Paradise. St. Francis Xavier, in the midst of his labours in India for the glory of Jesus Christ, was so replenished with Divine consolations, that he would exclaim: \"Enough, O Lord! Enough!\" Where, I ask, has any lover of this world been found, so satisfied with the possession of worldly goods as to say: Enough, O world, enough; no more riches, no more honours, no more applause, no more pleasures? Ah, no! worldlings are constantly seeking after higher honours, greater riches, and new delights; but the more they have of them, the less are their desires satisfied, and the greater their disquietude.

It is necessary to persuade ourselves of this truth, that God alone can give content. Worldlings do not wish to be convinced of it, through an apprehension that, if they give themselves to God, they will lead a life of bitterness and discontent. But with the Royal Prophet, I say to them: *O taste, and see that the Lord is sweet.* (Ps. xxxiii. 9). Why, O sinners, will you despise and regard as miserable that life which you have not as yet tried? O taste and see. Begin to make a trial of it; hear Mass every day; practise Mental Prayer and the Visit to the Most Holy Sacrament; go to Communion at least once a week; fly from evil conversations; walk always with God; and you shall see that, by such a life, you will enjoy that sweetness and peace which the world, with all its delights, has not hitherto been able to give you.

## Evening Meditation.

THOU SHALT BE CROWNED.

I.

Let us imagine to ourselves a soul which, on departing out of this world, enters into eternity in the grace of God. All full of humility and of confidence, it presents itself before Jesus, its Judge and Saviour. Jesus embraces it, gives it His benediction, and causes it to hear these words of sweetness: Come, my spouse, come! Thou shalt be crowned! If the soul have need of being purified, He sends it to Purgatory, and, all resigned, it embraces the chastisement, because itself wishes not to enter into Heaven, that land of purity, if it is not wholly purified. The Guardian Angel comes to conduct it to Purgatory; it first returns him thanks for the assistance he has rendered it in its lifetime, and then obediently follows him. Ah, my God, when will that day arrive on which I shall see myself out of this world of perils, secure of never being able to lose Thee any more? Yes, willingly will I go to the Purgatory which shall be mine; joyfully will I embrace all its pains; sufficient will it be for me in that fire to love Thee with all my heart, since there I shall love none else but Thee.

II\.

The purgation over, the Angel will return and say to the soul: Come, beautiful soul, the punishment is over; come, and enjoy the Presence of thy God Who is awaiting thee in Paradise. Behold, the soul now passes beyond the clouds, passes beyond the spheres and the stars, and enters into Heaven. O God, what will it say on entering into that beautiful country, and casting its first glance on that city of delights? The Angels and Saints, and especially its own holy advocates, will go to meet it, and with jubilation will they welcome it, saying, Welcome, O companion of our own! Welcome! Ah, my Jesus, do Thou make me worthy of it.

What consolation will the soul not feel in there meeting with relations and friends of its own who have previously entered into Heaven! But greater by far will be its joy in beholding Mary its Queen, and in kissing her feet, and thanking her for the many kindnesses she has done it. The Queen will embrace it, and will herself present it unto Jesus, Who will receive it as a spouse. And Jesus will then present it to His Divine Father, Who will embrace and bless it, saying: Enter thou into the joy of thy Lord. And thus will He beatify it with the same beatitude He Himself enjoys. Ah, my God, make me love Thee exceedingly in this life, that I may love Thee exceedingly in eternity. Thou art the object most worthy of being loved; Thou dost deserve all my love; I will love none but Thee. Do Thou help me by Thy grace. And, Mary, my Mother, be thou my protectress.
