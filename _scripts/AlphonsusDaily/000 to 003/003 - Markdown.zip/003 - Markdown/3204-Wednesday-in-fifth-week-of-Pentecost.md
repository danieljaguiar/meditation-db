# Wednesday\--Fifth Week after Pentecost

## Morning Meditation

THE VANITY OF THE WORLD\--THE GOODS OF THIS WORLD ARE FALSE GOODS.

The world! And what is the world but mere show! A scene which quickly passes away! The fashion of this world passeth away! Death approaches, the curtain falls, the scene closes, and all comes to an end!

I.

*What doth it profit a man, if he gain the whole world and suffer the loss of his own soul?* (Matt. xvi. 26). O great maxim, which has conducted so many souls to Heaven, and bestowed so many Saints on the Church! What doth it profit to gain the whole world, which passes away, and lose the soul, which is eternal?

The world! And what is the world but mere show, a scene which quickly passes away! *The fashion of this world passeth away* (1 Cor. vii. 31). Death approaches, the curtain falls, the scene closes, and thus all comes to an end!

Alas! at the hour of death, how will all worldly things appear to a Christian\--those vessels of silver, those heaps of gold, that rich and vain furniture\--when he must leave them all forever!

O Jesus, grant that henceforward my soul may be wholly Thine! Grant that I may love no other but Thee. I desire to renounce all things before death tears me away from them.

St. Teresa says: \"Nothing ought to be considered of consequence which must come to an end.\" Let us, therefore, strive to gain that treasure which will not fail with time. What does it avail a man to be happy for a few days (if indeed there can be any happiness without God), if he must be unhappy forever in eternity.

David says that earthly goods at the hour of death, will seem as a dream to one waking from sleep: *As the dream of them that awake* (Ps. lxxii. 20). What disappointment does he feel who, having dreamt he was a king, on awaking finds himself still as lowly and poor as ever?

O my God, who knows but that this meditation which I am now reading will be the last call for me? Enable me to root out of my heart all earthly affections, before I enter into eternity. Grant that I may be sensible of the great wrong I have done Thee, by offending Thee, and by forsaking Thee for the love of creatures. *Father, I am not worthy to be called thy son* (Luke xv. 21). I am grieved for having turned my back upon Thee; do not reject me, now that I return to Thee.

II\.

No position of dignity, no magnificence, no wealth, no nice points of honour, no pastimes, will console a Christian at the hour of death; the love of Jesus Christ, and the little that he has suffered for His love, will alone console him.

Philip II, when dying, said \" Oh, that I had been a Lay-Brother in some Monastery, and not a King!\" Philip III said \" Oh, that I had lived in a desert! Alas, now I shall appear with but little confidence before the tribunal of God!\" Thus, at the hour of death, do those express themselves who have been esteemed the most fortunate in this world.

In short, all earthly goods generally bring, at the hour of death, only remorse of conscience and fear of eternal damnation. O God! will the dying sinner say, I have had sufficient light to withdraw myself from worldliness, and yet I have followed the world, and its maxims; and now what sentence will be pronounced upon me? Fool that I have been! I might have been a saint, with the means of grace and the advantages I enjoyed! I might have led a happy life in union with God; and now what have I but remorse of conscience and a dread of damnation! But when will he say this? When the scene is about to close, and himself about to enter into eternity, and at that moment on which will depend his happiness or misery forever.

O Lord, have pity on me! For the past I have not been so wise as to love Thee. From this day forward Thou alone shalt be my only Good: *My God and my all!* Thou alone deservest all my love, and Thee only will I love.

## Spiritual Reading

IV.\--THE ADVANTAGE OF A RETREAT MADE IN SOLITUDE AND SILENCE.

If, indeed, there were no other satisfaction in solitude than that of knowing the Eternal Truths, that alone would be sufficient to make a Retreat a most desirable thing. The knowledge of the Eternal Truths gives the soul a perfect contentment such as is never found in the vanities of the world, which are only lying and deceitful things. Herein consists precisely the happiness which is found in the exercises of a Retreat gone through in solitude and silence. It is then one sees in the clearest light the Christian maxims, the importance of salvation, the ugliness of sin, the value of grace, the love God bears us, the vanity of earthly goods, the foolishness of those who, for the sake of the fleeting joys of the world, fling away eternal goods and prepare for themselves an Eternity of pain and misery.

Hence it comes about that, having convinced himself of these truths, a man takes the most efficacious means to secure his eternal salvation. In a Retreat he disentangles himself from earthly affections and unites himself to God in prayer, by desires of closer union with Him, by repeated offerings of himself, by multiplied acts of sorrow, love, and resignation. He thus finds himself raised so high above all created things that he smiles in pity on those who set such value on the things of this world which he so much despises, knowing how worthless they are, and how unworthy of the love of a heart created to love an infinite Good, which is God. It is certain that one comes out of the Exercises a very different man, and much better than he was when he began them.

It was the opinion of St. John Chrysostom that retirement was a great means of rising to perfection. And a learned author, speaking of the Exercises of a Retreat, says: \"Happy, indeed, is the man who, fleeing from the noise of the world, allows himself to be led by the Lord to the Spiritual Exercises, into that sweet solitude where he finds and tastes the delights of Paradise.\" Sermons in the churches are good, but if the hearers do not reflect on what they have heard, the fruit will be little. Reflection will never be made as it should be unless it be made in solitude. As soon as the oyster receives the dew of heaven it shuts itself at once and sinks to the bottom of the sea, and there the pearl is formed. It is beyond all doubt that what makes the fruit of the Exercises perfect is the silent reflection alone with God upon the truths one has heard in a sermon or read in a book. Hence St. Vincent de Paul in his missions never failed to exhort his hearers to make the Exercises in some retired place. One single spiritual maxim well meditated upon is sufficient to make a saint. Thus St. Francis Xavier resolved to give up the world in consequence of the impression made on him by that maxim of the Gospel: *What doth it profit a man if he gain the whole world and suffer the loss of his own soul?* (Matt. xvi. 26). A young student having once heard a maxim on death, changed his conduct and led a virtuous life. St. Clement of Ancyra was encouraged to suffer for Jesus Christ all the torments inflicted by the tyrant, by thinking of what his mother had taught him: \"It is for life eternal we are fighting.\"

## Evening Meditation

THE PRACTICE OF THE LOVE OF JESUS CHRIST.

HE THAT LOVES JESUS CHRIST BEARS ALL THINGS FOR HIM, AND ESPECIALLY ILLNESS, POVERTY AND CONTEMPT.

Above all, in time of sickness we should be ready to accept of death, and of that death which God pleases. We must die, and our life must finish in our last illness; but we do not know which will be our last illness. Wherefore in every illness we must be prepared to accept that death God has appointed for us. A sick person says: \"Yes; but I have committed many sins, and have done no penance. I should like to live, not for the sake of living, but to make some satisfaction to God before I die.\" But tell me, how do you know that if you live longer you will do penance, and not rather do worse than before? At present you can well cherish the hope that God has pardoned you, and what penance can be more satisfactory than to accept of death with resignation, if God wills you are to die? St. Aloysius Gonzaga, at the age of twenty-three, gladly embraced death with this reflection: \"At present,\" he said, \"I am, as I hope, in the grace of God. Hereafter I know not what may befall me; so that I now die contentedly, if God calls me to the next life.\" It was the opinion of Blessed John of Avila that every one, provided he be in proper dispositions, though only moderately good, should desire death, to escape the danger which always surrounds us in this world, of sinning and losing the grace of God.

Besides, owing to our natural frailty, we cannot live in this world without committing at least venial sins; this should be a motive for us to embrace death willingly that we may never offend God any more. Further, if we truly love God, we should ardently long to go to see Him, and love Him with all our strength in Paradise, which no one can do perfectly in this present life; but unless death open to us the door, we cannot enter that blessed region of love. This caused St. Augustine, that loving soul, to cry out: \"Oh, let me die, Lord, that I may behold Thee!\" O Lord, let me die, otherwise I cannot behold and love Thee face to face.

II\.

In the second place we must practise patience in the endurance of poverty. Our patience is certainly very much tried when we are in need of temporal goods. St. Augustine says: \"He that has not God, has nothing; he that has God, has all.\" He who possesses God, and remains united to His will, finds every good. Witness St. Francis, barefooted, clad in sack-cloth, and deprived of all things, yet happier than all the monarchs of the world, by simply repeating: *Deus meus et omnia*! My God and my All! He only is a poor man who has not what he desires; but he that desires nothing, and is contented with his poverty, is in fact very rich. Of such St. Paul says: *Having nothing, yet possessing all things* (2 Cor. vi. 10). The true lovers of God have nothing, and yet have every thing; since, when temporal goods fail them, they exclaim: \"My Jesus, Thou alone art sufficient for me!\" and with this they rest satisfied. Not only did the Saints maintain patience in poverty, but sought to be despoiled of all, in order to live detached from all, and united with God alone. If we have not courage to renounce all worldly goods, at all events let us be contented with that state of life in which God has placed us; let our solicitude be not for earthly goods, but for those of Paradise, which are immeasurably greater, and last for ever; and let us be fully persuaded of the truth of what St. Teresa says: \"The less we have here the more we shall have in Heaven.\"
