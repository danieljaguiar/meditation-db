Eighteenth Sunday after Pentecost

## Morning Meditation

ST. MICHAEL THE ARCHANGEL

(September 29)

The Church assures us that St. Michael has been given as our defender, and that he comes to the aid of all who have recourse to him. Beseech him that he may be thy special protector with God Who loves him so much.

I.

Among the angels in Heaven none surpass St. Michael in glory; and, according to St. Basil and others, none, indeed, equal him. St. Michael was chosen before all others to subdue the pride of Lucifer and of all the rebel angels, and to expel them from Heaven. If thou lovest this Archangel, who has so great love for men, rejoice at the glory he enjoys in Heaven, and beseech him, that, as he is the protector of the whole Church and of all the faithful, he will be thy special protector with God, Who loves him so much, and Who rejoices in beholding one who is so faithful to Him and so zealous for His honour, so much glorified by all.

In the Mass for the Dead, the Church prays: *\"Let the standard-bearer, St. Michael, bring them into the holy light.\"* The learned explain this prayer, and say that St. Michael has the honourable office of presenting to Jesus Christ the Judge, all the souls that depart out in this world in the grace of God.

Protect me, therefore, O holy Archangel, and by thy protection enable my soul to become worthy to be presented by thy hands on the day of my death, clothed with Divine grace, before my Judge Jesus Christ.

II\.

St. Laurence Justinian says that our holy mother the Church honours St. Michael as her own special protector and faithful intercessor, and the holy Church herself declares she venerates St. Michael, as the ancient Synagogue venerated him, as protector and patron. The holy Archangel, then, as the protector of the whole Church continually intercedes with God in favour of Christians, and obtains for them all the help they need. He also aids the Sovereign Pontiff and all the bishops in the government of souls, and most carefully watches over the defence of the faithful against the attacks of those demons whom he formerly expelled from the heavenly kingdom.

The Church prays to St. Michael, in the name of all the faithful, to defend us from the assaults of the wicked enemy at the hour of our death, that we may not be conquered and may not lose our souls: *Holy Michael, Archangel, defend us in the battle, that we may not perish in the dreadful Judgment.*

O holy Archangel, the devil has many weapons to employ against me at the hour of my death; these weapons are my sins, by which he will then endeavour to cast me into despair. He is also preparing furious assaults of temptation, to cause me to fall again into sin. Do thou, who hast conquered him, and expelled him from Heaven, conquer him now for me, and drive him far away from me at the hour of my death; I beseech thee to hear my prayer, for the love of that God Who so much loves thee, and Whom thou dost so much love. O Mary, Queen of Heaven, procure for me the assistance of St. Michael at the hour of my death.

## Spiritual Reading

*ST. MICHAEL PROTECTS US AGAINST THE TEMPTATIONS OF THE DEVIL.*

Mankind being lost through the fall of Adam, God sent on earth His only Son to redeem it, and He at the same time charged St. Michael, as a valiant combatant, to repress the powers of hell. He moves through the whole world with great rapidity in order to strengthen men against the temptations of the devil.

We should take care to honour and invoke this great minister of God, for the Church assures us that St. Michael has been given to us as our defender, and that he comes to the aid of every one who has recourse to him. He is specially prompt in succouring those who are tempted by the devil. Pantaleon says that he discloses to us the snares of our enemy, and that he baffles his artifices. The evil spirit often tempts us to regard a bad action as permissible, and even as good, and seeks by this means to destroy us; but St. Michael permits us to see the danger, and thus enables us to avoid the dangers that threaten us.

Father Nieremberg relates that the servant of a great lord, after having, during many years, led a wicked life, was at the point of death. The devil placing inwardly before his mind all his sins, strongly tempted him to despair, and succeeded in making him say that he did not wish to make his Confession, nor to receive any other Sacrament, because he was damned. But as this unfortunate sinner in the midst of his disorders had never ceased to keep up some sentiment of devotion towards St. Michael, and to recommend himself to him, the good Archangel appeared to him at the moment of death and revealed to him that he had prayed for him, adding that the Lord, through his intercession, had granted him three hours more to live in order that he might confess and receive the Sacraments, so as to be able to die in the grace of God. Thereupon the dying man with tears in his eyes, thanked his heavenly benefactor for having obtained for him so great a favour. He then called his brother and begged him to go at once and bring him a confessor. His brother set out at once and directed his steps towards a Dominican convent that was not far away. On the road he met two of these Religious, who told him that they had been called by an unknown person to hear the Confession of the sick man, and that they were going to his house for this purpose. It is presumed that the holy Archangel himself gave them this information and requested them to seek out the dying man. When they arrived the sick man made his Confession and received the Sacraments with lively sentiments of compunction; and after the lapse of the three hours, the man died, giving every hope that he had saved his soul.

## Evening Meditation

*ST. MICHAEL BATTLES FOR US AGAINST THE INFERNAL DRAGON.*

I.

The Deacon Pantaleon assures us that St. Michael not only obtains for his pious servants the courage and the strength to resist the temptations of hell, but comes in person to fight when he sees any one hard pressed by the devil, and exposed to the proximate danger of falling into sin. Moreover, St. Bruno, bishop of Segni, who lived at the end of the Eleventh Century, says that this generous Archangel loves us so much that he does not cease day or night to give battle for us against the infernal dragon, and that he even calls together those angels under him to combat with him, so that we may not be overcome by our enemy. Pantaleon also adds that St. Michael is always encamped, as it were, near God\'s people, that is to say, he comes with his angel, and places his guards around Christians, in order that they may not become the prey of hell, especially when they implore him to come to their aid.

II\.

St. Michael comes to the assistance of his pious servants if they happen to fall into sin. He obtains for them the grace to know the baseness of their faults, and to detest them. This is the reason why the Church wishes us to confess ourselves guilty, first to God, then to the Blessed Virgin, and then to St. Michael. Here we see that the holy Archangel is also specially asked to help us to recover the grace of God.

St. Sophronius, patriarch of Jerusalem in the Seventh Century, in a discourse in which he greatly eulogizes St. Michael, calls him the guide of those who go astray; that is to say, he brings back to the path of duty sinners who live far from God, and helps them to find the means of obtaining pardon. The Archangel is also described by the same Saint as the one who raises up those who have fallen; for the holy Archangel by means of salutary inspirations induces sinners to rise out of the unhappy state in which they find themselves.

The Deacon Pantaleon pronounces the same eulogy: \"The Archangel leads them forth to the road of penance, and procures for them the remission of sins.\" St. Michael, who ardently loves our souls, when he sees them lying in the abyss of sin, seeks in different ways to conduct them to penance, which is the only way to return to the state of grace. He adds that the generous Archangel goes so far as to make himself responsible for sinners; that is, seeing one of his pious clients in disgrace with God, he supplicates the Lord to wait for him till he does penance, and he becomes in some way surety for him by promising God that this sinner will offend Him no more, because he will take care to aid him when he sees him in danger of relapsing into sin.
