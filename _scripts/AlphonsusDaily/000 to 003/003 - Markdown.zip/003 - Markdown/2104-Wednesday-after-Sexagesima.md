# Wednesday after Sexagesima

## Morning Meditation

*THE TURNING AWAY FROM GOD BY SIN.*

*Who is the Lord that I should hear his voice? I know not the Lord.* (Exod. v. 2). So speaks the sinner. Lord, I do not acknowledge Thee! I will do what I please! He insults God to His face and turns his back upon Him. This turning away from God is mortal sin.

I.

St. Augustine and St. Thomas define mortal sin as *a turning away from God*: that is, the turning of one\'s back upon God, leaving the Creator for the sake of the creature. What punishment would that subject deserve who, while his king was giving him a command, contemptuously turned his back upon him to go and transgress his orders? That is what the sinner does; and it is punished in hell with the pain of loss, that is, the loss of God, a punishment richly deserved by him who in this life turns his back upon his Sovereign Good.

Alas! my God, I have frequently turned my back upon Thee; but I see that Thou hast not yet abandoned me; I see that Thou approachest me, and, inviting me to repentance, dost offer me Thy pardon. I am sorry above every evil for having offended Thee, do Thou have pity on me.

*Thou hast forsaken me*, saith the Lord; *thou art gone backward.* (Jer. xv. 6). God complains and says: Ungrateful soul, hast thou forsaken Me! I should never have forsaken thee hadst thou not first turned thy back upon Me: *thou hast gone backward*. O God, with what consternation will these words fill the soul of the sinner when he stands to be judged before Thy Divine tribunal!

Thou makest me hear them now, O my Saviour, not to condemn me, but to bring me to sorrow for the offences I have committed against Thee. Yes, O Jesus, I sincerely repent of all the displeasure I have given Thee. For my own miserable gratification I have forsaken Thee, my God, my Sovereign, Infinite Good! But behold me a penitent returned to Thee; reject me not.

II\.

*Why will you die, O house of Israel? return ye and live.* (Ezech. xviii. 31). I have died, says Jesus Christ, for the salvation of your souls, and why will you condemn them by your sins to eternal death? Return to Me, and you will recover the life of My grace.

O Jesus, I should not dare to crave Thy pardon, did I not know that Thou hast died to obtain my forgiveness. Alas! how often have I despised Thy grace and Thy love. O that I had died rather than have ever offered Thee so great an injury! But Thou, Who didst come near to me even when I offended Thee, wilt not now reject me, when I love Thee and seek no other but Thee. My God and my All, suffer me not any more to be ungrateful to Thee. Mary, Queen and Mother, obtain for me the grace of holy perseverance.

## Spiritual Reading

THE POWER OF THE PASSION OF JESUS CHRIST (continued).

It was for this end, says St. Paul, that Jesus Christ died, that each of us should no longer live to the world nor to himself, but to Him alone Who has given Himself wholly to us: *And Christ died for all, that they also who live may not now live to themselves, but unto him who died for them.* (2 Cor. v. 15). He who lives to the world, seeks to please the world; he who lives to himself, seeks to please himself; but he who lives to Jesus Christ, seeks only to please Jesus Christ, and fears only to displease Him. His only joy is to see Him loved; his only sorrow, to see Him despised. This is to live to Jesus Christ; and this is what He claims from each one of us. I repeat, does He claim too much from us, after having given us His blood and His life?

Wherefore, then, O my God, do we employ our affections in loving creatures, relations, friends, the great ones of the world, who have never suffered for us scourges, or thorns, or nails, or shed one drop of blood for us; and not in loving a God Who for love of us came down from Heaven and was made Man, and shed all His blood for us in the midst of torments, and finally died of grief upon a Cross, in order to win to Himself our hearts: and, further, in order to unite Himself more closely with us, has left Himself, after His death, upon our altars, where He makes Himself one with us that we may understand how burning is the love wherewith He loves us? \"He hath mingled Himself with us,\" exclaims St. John Chrysostom, \"that we may be one and the same thing; for this is the desire of those who ardently love.\" And St. Francis de Sales, speaking of Holy Communion, adds: \"There is no action in which we can think of our Saviour as more tender or more loving than this, in which He, as it were, annihilates Himself, and reduces Himself to food, in order to unite Himself to the hearts of His faithful.\"

But how comes it, O Lord, that I, after having been loved by Thee to such an excess, have had the heart to despise Thee, according to Thy just reproach: *I have brought up children and exalted them, but they have despised me* (Is. i. 2)? I have dared to turn my back upon Thee, in order to gratify my senses: *Thou hast cast me behind thy back.* (Ezech. xxiii. 35). I have dared to drive Thee from my soul: *The wicked have said to God: Depart from us.* (Job xxi. 14). I have dared to afflict that Heart of Thine which has loved me so much. And what, then, am I now to do? Ought I to be distrustful of Thy mercy? I curse the days wherein I dishonoured Thee. Oh, would that I had died a thousand times, O my Saviour, than that I had ever offended Thee! O Lamb of God, Thou didst bleed to death upon the Cross to wash away our sins in Thy Blood. O sinners, what would you not pay on the Day of Judgment for one drop of the Blood of this Lamb? O my Jesus, have pity on me, and pardon me; but Thou knowest my weakness; take, then, my will, that it may never more rebel against Thee. Expel from me all love that is not for Thee. I choose Thee alone for my Treasure and my only Good. Thou art sufficient for me; and I desire no other good apart from Thee: The God of my heart, and God that is my portion for ever.

O little sheep, beloved of God (so used St. Teresa to call the Blessed Virgin), who art the Mother of the Divine Lamb, recommend me to thy Son. Thou, after Jesus, art my hope, for thou art the hope of sinners. To thy hands I intrust my eternal salvation. *Spes nostra, salve!* (Our hope, save us!)

## Evening Meditation

REFLECTIONS AND AFFECTIONS ON THE PASSION OF JESUS CHRIST.

The Apostle St. Paul said that he desired to know nothing but Jesus, and Jesus crucified; that is, the love that He has shown us on the Cross: *I judged not myself to know anything among you but Jesus Christ, and him crucified.* (1 Cor. 2). And, in truth, from what books can we better learn the Science of the Saints \-- that is, the Science of loving God than from Jesus crucified? That great servant of God, Brother Bernard of Corlione, the Capuchin, not being able to read, his brother Religious wanted to teach him, upon which he went to consult his Crucifix; but Jesus answered him from the Cross, \"What is reading? What are books? Behold, I am the Book wherein thou mayest continually read the love I have borne thee.\" O great subject to be considered during our whole life and during all eternity! A God dead for the love of us! a God dead for the love of us! O wonderful subject!

St. Thomas Aquinas was one day paying a visit to St. Bonaventure, and asked him from what book he had drawn all the beautiful lessons he had written. St. Bonaventure showed him the image of the Crucified, which was completely blackened by all the kisses he had given it, and said, \" This is my book, whence I receive everything that I write; and it has taught me whatever little I know.\" In short, all the Saints have learned the art of loving God from the study of the Crucifix. Brother John of Alvernia, every time that he beheld Jesus wounded, could not restrain his tears. Brother James of Tuderto, when he heard the Passion of our Redeemer read, not only wept bitterly, but broke out into loud sobs, overcame with the love with which he was inflamed towards his beloved Lord.

II\.

It was this sweet study of the Crucifix which made St. Francis become a great seraph. He wept so continually in meditating on the sufferings of Jesus Christ, that he almost entirely lost his sight. On one occasion, being found crying out and weeping, he was asked what was the matter with him. \"What ails me?\" replied the Saint. \"I weep over the sorrows and insults inflicted on my Lord; and my sorrow is increased when I think on those ungrateful men who do not love Him, but live without any thought of Him.\" Every time that he heard the bleating of a lamb, he felt himself touched with compassion at the thought of the death of Jesus, the Immaculate Lamb, drained of every drop of Blood upon the Cross tor the sins of the world. And therefore this loving Saint could find no subject on which he exhorted his brethren with greater eagerness than the constant remembrance of the Passion of Jesus.

This, then, is the Book \-- Jesus crucified \-- which, if we constantly read it, will teach us on the one hand, to have a lively fear of sin, and, on the other hand, will inflame us with love for a God so full of love for us; while we read in these Wounds the great malice of sin, which reduced a God to suffer such a bitter death in order to satisfy the Divine justice, and the love which our Saviour has shown us in choosing to suffer so much in order to prove to us how much He loved us.

Let us beseech the Divine Mother Mary to obtain for us from her Son the grace that we also may enter into these furnaces of love, in which so many loving hearts are consumed, in order that, our earthly affections being there burnt away, we also may burn with those blessed flames, which render souls holy on earth and blessed in Heaven. Amen.
