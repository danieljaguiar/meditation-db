Twenty-fourth Sunday after Pentecost

## Morning Meditation

*\"COME YE BLESSED OF MY FATHER.\"*

*Come ye blessed of my Father!* (Matt. xxv. 34). Such will be the glorious sentence which in the day of triumph God will pronounce in favour of those who have loved Him. O faithful souls, who love God, be not troubled if you are despised and humiliated in this world. *Your sorrow shall be turned into joy!*

I.

*Come ye blessed of my Father!* (Matt. xxv. 34). Such will be the glorious sentence which in the day of triumph God will pronounce in favour of those who have loved Him. St. Francis of Assisi having had it revealed to him that he was one of the predestinate, almost died of the consolation which such a revelation afforded him. What, then, will be the joy of the elect when they hear Jesus Christ inviting them: Come, ye blessed children, come and possess the inheritance of your Divine Father! Come and reign with Him forever in Heaven!

How often, O God, have I, through my own fault, forfeited Thy blessed kingdom! But, O Jesus, Thy precious merits encourage me to hope that I shall regain it. My dear Redeemer, I trust in Thee and love Thee.

Oh, how will the Blessed congratulate one another when they behold themselves placed upon thrones and united in the enjoyment of God for all eternity, without the least fear of ever being again separated from Him! What joy and glory will be theirs to enter on that day crowned into Heaven, singing together songs of gladness and the sweet praises of God! Happy souls, that are destined to such a blessed lot!

O God of my soul, bind me to Thee with the sweet bonds of Thy holy love, so that I may enter into Thy kingdom and praise and love Thee forever. *The mercies of the Lord I will sing forever* (Ps. lxxxviii. 2).

II\.

Let us arouse our slumbering Faith! It is certain that we shall one day be judged, and that we shall receive sentence either of eternal life or of eternal death. If we be not secure of obtaining the sentence of life, let us endeavour now to make it certain. Let us fly from all those occasions which may expose us to the loss of our souls; and unite ourselves to Jesus Christ by frequently approaching the Sacraments, by pious meditations, by spiritual reading and continual prayer. The practice or neglect of these means will be the sign of our salvation or of our perdition.

My beloved Jesus, and my Judge, I hope through Thy Precious Blood that Thou wilt on that day bless me. Do Thou bless me now, and pardon me all the offences I have committed against Thee. Grant me to hear the same consoling words that Thou didst address to Magdalen: *Thy sins are forgiven thee* (Luke vii. 48). I am sorry with my whole heart for having offended Thee; pardon me, and at the same time give me grace always to love Thee. I love Thee, my sovereign Good; I love Thee more than myself, my Treasure, my Love, my All. *Thou art the God of my heart, and the God that is my portion forever* (Ps. lxxii. 26). O my God! Thee alone do I desire. Holy Mary, by thy powerful intercession thou canst procure my salvation, and thou desirest to do so. In thee do I confide.

## Spiritual Reading

*LOVE OF SOLITUDE*

Whosoever loves God, loves solitude. There the Lord communicates Himself more familiarly to souls, because there He finds them less entangled in worldly affairs, and more detached from earthly affections. Hence, St. Jerome exclaimed: \"O solitude, in which God speaks and converses familiarly with His servants.\" O blessed solitude, in which God speaks and converses with His beloved ones with great love and confidence! *The Lord is not in the earthquake* (3 Kings, xix. 11). But where is He found? *I will lead her into the wilderness, and I will speak to her heart* (Osee ii. 14). He is found in solitude and there He speaks to the heart in words that inflame it with holy love, as the sacred spouse attests: *My soul melted when my Beloved spoke* (Cant. v. 6). St. Eucherius relates that a certain man, desirous of becoming a saint, asked a servant of God where he should find God. The servant of God conducted him to a solitary place, and said: \"Behold where God is found!\" By these words he meant to say that God is found not amid the tumults of the world, but in solitude.

Virtue is easily preserved in solitude; and, on the other hand, it is easily lost by intercourse with the world, where God is but little known, and therefore His love, and the treasures He gives to those who leave all things for His sake, are but little esteemed. St. Bernard says that he learned more among the trees of the forest than from books and masters. Hence the Saints, in order to live in solitude and far from tumult, have so ardently loved the caves, the mountains, and the woods. *The land that was desolate and impassable shall be glad, and the wilderness shall rejoice, and shall flourish like the lily; it shall bud forth and blossom \... They shall see the glory of the Lord and the beauty of our God* (Is. XXXV. 1, 2). The wilderness shall be a perennial fountain of joy and gladness to the soul that seeks it; it shall flourish like the lily in whiteness and innocence of life, and shall produce fruits of every virtue. These happy souls shall in the end be raised on high to see the glory and infinite beauty of the Lord. It is certain that to keep the heart united with God we must preserve in the soul the thought of God, and of the immense reward He prepares for those who love Him. But when we hold intercourse with the world, it presents to us earthly things that obliterate spiritual impressions and pious sentiments.

Worldlings shun solitude, and with good reason; for in solitude they feel more acutely the remorse of conscience, and therefore they go in search of the conversations and bustle of the world, that the noise of these occupations may stifle the stings of remorse. It is true that man loves society; but what society is preferable to the society of God? Ah! to withdraw from creatures and to converse in solitude with our Creator brings neither bitterness nor tediousness. Of this the Wise Man assures us: *For her conversation hath no bitterness, nor her company any tediousness, but joy and gladness* (Wisd. viii. 16). The Venerable Father Vincent Carafa, General of the Society of Jesus, said that he desired nothing in this world, and that were he to desire anything he would wish only for a little grotto, a morsel of bread, and a spiritual book, in order to live there always in solitude.

It is not true that a life of solitude is a life of melancholy: it is a foretaste and beginning of the life of the Saints in bliss, who are filled with an immense joy in the sole occupation of loving and praising their God. St. Jerome tells us that flying from Rome he went to shut himself up in the Cave of Bethlehem, in order to enjoy solitude. Hence he afterwards wrote: \"To me solitude is a paradise.\" The Saints in solitude appear to be alone, but they are not alone. St. Bernard said: \"I am never less alone than when I am alone\"; for I am then in the company of my Lord, Who gives me more content than I could derive from the conversation of all creatures. They appear to be in sadness, but they are not sad. The world, seeing them far away from earthly amusements, regards them as miserable and disconsolate; but they are not so; they, as the Apostle attests, enjoy an immense and continual peace. *As sorrowful, yet always rejoicing* (2 Cor. vi. 10). The Prophet Isaias attested the same when he said: *The Lord therefore will comfort Sion, and will comfort all the ruins thereof; and he will make her desert as a place of pleasure, and her wilderness as the garden of the Lord. Joy and gladness shall be found therein, thanksgiving and the voice of praise* (Is. li. 3). The Lord well knows how to console the solitary soul, and will give a thousandfold compensation for all the temporal pleasures which it has forfeited: He will render its solitude the garden of His delights. There joy and gladness shall be always found, and nothing will be heard but the voice of thanksgiving and praise of the Divine goodness. Cardinal Petrucci describes the happiness of a solitary heart in the following words: \"It appears to be sad, and it is filled with celestial joy. Though it treads on the earth, its dwelling is in Heaven. It asks nothing for itself, because in its bosom it contains an immense treasure. It appears to be agitated and overwhelmed by the tempest, and it is always in a secure harbour.\"

In order to find this happy solitude, it is not necessary to hide yourself in a cave or in a desert. David found it, even in the midst of the great concerns of a kingdom, and therefore he said: *Lo, I have gone far off, flying away; and I abode in the wilderness* (Ps. liv. 8). St. Philip Neri desired to retire into a desert, but God gave him to understand that he should not leave Rome, but that he should live there as in a desert.

Hitherto we have spoken of the solitude of the body; we must now say something on the solitude of the heart, which is more necessary than the solitude of the body. \"Of what use,\" says St. Gregory, \"is the solitude of the body without the solitude of the heart?\" That is, of what use is it to live in the desert if the heart is attached to the world? A soul detached and free from earthly affections, says St. Peter Chrysologus, finds solitude even in the public streets and highways. On the other hand, of what use is it to observe silence if affections to creatures are entertained in the heart, and by their noise render the soul unable to listen to the Divine inspirations? I here repeat the words of our Lord to St. Teresa: \"Oh, how gladly would I speak to many souls, but the world makes such a noise in their hearts that My voice cannot be heard. Oh that they would retire a little from the world!\"

Let us then understand what is meant by solitude of the heart. It consists in expelling from the soul every affection that is not for God, by seeking nothing in all our actions but to please His Divine eyes. It consists in saying with David: *What have I in heaven? and besides thee, what do I desire upon earth? \... Thou art the God of my heart, and the God that is my portion forever* (Ps. lxxii. 25, 26). Except Thee, O my God, what is there on earth or in Heaven that can content me? Thou alone art the Lord of my heart, and Thou shalt always be my only Treasure. In fine, solitude of the heart implies that you can say with sincerity: My God, I wish for Thee alone, and for nothing else.

Someone complains that he does not find God; but listen to what St. Teresa says: \"Detach the heart from all things \-- seek God, and then you will find Him.\" God can neither be sought nor found if He is not first known; but what can a soul attached to creatures know of God and His Divine beauty? The light of the sun cannot enter a crystal vessel filled with earth; and in a heart occupied with attachment to pleasures and wealth and honours, the Divine light cannot shine. Hence the Lord says: *Be still, and see that I am God* (Ps. xlv. 11). The soul, then, that wishes to see God must remove the world from her heart, and keep it shut against all earthly affections. This is precisely what Jesus Christ gave us to understand under the figure of a closed chamber, when He said: *But when thou shalt pray, enter into thy chamber, and having shut the door, pray to thy Father in secret* (Matt. vi. 6). That is, the soul, in order to unite itself with God in prayer, must retire into its heart, which, according to St. Augustine, is the chamber of which our Lord speaks, and shut the door against all earthly affections.

This is also the meaning of the words of Jeremias: *He shall sit solitary, and hold his peace; because he hath taken it up upon himself* (Lam. iii. 28). The solitary soul, that is, the soul that is free from all attachments, and in which earthly affections are silent, will unite itself with God in Mental Prayer by holy desires, by oblations of itself, and by acts of love: and then it will find itself raised above all created objects, so that it will smile at the worldling who sets so high a value on the goods of this earth, and submits to so many toils in order to secure enjoyment of them, while it regards them as trifles, and utterly unworthy of the love of a heart created to love God, the infinite Good.

## Evening Meditation

*CHRIST, THE KING OF LOVE*

(FEAST OF CHRIST THE KING. LAST SUNDAY OF OCTOBER.)

I.

Through fear of losing his kingdom the wicked Herod sought the life of the Divine Child. St. Fulgentius contemplating little Jesus flying into Egypt, tenderly exclaims: \"Why art thou troubled, O Herod? The King Who is just now born comes not to overthrow other kings by force of arms, but to subjugate them by dying for them.\" As though he had said: The King of Heaven is not come to conquer us by war, but by love; He is not come to put us to death, but to rescue us from death by dying for us. Hence it is that Jesus may indeed be styled the King of Love.

Oh that I had always loved Thee, O Jesus, my sovereign King, and that I had never offended Thee! Thou didst spend thirty-three years in pain and labour to save me, and I have wilfully renounced Thee, my sovereign Good, for the sake of momentary pleasures! Father of mercy, forgive me, and embrace me with the kiss of peace.

Ungrateful Jews! why did you refuse to acknowledge for your King One so lovely and so loving towards you? Why did you exclaim: *We have no king but Caesar*? (Jo. xix. 15). Caesar did not love you, nor desire to die for you; while your true King Jesus descended from Heaven upon the earth to die for the love of you.

O sweet Saviour Christ, if others will not receive Thee as their King, I will have no other King but Thee: \"Jesus, Thou art my King.\" I know that Thou alone lovest me; Thou alone hast redeemed me with Thy Blood; where then shall I find one who has loved me as Thou hast loved me? I am grieved for having hitherto rejected Thee as my King by rebelling against Thee! Pardon me, O Jesus, my King! for Thou hast died to purchase pardon for me.

II\.

*To this end Christ died and rose again; that he might be Lord both of the dead and of the living* (Rom. xiv. 9).

My beloved King, dearest Jesus, since Thou camest upon earth to gain our hearts to Thyself, if hitherto I have resisted Thy loving calls, I will now no longer resist them. Do not disdain to accept me; I now give myself to Thee, I give Thee my whole self. Take, O my King, possession of my whole will, and of my whole self. Make me loyal to Thee; and grant that I may rather die than betray Thee any more, O my King, my Love, my only Good. O Queen, and Mother of my King, O Mary, obtain for me that I may be faithful to what I this day promise to thy Divine Son.

O KING OF HEAVEN

O King of Heaven, from starry throne descending,\

Thou takest refuge in this wretched cave;\

O God of bliss! I see Thee cold and trembling!\

What pain it cost Thee fallen man to save!

Thou, of a thousand worlds the great Creator,\

Dost now the pain of cold and want endure;\

Thy poverty but makes Thee more endearing,\

For well I know \'tis love has made Thee poor.

I see Thee leave Thy Heavenly Father\'s bosom,\

But whither has Thy love transported Thee?\

Upon a little straw I see Thee lying;\

Why suffer thus? \'Tis all for love of me.

But if it is Thy will for me to suffer,\

And by these sufferings my heart to move,\

Wherefore, my Jesus, do I see Thee weeping?\

\'Tis not for pain Thou weepest, but for love.

Thou weepest thus to see me so ungrateful;\

My sins have pierced Thee to the very core;\

I once despised Thy love, but now I love Thee,\

I love but Thee; then, Jesus, weep no more.

Thou sleepest, Lord, but Thy Heart ever watches,\

No slumber can a heart so loving take;\

But tell me, darling Babe, of what Thou thinkest,\

\"I think,\" He says, \"of dying for thy sake.\"

Is it for me that Thou dost think of dying!\

What, then, O Jesus! can I love but Thee?\

Mary, my hope! If I but love Him little\--\

Be not indignant \-- love Him thou for me.
