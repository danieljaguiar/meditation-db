# Friday after Septuagesima

## Morning Meditation

*HE THAT LOVES JESUS CHRIST SHOULD HATE THE WORLD.*

St. Paul writes that Jesus Christ gave Himself for our sins that He might deliver us from the present wicked world according to the will of God and our Father. (Gal. i. 4). As the lovers of God are hateful to the world, so the world ought to be hateful to him who loves God. Jesus Christ desires we should become superior to the promises and threats of the world and no longer take account of its censures or its praise.

I.

Whosoever loves Jesus Christ with true love, let him greatly rejoice when he sees himself treated by the world as Jesus Christ was treated. He was hated, scorned, and persecuted by the world, even unto an agonising death upon a shameful Cross. The world is altogether against Jesus Christ; and, therefore, hating Jesus Christ, it hates all His servants. Wherefore the Lord encouraged His disciples to suffer in peace all the persecutions of the world, saying to them that, having given up the world, they could not but be hated by the world. *Ye are not of the world, therefore the world hateth you* (Jo. xv. 19).

And as the lovers of God are hateful to the world, so the world ought to be hateful to him who loves God. St. Paul said: *God forbid that I should glory, save in the cross of our Lord Jesus Christ, by whom the world is crucified to me* (Gal. vi. 14). The Apostle was an odious thing to the world, as a man condemned and dead upon a cross is odious; and in return, the world was odious to St. Paul: *The world is crucified to me.*

Jesus Christ chose to die upon the Cross for our sins, for this end, that He might deliver us from this wicked world. Our Lord, having called us to His love, desires that we should become superior to the promises and threats of the world. He desires that we should no longer take account of its censures or its praise. We must pray God to make us utterly forget the world, and to rejoice when we see the world reject us. It is not enough, in order to belong wholly to God, that we should abandon the world; we must desire that the world should abandon us, and utterly condemn us. Some people leave the world, but they do not cease to wish to be praised by it, at least for having abandoned it. In such persons the desire of worldly estimation causes the world still to live in them.

II\.

Thus, then, the world hates the servants of God, and hates their good example and holy maxims; and therefore it is necessary that we should hate all the maxims of the world. *The wisdom of the flesh is an enemy to God, for it is not subject to the law of God, neither can it be* (Rom. viii. 7). The Apostle says *it cannot be*, for this reason, that the world has no other object but its own interest or pleasure; and thus it cannot agree with those who seek only to please God.

Yea, O Jesus, crucified and dead for me, Thee alone I desire to please. What is the world, what are riches, what are honours? I desire that Thou, my Redeemer, shouldst be all my Treasure; to love Thee is my riches. If Thou wilt have me poor, I desire to be poor; if Thou wilt have me humbled and despised by all, I embrace all and receive all from Thy hands. Thy will shall ever be my comforter. This is the grace that I seek of Thee, that in every event I may never depart an instant from Thy holy will.

## Spiritual Reading

*THE PRACTICE OF THE CHRISTIAN VIRTUES*

IX\. \-- MEANS OF ACQUIRING THE LOVE OF JESUS CHRIST

Jesus Christ ought to be our whole love. He is worthy of it, both because He is a God of infinite goodness, and because He has loved us to such an excess, that He died for us. Oh, what a great obligation we are under to Jesus Christ! All the good we enjoy, all our inspirations, calls, pardons, helps, hopes, consolations, sweetnesses, and loving affections, come to us through Jesus Christ. Let us see by what means we are to acquire this love of Jesus Christ.

In the first place, we must *desire* to have this love of Jesus Christ, and we must, therefore, often ask Him to give it to us, especially in our prayers, in our Communions, and in the Visit to the Blessed Sacrament. And this grace must also be sought through the hands of the ever-blessed Mary, from our Guardian Angel and our holy Patrons, that they may enable us to love Jesus Christ. St. Francis de Sales says that the grace of loving Jesus Christ contains all other graces in itself; because he who truly loves Jesus Christ cannot be wanting in any virtue.

In the second place, if we wish to acquire the love of Jesus Christ, we must detach our hearts from all earthly affections; Divine love will find no place in a heart that is full of this world. St. Philip Neri used to say: \"The love we give to creatures is all so much taken from God.\"

In the third place, we must often exercise ourselves, especially when we pray, in making acts of the love of Jesus Christ. Acts of love are the fuel with which we keep alive the fire of holy charity. Let us make acts of love and complacency, saying: \"My Jesus, I rejoice that Thou art infinitely happy, and that Thy Eternal Father loves Thee as much as Himself.\" Of benevolence: \"I wish, my Jesus, that all could know and love Thee.\" Of predilection, as: \"My Jesus, I love Thee more than all things! I love Thee more than myself!\" Let us also often make acts of contrition, which are called acts of sorrowful love.

In the fourth place, if any one wishes to make sure of being inflamed with love towards Jesus Christ, let him try to meditate often on His Passion. It was revealed to a holy solitary, that no exercise was more efficacious in enkindling love, than the consideration of the sufferings and ignominy which Jesus Christ endured for love of us. I say, it is impossible that a soul, meditating often on the Passion of Jesus Christ, should be able to resist His love. It was for this that, although He could have saved us by one drop of His Blood, nay even by a single prayer, He chose to suffer so much, and to shed all His Blood, that He might attract all hearts to love Him; therefore he who meditates on His Passion does what is very agreeable to Him. Do you, then, often make your Meditation on the Passion of our Lord Jesus Christ. Do so at least every Friday, the day on which He died for the love of us. For this purpose I have written many Meditations on the Passion of Our Lord Jesus Christ, especially the *Darts of Fire,* which speak of the love Jesus Christ has borne us in the great work of our Redemption.

## Evening Meditation

*DIVINE LOVE VICTORIOUS OVER GOD HIMSELF*

I.

Our God is omnipotent: who, then, will ever overcome and conquer Him? Love towards man has conquered and triumphed over Him, says St. Bernard. For His love has caused Him to die in torments upon a disgraceful Cross to secure man\'s salvation. O infinite Love! Unhappy the soul that loves Thee not!

What man, not a believer, passing by Calvary on that day when Jesus was dying on the Cross, and enquiring who was that *criminal*, crucified in such a mangled state, was told it was the Son of God, true God, equal with His Father, would not have said with the Gentiles that to believe such things was folly? \"It appeared folly,\" says St. Gregory, \"that the Author of life should die for men.\" If it would have appeared folly to suppose that a king would become a worm for the love of a worm, greater still would have appeared the folly of believing that God had become Man for the love of man, to die for man. This led St. Mary Magdalen de Pazzi to say, concerning this immense love of God, \"My Jesus, Thou lovest us to madness.\"

And, alas! I, a miserable sinner, have not loved God, but have many times offended Him!

II\.

Christian, lift up your eyes, and behold that afflicted one upon the Cross, oppressed with grief and torments, struggling in His agony, on the point of expiring, dying for the pure love of you. Know you who He is? He is your God. And if you believe that He is your God, ask who has reduced Him to such a miserable condition. \"What has done this?\" asks St. Bernard. He answers: \"Love has done it, regardless of its own dignity.\" It was love, which refuses no pain, or disgrace, when it would make itself known and exert itself for its beloved.

O Jesus, it was because Thou didst so much love me, that Thou didst suffer so much for me: if Thou hadst loved me less Thou wouldst have suffered less. I love Thee, my dear Redeemer, with my whole heart. And how can I refuse God my whole love, when He has not refused me His Precious Blood, His life? I love Thee, O Jesus, my Love, my All! Holy Mary, Virgin of virgins, help me by thy prayers faithfully to love Jesus.
