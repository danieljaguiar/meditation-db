# Thursday\--Second Week of Advent

## Morning Meditation

*CONSIDERATIONS ON THE RELIGIOUS STATE. IV.*

*Consider the torments of the soul of one in hell who lost his Vocation.*

He will say: O fool that I was! I might have become a great Saint! And if I had obeyed the Call of God I should certainly have become a Saint, and now I am damned without remedy! Make your choice, for God leaves it in your own hands, to be a great king in Paradise, or a reprobate in hell.

I.

The remorse for having lost, by one\'s own fault, some great good, or for having been the voluntary cause of some great evil to ourselves, is so great that even in this life it is an insupportable torment. But what torment will that youth, called by the singular favour of God to the Religious state, feel in hell when he perceives that if he had obeyed God he would have attained a high place in Paradise, and sees himself nevertheless confined in that prison of torments, without hope of remedy for this his eternal ruin! *Their worm dieth not* (Mark ix. 43).

This will be that worm, which, living always, will always gnaw his heart by continual remorse. Fool that I was! he will say, I might have become a great Saint. And if I had obeyed, I should certainly have become a Saint; and now I am damned without remedy.

Unfortunate man! For his greater torment, on the Day of Judgment, he will see and recognise at the right hand of God and crowned as Saints, those who followed their Vocation, and, leaving the world, retired to the House of God, to which he also had been called. He shall see himself separated from the company of the Blessed, and placed in the midst of that innumerable and miserable crew of the damned, for his disobedience to the voice of God.

No, my God, permit me not to disobey Thee and to be unfaithful. I see Thy goodness, and thank Thee, for instead of casting me away from Thy face, and banishing me to hell, as I have so often deserved, Thou callest me to become a Saint, and preparest for me a high place in Paradise. I see that I should deserve a double torment, should I not correspond with this grace \-- a grace not given to all. I will obey Thee. Behold, I am Thine, and always will be Thine. I embrace with joy all the pains and discomforts of the Religious life, to which Thou invitest me. And what are these pains in comparison with the eternal pains, which I have deserved? I was entirely lost through my sins; now I give myself entirely to Thee. Dispose of me and my life as Thou pleasest.

II\.

We know well, as we have considered above, that to this most unhappy lot he exposes himself, who, in order to follow his own caprice, turns a deaf ear to the call of God. Therefore, my brother, you who have already been called to become a Saint in the House of God, consider that you will expose yourself to a great danger should you lose your Vocation through your own fault. Consider that this very Vocation which God in His Sovereign Bounty has given you, in order, as it were, to take you out from among the crowd, and place you among the chosen princes of His Paradise, will, through your own fault, should you be unfaithful to it, become a special hell for you. Make your own choice, then, for now God leaves it in your own hands, either to be a great king in Paradise, or a reprobate in hell, more full of despair than the rest.

Accept, O Lord, of one already at the gates of hell, as I have been, to serve Thee and love Thee in this life and in the next. I will love Thee as much as I have deserved to be doomed to hate Thee in hell, O God, worthy of an infinite love! O my Jesus Thou hast broken those chains by which the world held me captive; Thou hast delivered me from the servitude of my enemies. I will love Thee much, then, O my Love! and for the love I bear thee, I will always serve Thee and obey Thee. I will always thank thee, O Mary, my advocate, who hast obtained this mercy for me. Help me, and suffer me not to be ungrateful to that God Who has loved me so much. Obtain for me that I may die rather than be unfaithful to so great a grace. This is my hope.

## Spiritual Reading

*COUNSELS CONCERNING A RELIGIOUS VOCATION*

IV\. THE MEANS TO BE EMPLOYED TO PRESERVE A RELIGIOUS VOCATION

*Secrecy* (continued)

If, then, it would be a great mistake to ask the *advice* of parents in following one\'s Vocation, it would be a greater error still to ask their *permission* to follow it, and wait for their consent; for there would be an evident danger of losing the Vocation in so doing when there is a likely suspicion that parents would exert themselves to prevent it. Thus St. Thomas Aquinas acted, and St. Francis Xavier, St. Philip Neri and St. Louis Bertrand. And we know that the Lord approved, even by miracles, of their glorious flight.

St. Peter of Alcantara, when he went to the monastery to become a Religious, and was fleeing from the house of his mother under whose obedience he had lived since the death of his father, found himself prevented by a wide river from advancing any further. He recommended himself to God, and at the same instant saw himself transported to the other side.

In like manner, when St. Stanislaus Kotska fled from home, without the permission of his father, his brother set out after him in great haste in a carriage, but having almost overtaken him, the horses, in spite of all the violence used against them, would not advance a step further, till turning back towards the city, they began to travel at full speed.

In like manner the Blessed Oringa of Valdarno, in Tuscany, being promised in marriage to a young man, fled from the house of her parents in order to consecrate herself to God; but she was stopped by the river Arno. After a short prayer she saw it divide and form, as it were, two walls of crystal, to let her pass through with dry feet.

Therefore, my very beloved brother, if you are called by God to leave the world, be very careful not to make your resolution known to your parents, and, content to be thus blessed by God, seek to execute it as promptly as you can, and without their knowledge, if you would not expose yourself to the great danger of losing your Vocation. For, generally speaking, relatives, as has been said before, especially fathers and mothers, oppose the execution of such resolutions; and although they may be endowed with piety, nevertheless, interest and passion render them so blind that under various pretexts they scruple not to thwart with all their might the Vocation of their children.

We read in the Life of Father Paul Segneri, the Younger, that his mother, though a matron much given to prayer, left, nevertheless, no means untried to prevent her son from entering the Religious state to which he was called. We also read in the life of Mgr. Cavalieri, Bishop of Troja, that his father, although a man of great piety, used every means to prevent his son from entering the Congregation of Pious Workers (which, notwithstanding, he afterwards did), and even went so far as to bring against him a lawsuit in the Ecclesiastical Court. And how many other fathers, even though they were men of piety and prayer, have not in such cases been seen to change, and to become possessed, as it were, by the devil! For under no other circumstances does hell seem to employ more formidable arms than when there is a question of preventing those who are called to the Religious state from executing their resolution.\*

For this reason be also very careful not to communicate your design to your friends, who will not scruple to dissuade you from it, or at least, to divulge the secret, so that the knowledge of it will easily come to the ears of your parents.

\*St. Alphonsus had himself to suffer great opposition in following his Vocation. No one opposed him more than his own father. The mere thought of the separation broke the father\'s heart. One afternoon he entered the room of Alphonsus and taking him in his arms, cried out with sobs: My son, my son, why will you abandon me? What have I done that you should give me so much pain? Why should I be treated so? Have pity on me, and do not abandon me!\" This struggle with a father\'s love lasted three long hours. Father and child were torn with grief. Alphonsus conquered; but he could never afterwards think of that struggle of three hours without a shudder. \--EDITOR.

## Evening Meditation

*JESUS SUFFERS DURING HIS WHOLE LIFE.*

I.

*My sorrow is continually before me* (Ps. xxxvii. 18).

Consider that all the sufferings and ignominy that Jesus endured in His life and death were present to Him from the first moment of His life: *My sorrow is continually before me*; and even from His childhood He began to offer them in satisfaction for our sins, beginning even then to fulfil His office as Redeemer. He revealed to one of His servants that from the commencement of His life even unto His death He suffered continually; and suffered so much for each of our sins that if He had had as many lives as there are men, He would as many times have died of sorrow, if God had not preserved His life that He might suffer more.

Oh, what a martyrdom did not the loving Heart of Jesus constantly endure in beholding all the sins of men! He beheld every single fault. Even whilst He was in the womb of Mary every particular sin passed in review before Jesus, and each sin afflicted Him immeasurably. St. Thomas says that this sorrow which Jesus Christ felt at the knowledge of the injury done to His Father, and of the evil that sin would occasion to the souls that He loved, surpassed the sorrows of all the contrite sinners that ever existed, even of those who died of pure sorrow; because no sinner ever loved God and his own soul as much as Jesus loved His Father and our souls.

Behold, my Jesus, at Thy feet, the ungrateful sinner, the persecutor who kept Thee in continual affliction during all Thy life. But I will say to Thee with Isaias: *But thou hast delivered my soul that it should not perish; thou hast cast all my sins behind thy back* (Is. xxxviii. 17). I have offended Thee. I have wounded Thee by so many sins; but Thou hast not refused to take upon Thy shoulders all my offences. I have voluntarily cast my soul into the fire of hell every time that I have consented to offend Thee gravely; and Thou, at the cost of Thy own Blood, hast continually liberated me and prevented me from being entirely lost. My beloved Redeemer, I thank Thee.

II\.

Wherefore that agony which our Redeemer suffered in the Garden at the sight of our sins was endured by Him even from His Mother\'s womb: *I am poor, and in labours from my youth* (Ps. lxxxvii. 16). Thus through the mouth of David did our Saviour prophesy of Himself that all His life would be a continual suffering. From this St. John Chrysostom deduces that we ought not to afflict ourselves for anything but for sin alone; and that since Jesus was afflicted all His life long on account of our sins, so we who have committed them ought to feel a continual sorrow for them, remembering that we have offended God Who has loved us so much. St. Margaret of Cortona never ceased to shed tears for her sins. One day her confessor said to her: \"Margaret, no more tears! It is enough \-- Our Lord has already forgiven thee.\" \"What!\" answered the Saint, \"how can my tears and my sorrows suffice for the sins for which my Jesus was afflicted all His life long!\"

O my Jesus, I could wish to die of sorrow when I think how I have abused Thy infinite goodness; forgive me, my Love, and come and take entire possession of my heart. Thou hast said that Thou wouldst not disdain to enter into the abode of him that opens to Thee, and to remain in his company: *If any man shall open to me the door, I will come in to him, and will sup with him* (Apoc. iii. 20). If I have hitherto driven Thee away from me, I now love Thee and desire nothing but Thy favour. Behold, the door is open, enter Thou into my heart, but enter never to depart from it again. I am poor; but if Thou enter Thou wilt make me rich. I shall always be rich so long as I possess Thee, the Sovereign Good. O Queen of Heaven, sorrowful Mother of this suffering Son, I also have been a cause of sorrow to thee, because thou hast participated, in great measure, in the sufferings of Jesus. My Mother, do thou also forgive me, and obtain for me the grace to be faithful to thee, now that I hope my Jesus has returned into my soul.
