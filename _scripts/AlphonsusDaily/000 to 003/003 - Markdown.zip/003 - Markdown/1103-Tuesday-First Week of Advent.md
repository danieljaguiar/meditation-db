# Tuesday\--First Week of Advent

## Morning Meditation

*THE GREAT AFFAIR OF SALVATION*

Consider that our most important affair is that of our eternal salvation. Upon our eternity depends our happiness or misery for ever. Whether we shall live for ever happy or for ever miserable.

*Before man is life and death \... that which he shall choose shall be given him.* (Ecclus. xv., 18).

Oh, let us make such a choice now as we shall not have to regret in eternity.

I.

The affair of our eternal salvation is of all affairs the most important. But how comes it that men use all diligence to succeed in the affairs of this world, leave no means untried to obtain a desirable situation, to gain a lawsuit, or to bring about a marriage; reject no counsels, neglect no measures by which to secure their object; neither eat nor sleep, and yet do nothing to gain eternal salvation \-- nothing to gain it, but everything to forfeit it, as though *Hell, Heaven*, and *Eternity* were not Articles of Faith, but only fables and lies?

O God! assist me by Thy divine light; suffer me not to be any longer blinded, as I hitherto have been.

If an accident happen to a house, what is not immediately done to repair it? If a jewel be lost, what is not done to recover it? The soul is lost, the grace of God is lost, and men sleep and laugh! We attend most carefully to our temporal welfare, and almost entirely neglect our eternal salvation! We call those happy who have renounced all things for God; why then are we so much attached to earthly things?

O Jesus! Thou hast so much desired my salvation as to shed Thy Blood and lay down Thy life to secure it; and I have been so indifferent to the preservation of Thy grace as to renounce and forfeit it for a mere nothing! I am sorry, O Lord, for having thus dishonoured Thee. I will renounce all things to attend only to Thy love, my God, Who art most worthy of all love.

II\.

The Son of God gives His life to save our souls; the devil is most diligent in his endeavours to bring them to eternal ruin: and what care do we take of them? St. Philip Neri convicts that man of the height of folly who is inattentive to the salvation of his soul. Let us rouse our Faith: it is certain that, after this short life, another life awaits us, which will be either eternally happy or eternally miserable. God has given us to choose which we will. *Before man is life and death \... that which he shall choose shall be given him.* Ah! let us make such a choice now as we shall not have to repent of for all eternity.

O God, make me sensible of the great wrong I have done Thee in offending Thee and renouncing Thee for the love of creatures. I am sorry with my whole heart for having despised Thee, my sovereign Good; do not reject me now that I return to Thee. I love Thee above all things, and for the future I will renounce all things rather than lose Thy grace. Through the love which Thou hast shown me in dying for me, succour me with Thy help, and do not abandon me. O Mary, Mother of God, be thou my advocate.

## Spiritual Reading

*MENTAL PRAYER*

I. ITS IMPORTANCE

In the first place, Mental Prayer is necessary in order that we may have light on the journey we are making towards eternity. The Eternal Truths are spiritual things which are not seen with the eyes of the body, but only in the mind by consideration. He that does not meditate does not see them; therefore he walks with difficulty on the way of Salvation. And further, he who does not meditate does not know his defects, and therefore, says St. Bernard, does not detest them. So also, he does not see the danger to Salvation in which he is, and therefore does not think of avoiding it. God enlightens us in Meditation. *Come ye to him and be enlightened.* (Ps. xxxiii., 6). In Meditation God speaks to us and makes us know what we are to avoid and what we are to do. *I will lead her into solitude and I will speak to her heart.* (Osee, ii., 14). St. Bernard says that Meditation regulates our affections, directs our actions and corrects our defects.

In the second place, without Mental Prayer we have no strength to resist temptation and practise virtue. St. Teresa used to say that when a man leaves off Mental Prayer, the devil has no need of carrying him to hell, for he throws himself into it of his own accord. And the reason is, that without Meditation there is no prayer. God is most willing to give us His graces; but St. Gregory says that before giving them He desires to be asked, and, as it were, compelled to give them through our prayers. But without Meditation there is no light: we walk in darkness, and walking in darkness, we do not see the danger we are in, we do not make use of the means to avoid it, or pray to God to help us, and so we are lost. Cardinal Bellarmine declared it to be morally impossible for a Christian who does not meditate to persevere in the grace of God: whereas he who makes his Meditation every day can scarcely fall into sin \-- and if unhappily he should fall occasionally, by continuing his prayer he will return immediately to God. It was said by a servant of God that \"Mental Prayer and mortal sin cannot exist together.\"

And further, Meditation is the blessed furnace in which souls are inflamed with divine love. *In my meditation*, says the Psalmist, *a fire shall flame out* (Ps. xxviii., 4). St. Catherine of Bologna said: \"Meditation is that bond which binds the soul to God.\" In Meditation the soul, retiring to converse alone with God, is raised above itself. *He shall sit solitary and hold his peace* (Lam. ii., 28), says the Prophet Jeremias. When the soul sits solitary, that is, remains alone in Meditation to consider how worthy God is of love, and how great is the love He bears to it, it will then relish the sweetness of God and fill its mind with holy thoughts. There it will detach itself from earthly affections; there it will conceive great desires to become holy, and finally resolve to give itself wholly to God. And where have the Saints made those generous resolutions which have lifted them up to a sublime degree of perfection, if not in Mental Prayer? St. Aloysius Gonzaga used to say that no one will ever attain a high degree of perfection who is not given to much Mental Prayer.

Let us; then, devote ourselves to it, and not neglect it on account of any weariness that we may experience: the weariness which we endure for God will be abundantly recompensed by Him.

Resolve, then, to make every day, either in the morning or in the evening \-- but it is better in the morning \-- half an hour\'s Meditation. In tomorrow\'s \"Spiritual Reading\" you will see briefly explained an easy method of making this Prayer. For the rest it is sufficient that during the time you should recollect yourself by reading some book of Meditation \-- either this one or one of the many others \-- and from time to time excite some good affection or some aspiration as will be explained in the Method. Above all I beg you never to leave off Mental Prayer, which you should practise at least once a day, although you may be in great aridity and feel great weariness in performing it. *If you do not discontinue it you will certainly be saved.*

## Evening Meditation

*THE LOVE OF GOD FOR MEN*

I.

*God so loved the world as to give his only-begotten Son.* (St. John iii., 16).

Consider that the Eternal Father, in giving us His Son for a Redeemer, the victim and price of our ransom, could not give us stronger motives for hope and love, to inspire us with confidence, and to oblige us to love Him. \"In giving us His Son,\" says St. Augustine, \"He could give us nothing more.\" He desires that we should avail ourselves of this immense Gift in order to gain for ourselves eternal Salvation, and every grace that we want; for in Jesus we find all that we can desire; we find light, strength, peace, confidence, love, and eternal glory; for Jesus Christ is a Gift which contains all the gifts that we can seek for or desire. *How hath he not also, with him, given us all things?* (Rom. vii., 32). God having given us His beloved only begotten Son, Who is the fountain and treasure of all good, who could fear that He would deny us any favour that we ask of Him?

O Eternal God! who could ever have given us this treasure of infinite value, but Thou, Who art a God of infinite love? O my Creator, what more couldst Thou have done to give us confidence in Thy mercy, and to put us under an obligation of loving Thee? O Lord, I have repaid Thee with ingratitude; but Thou hast said: *To them that love God all things work together unto good* (Rom. viii., 28). Therefore, notwithstanding the great number and the enormity of my sins, I will not despair of Thy bounty; rather let my transgressions serve to humble me the more whenever I meet with any insult; insults and humiliations does he indeed deserve who has had the temerity to offend Thy divine Majesty. I wish that my sins may serve to reconcile me more to the crosses which Thou shalt send me, that I may be more diligent in serving and honouring Thee in order to compensate for the injuries I have committed against Thee. O my God, I will always remember the displeasure I have caused Thee in order that I may the more exalt Thy mercy and be inflamed with love for Thee.

II\.

*Christ Jesus is of God made unto us wisdom, and justice, and sanctification, and redemption.* (1 Cor. i., 30). God hath given Jesus to us in order that He might be to us ignorant and blind creatures light and wisdom, wherewith to walk in the way of salvation; in order that to us who are deserving of hell He might be justice, enabling us to aspire to Paradise; that to us sinners He might be sanctification, to obtain for us holiness; that finally, to us slaves of the devil He might be a ransom to purchase for us the liberty of the sons of God. In short, the Apostle says that with Jesus Christ we have been enriched with every good gift and every grace, if we ask it through His merits: *In all things you are made rich in him \... so that nothing is wanting to you in any grace.* (1 Cor. i., 5).

And this gift which God has made us of His Son is a gift to each one of us; for He hath given Him entirely to each of us, as if He had given Him to each one alone, so that every one of us may say: Jesus is all mine; His body is mine; His blood is mine; His life is mine; His sorrows, His death, His merits, are all mine. Wherefore St. Paul said: *He loved me and delivered himself for me.* (Gal. ii., 20). And every one may say the same thing: \"My Redeemer has loved me; and for the love that He bore me He has given Himself entirely to me.\"

My God, my God, how can I ever leave off loving Thee and separate myself again from Thy love! I repent, and will always repent of the outrages I have committed against Thee; I depend upon Thee to help me. O my God, for Thy Glory\'s sake, vouchsafe to grant that, as I have offended Thee much I may also love Thee much!

O Mary, my Queen, do thou assist me. Thou knowest my weakness. Grant that I may have recourse to thee whenever the devil tries to separate me from God. My Mother, my hope, do thou help me. Amen.
