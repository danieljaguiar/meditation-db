# The Feast of the Epiphany

*(January 6th)*

## Morning Meditation

*THEY FOUND THE CHILD WITH MARY, HIS MOTHER.*

*They found the child with Mary, his mother* (Matt. ii. 11). The kings find a poor Maiden, and her poor Infant wrapped in poor swaddling-clothes, and not one to attend on Him or assist Him. They adore, they acknowledge Him for their God, and, kissing His feet, they offer Him their gifts of Gold, Frankincense and Myrrh. Let us adore our little King, and offer Him all our hearts.

I.

The Son of God is born humble and poor in a stable. There indeed the Angels of Heaven acknowledge Him, singing: *Glory to God in the highest* (Luke ii. 14); but men on earth, for whose salvation Jesus is born, leave Him neglected: only a few shepherds come and acknowledge Him, and confess Him to be their Saviour. But our loving Redeemer desires from the very beginning to communicate to us the grace of Redemption, and therefore He begins to make Himself known even to the Gentiles, who neither knew Him nor looked for His coming. For this purpose He sends the star to give notice to the holy Magi, enlightening them at the same time with interior light, in order that they may come to acknowledge and adore their Redeemer. This was the first and sovereign grace bestowed upon us; our call to the true Faith.

O Saviour of the world, what would have happened us if Thou hadst not come to enlighten us? We should be like our forefathers, who worshipped as gods, animals, stones, and wood, and consequently we should have all been damned. I give Thee thanks today on behalf of all men.

II\.

Behold, the Magi without delay set out on their journey; and led by the star they arrive at the place where the Holy Infant is lying: *They found the child with Mary his mother* (Matt. ii. 11). They find there only a poor Maiden, and a poor Infant wrapped in poor swaddling-clothes. But on entering into that abode, a stable for beasts, they feel an interior joy, and their hearts are drawn towards this sweet Infant. The straw, the poverty, those cries of the Infant Saviour, are all darts of love and fire to their enlightened hearts.

The Infant looks upon these holy pilgrims with a joyful countenance, and thus shows that He accepts these first-fruits of His Redemption. The divine Mother is also silent, but welcomes them wth her smiling looks, and thanks them for the homage done to her Son. They adore Him also in silence, and acknowledge Him for their Saviour and their God, offering Him gifts of Gold, Frankincense and Myrrh.

Yes, my Infant Jesus, the more humbled and poor I behold Thee, the more dost Thou inflame me with Thy love.

O Jesus, my Infant King! I also adore Thee, and offer Thee my miserable heart. Accept it and change it. Make it wholly Thine own, so that it may love nothing but Thee. My sweet Saviour, save me, and let my eternal happiness be to love Thee always and without reserve. O Mary, most holy Virgin, I hope for this grace from thee.

## Spiritual Reading

*\"LO, HERE AM I, SEND ME!\"*

The Eternal Word became Man in order to inflame us with His divine love. Adam, our first parent, sinned. Ungrateful for the benefits bestowed upon him, he rebelled against God by a violation of the precept given him not to eat of the forbidden fruit. On this account God is obliged to drive him out of the earthly paradise in this world, and in the world to come to deprive not only Adam, but all the descendants of this rebellious creature, of the heavenly and everlasting Paradise which He had prepared for them after this mortal life.

Behold, then, all mankind together condemned to a life of pain and misery, and forever shut out from Heaven. But hearken to God, Who, as Isaias tells us, would seem, after our manner of understanding, to give vent to His affliction in lamentations: *And now what have I here, saith the Lord, for my people is taken away gratis* (Is. lii. 5). \"And now,\" says God, \"what delight have I left in Heaven, now that I have lost men who were My delight?\" *My delights were to be with the children of men* (Prov. viii. 31).

But how is this, O Lord? Thou hast in Heaven so many Seraphim, so many Angels; and canst Thou thus take to heart having lost men? Indeed, what need hast Thou of Angels or of men to fill up the sum of Thy happiness? Thou hast always been, and Thou art in Thyself, most happy; what can ever be wanting to Thy bliss, which is infinite? \"That is all true,\" says God, \"but\" (and these are the words of Cardinal Hugo on the above text of Isaias) \-- \"but, losing man, I deem that I have nothing.\" I consider that I have lost all, since My delights were to be with men; and now I have lost these men, and, poor hapless creatures, they are doomed to live forever far away from Me.

But how can the Lord call men His delight? Yes, indeed, writes St. Thomas, God loves man just as if man were His God, and as if without man He could not be happy; \"as if man were the God of God Himself, and without him He could not be happy.\" St. Gregory of Nazianzen adds, moreover, that God, for the love He bears to men, seems beside Himself: \"we are bold to say it, God is out of Himself by reason of His immense love.\" So runs the proverb: \"Love puts the lover beside himself.\"

And here St. Bernard, in his contemplations on this subject, imagines a struggle to ensue between the *Justice* and *Mercy* of God. *Justice* says: \"I perish if Adam die not.\" *Mercy*, on the other hand, says: \"I perish if he does not obtain forgiveness.\" In this contest the Lord decides, that in order to deliver man, who was guilty of death, some innocent one must die \"Let one die who is no debtor to death.\"

On earth, there was not one innocent. \"Since, therefore,\" says the Eternal Father, \"amongst men there is none can satisfy My Justice, let Him come forward Who will go to redeem man.\" The Angels, the Cherubim, the Seraphim \-- all are silent; not one replies. One voice alone is heard, that of the Eternal Word, Who says: *Lo, here am I; send me* (Is. vi. 8). \"Father,\" says the Only-Begotten Son, \"Thy Majesty, being infinite, and having been injured by man, cannot be fittingly satisfied by an Angel, who is merely a creature; and though Thou mightest accept of the satisfaction of an Angel, reflect that, in spite of so great benefits bestowed on man, in spite of so many promises and threats, We have not yet been able to gain his love, because he is not yet aware of the love We bear him. If We would oblige him to love Us, what better occasion can we find than that, in order to redeem him, I, Thy Son, should go upon earth, should there assume human flesh, and pay by my death the penalty due by him. In this manner Thy justice is fully satisfied, and at the same time man is fully convinced of Our love!\" \"But think,\" answered the Heavenly Father \-- \"think, O My Son, that in taking upon Thyself the burden of man\'s satisfaction, Thou wilt have to lead a life full of sufferings!\" \"It matters not,\" replied the Son: *Lo, here am I, send me.* \"Think that Thou wilt have to be born in a cave, the shelter of the beasts of the field; thence Thou must flee into Egypt whilst still an Infant, to escape the hands of those very men who, even from Thy tenderest Infancy, will seek to take away Thy life.\" \"It matters not: *Lo, here am I, send me*.\" \"Think that, on Thy return to Palestine, Thou shalt there lead a life most arduous, most despicable, passing Thy days as a simple boy in a carpenter\'s shop.\" \"It matters not: *Lo, here am I, send me*.\" \"Think that when Thou goest forth to preach and to manifest Thyself, Thou wilt have indeed a few, but very few, to follow Thee; the greater part will despise Thee and call Thee impostor, magician, fool, Samaritan; and finally, they will persecute Thee to such a pass that they will make Thee die shamefully on a gibbet by dint of torments.\" \"It matters not: *Lo, here am I, send me*.\"

So, then, for us miserable worms, and to captivate our love, has a God deigned to become Man? Yes, it is of Faith; as the Holy Church teaches us: *For us men, and for our salvation, He came down from Heaven \... and was made Man* (Nicene Creed). Yes, indeed, so much has God done in order to be loved by us.

## Evening Meditation

*HAPPINESS OF HAVING BEEN BORN AFTER THE REDEMPTION AND IN THE TRUE CHURCH*

I.

*When the fullness of time had come, God sent his son \... that he might redeem them who were under the law*. (Gal. iv. 4).

How thankful should we not be to Almighty God for having caused us to be born after the great work of man\'s redemption was accomplished! This is what is meant by the *fulness of time*, a time blessed by the fulness of grace, which Jesus Christ obtained for us by coming into the world. Miserable should we have been if, guilty as we are of manifold sins, we had lived on this earth before the coming of Jesus Christ.

Oh, in what miserable state were all men before the coming of the Messias; the true God was hardly known even in Judea, and in every other part of the world idolatry reigned, so that our forefathers worshipped stones, and wood, and devils; they worshipped innumerable false gods, but the true God was neither loved nor known by them. Even now, how many countries are there in which there are scarcely any Catholics, and all the rest of the inhabitants are either infidels or heretics, and all these are certainly in the way to be lost! What obligation do we not owe God for causing us to be born, not only after the coming of Jesus Christ, but also in countries where the true Faith reigns!

I thank Thee, O Lord, for this. Woe to me if, after so many transgressions, it had been my lot to live in the midst of infidels and heretics! I know, O my God, that Thou willest that I should be saved; and I, miserable wretch, have willed so many times to damn myself by losing Thy favour. Have pity, my Blessed Redeemer, on my soul, which has cost Thee so much.

II\.

*God sent his son that he might redeem them that were under the law* (Gal. iv. 4). The slave therefore sins, and by sinning gives himself over to the power of the devil, and his own Lord comes and ransoms him by His death.

O immense love, O infinite love of God towards man! O My Saviour, if Thou hadst not redeemed me by Thy death, what would have become of me? Of me, who so many times have deserved hell by my sins. Oh, if Thou, my Jesus, hadst not died for me, I should have lost Thee forever, and there would have been no hope for me of recovering Thy grace, or of seeing Thy beautiful face in Paradise. My dearest Saviour, I thank Thee; and I hope to come to Heaven, there to thank Thee for all eternity. I regret above every evil that of having despised Thee in times past. In future, I purpose to choose every suffering, every kind of death, rather than offend Thee. I beseech Thee, my Jesus, let me never do so again. Never let me be separated from Thee, never let me be separated from Thee. I love Thee, O infinite Goodness, and I will always love Thee in this life, and for all eternity. O my Queen and advocate Mary, keep me always under thy protection, and deliver me from sin.
