# Thursday\--Eighth Week after Pentecost

## Morning Meditation

*OUR INGRATITUDE TOWARDS JESUS CHRIST*

O ye sons of men, why do you not love Jesus Christ? Tell me, what more could He have done to make you love Him? If the vilest of mankind had suffered for us the torments Jesus Christ suffered, could we help giving him all our affection and showing him our gratitude?

I.

O my Jesus, what greater proof of Thy love couldst Thou have given me, than the sacrificing of Thy life upon the disgraceful gibbet of the Cross, to make satisfaction for my sins, and to conduct me with Thee into Paradise?

*He humbled himself, becoming obedient unto death, even to the death of the cross* (Phil. ii. 8). The Son of God, therefore, for the love of man, obedient to His Eternal Father, Whose will it was that He should die for our salvation, humbled Himself to die, and to die on a Cross! And are there men to be found who believe this and love not such a God!

O Jesus, how much has it cost Thee to make me understand Thy burning love for me; and I have basely repaid Thee with ingratitude. Oh, accept me now and suffer me to love Thee, since I will no more abuse Thy love. I love Thee, my Sovereign Good, and desire to love Thee forever. Remind me continually of the pains Thou didst suffer for me, that I may never forget the love I owe Thee.

O God, the Passion of Jesus Christ is spoken of, and is listened to as though it were a fable, or story about the sufferings and death of someone unknown to us, or something that did not concern us at all!

O ye sons of men, why do ye not love Jesus Christ? Tell me, what more could our Blessed Redeemer have done to make us love Him than to die in the midst of humiliations and torments?

If the vilest of mankind had suffered for us the torments Jesus Christ suffered, could we help giving him our affection and showing him our gratitude?

But, my Jesus, why do I speak of the ingratitude of others and not rather of my own? What has hitherto been my conduct towards Thee? Alas, I have repaid Thy love only with offences against Thee!

Pardon me, O Jesus! From this day, I desire to love Thee, and to love Thee much. I should be too ungrateful, if, after so many favours and mercies, I loved Thee but little.

II\.

Let us reflect that this Man of Sorrows, nailed to the disgraceful wood of the Cross, is our true God, and suffers and dies there for no other motive but for love of us.

Do we, then, believe that Jesus Christ crucified is our God, and really dies for us, and can we love aught but Jesus crucified?

O beautiful flames of love which consumed the life of my Saviour on Calvary, come and consume in me all worldly affections! Cause me ever to burn with love for such a God, Who was pleased to die and to sacrifice Himself entirely for the love of me.

What a spectacle for the Angels of Heaven to behold the Divine Word fastened to a gibbet, and dying for the salvation of us, His miserable creatures!

O my Saviour, Thou hast not refused me Thy Blood and Thy life, and shall I refuse Thee the affection of my heart? Shall I refuse Thee anything Thou askest of me? No, my Jesus! Thou hast given Thy whole Self to me, and I will give my whole self without reserve to Thee.

## Spiritual Reading

*PRAYER*

GOD GIVES TO ALL MEN THE GRACE TO PRAY.

We have proved that God wishes all men to be saved, and that, as far as He is concerned, He gives to all the graces necessary for their salvation. We say, moreover, that all men have given to them the grace to enable them actually to pray without needing a further grace, and by Prayer to obtain all further aid necessary for the observance of the Commandments and for salvation. But it must be remarked that when we say, \"without needing a further grace,\" we do not mean that the common grace gives the power of Prayer without the aid of *assisting grace*, since, in order to exercise any act of piety, besides the *exciting grace*, there is undoubtedly required the *assisting* or *co-operating grace*. But we mean that the common grace gives every man the power of actual Prayer, *without a further preventing grace* to determine, physically or morally, the will of man to exercise the act of Prayer. We will therefore:

First mention the famous Theologians who teach this doctrine as certain;

Secondly, examine the proofs of this doctrine

\(a\) from Scripture,

\(b\) the Council of Trent,

\(c\) and the Fathers;

Thirdly, examine the theological arguments which prove it.

I.-THE FAMOUS THEOLOGIANS WHO TEACH THIS DOCTRINE.

It is held by Isambert, Cardinal du Perron, Alphonsus le Moyne, and others whom we shall presently quote, and especially by Honoratus Tourneley, who treats the matter fully. All these authors prove that every man, by means of the ordinary sufficient grace alone, can actually pray without need of further aid, and by Prayer can obtain all the graces requisite for the performance of the most difficult things.

It was also held by Cardinal Noris, who proves the proposition that man, when the Commandment urges, can pray if he will; and he proves it in this way: Assuming that, in order to keep the Commandments and to be saved, Prayer is necessary, as we proved in the beginning when we spoke of the Necessity of Prayer, this learned author says that every one has the proximate power of Prayer, in order that by Prayer he may obtain the proximate power to do good; and therefore all can pray with only the ordinary grace, without other assistance. Otherwise, he argues, if, in order to obtain the proximate power for the act of Prayer we require another power, we should still want another power of grace to obtain this power, and so on *ad infinitum*, and it would no longer be in the power of man to co-operate in his salvation.

The same author held it as certain that in the present state all men have the assistance *sine qua non*, i.e., ordinary grace, which, without need of further assistance, produces Prayer, by which we can then obtain efficacious grace to enable us to observe the Law. And hence we can easily understand the axiom universally received in the Schools: \"*Facienti quod in se est, Deus non denegat gratiam.\" To him who does what in him lies, God does not refuse His grace*. That is, to the man who prays, and thus makes good use of the sufficient grace which enables him to do such *an easy thing as to pray*, God does not refuse the efficacious grace to enable him to execute *difficult things*.

Thus also, Louis Thomassin, who says that \"sufficient grace,\" to be really *sufficient*, ought to give a man the proximate and ready power to execute a good act. But if, in order to perform such an act, another grace\--namely, efficacious grace\--is needed, and a man has not, at least, mediately, this efficacious grace which is necessary for salvation, how can it be said that the \"sufficient grace\" gives him this proximate and ready power? But Saint Thomas says: \"God does not neglect to do that which is necessary to salvation.\" It is true, of course, that God is not bound to give us His grace, because what is gratis is not of obligation; but, on the other hand, supposing that He gives us Commandments, He is obliged to give us the assistance necessary for observing them. And as God does oblige us actually to observe every precept whenever it applies, so ought He also actually to supply us (at least mediately or remotely) with the assistance necessary for the observance of the precept, without the necessity of a further grace which is not common to all. Hence Thomassin concludes that in order to reconcile the proposition that *sufficient grace* is enough for a man\'s salvation with the statement that *efficacious grace* is requisite to observe the whole Law, it is necessary to say that *sufficient grace is enough to pray*, and to perform similar *easy acts*, and that by means of these we then *obtain efficacious grace to fulfil the difficult acts*. And this is without doubt in conformity with the doctrine of St. Augustine, who teaches: \"By the very fact that it is most firmly believed that the just and good God does not command impossibilities, we are admonished both what to do in easy things, and in difficult things what to ask for.\" On this passage Cardinal Noris observes: \"Therefore, we are able to do easy or less perfect works without asking God for further help; for which, however, we must pray in more difficult works.\" Thomassin also brings forward the authority of St. Bonaventure, Scotus, and others on this subject, and says that all these considered sufficient graces to be truly sufficient, whether the will consents to them or not. And this he demonstrates in four parts of his book, adducing the authorities of the Schoolmen for a long series of years beginning from the year 1100.

Habert, Bishop of Vabres and Doctor of the Sorbonne, who was the first to write against Jansenius, says: \"We think, first, that sufficient grace has only a contingent or mediate connection with the actual effect of the complete consent\... We think, further, that \'sufficient grace\' is a grace that disposes for efficacious grace, since from a good use of it God afterwards grants to the created will the grace that performs the complete effect.\" He had said before that \"all Catholic Doctors have professed, and do profess, that a real inward grace is given, which is capable of persuading the will to consent to good, though, on account of the free resistance of the will, it sometimes does not persuade it thus to consent\"; and for this doctrine he quotes Gamaches, Duval, Isambert, Perez, Le Moyne, and others. Then he proceeds: \"The assistance, therefore, of sufficient grace disposes us for the reception of efficacious grace, and is in some sort efficacious, namely, of an incomplete effect, obtained first remotely, then more nearly, and at last proximately \--such as is an Act of Faith, Hope, Love \... and amongst all these, of Prayer. Hence the famous Alphonsus Le Moyne taught that this sufficient grace was the grace of asking or of Prayer, of which St. Augustine so often speaks.\" So that, according to Habert, the difference between efficacious and sufficient grace is that the former produces its effect completely while the latter produces it either contingently (that is, *sometimes*, but *not always*), or mediately (that is, by means of Prayer). Moreover, he says that sufficient grace, according to the good use we make of it, prepares us to obtain efficacious grace; hence he calls sufficient grace \" in some sort efficacious\" (*secundum quid*), because of its effect commenced but not completed. Lastly, he says that sufficient grace is the grace of Prayer, of which it is in our power to avail ourselves, as St. Augustine teaches. So that a man has no excuse if he does not do that which he already has sufficient grace to enable him to perform, seeing that without further assistance he has the sufficient grace either to act, or at least obtain more help to enable him to act. And Habert asserts that this was the common doctrine of the Sorbonne.

Charles du Plessis d\'Argentre, another Theologian of the Sorbonne, quotes more than a thousand Theologians who teach expressly that with sufficient grace easy works are accomplished, and that a man who makes use of it obtains thereby more abundant assistance for his thorough conversion. And precisely in this sense, as we have already explained, he says the celebrated axiom of the Schools is to be understood: \"To those who do what is in their power\" (by means of sufficient grace) \"God does not deny grace\"; that is, more abundant and efficacious grace.

The learned Dionysius Petavius proves at great length that man works with simple sufficient grace; and he even says that it would be monstrous to assert the contrary, and that this is the doctrine not only of Theologians, but also of the Church. Hence, he says, the grace of observing the precepts follows Prayer; and that the gift of Prayer is given by God at the time when He imposes the precept. So that as the Law is imposed upon all, the gift of Prayer is given to all.

The author of the *Theology for the Use of the Seminary of Peterkau* says that with sufficient grace alone a \" man can act well, and sometimes does act well\"; so that \"there is nothing to hinder that, of two persons furnished with equal graces, one should perform the easier acts (which very often precede full conversion), the other should not.\" And this, he says, is in conformity with the doctrine of St. Augustine, and also of St. Thomas and his first disciples, notably Father Bartholomew Medina, who says that sometimes a man is converted with sufficient grace alone. And I find that also Father Louis of Granada asserts this to be the common doctrine of Theologians: \"Theologians reckon two kinds of assistance\--one *sufficient*, the other more *than sufficient*; by the former men are sometimes converted and sometimes refuse to be converted.\" And he adds: \"And Theologians define how universally this assistance is open to men.\" \"Thus,\" says the *Theology of Peterkau*, a man can perform some acts of piety, such as pray to God humbly, with the aid of sufficient grace alone, and sometimes actually does perform them, and so prepares himself for further graces.\" This, it adds, is the order of God\'s Providence with regard to graces, \"that the succeeding should follow the good use of the former.\" And it concludes that thorough conversion and final perseverance \"are infallibly obtained by Prayer, for which the sufficient grace which is given to every one abundantly suffices\...\"

Richard of St. Victor similarly teaches that there is a sufficient grace to which a man sometimes consents and which he sometimes resists.

Dominic Soto asks: \"Why of two persons whom God is most ready and desirous to convert, one is drawn by grace, and the other is not?\" And he answers: \"No other reason can be given, except that one consents and co-operates, while the other does not co-operate.\" \...

Cardinal Gotti in one place of his *Theology* apparently agrees with us; for when discussing how it is that a man can persevere if he will, when it is not in his power to have the special assistance which is requisite for perseverance, he says that although this special assistance is not in a man\'s power, \"yet it is said to be in a certain sense in a man\'s power, because he can by the grace of God ask for it and obtain it; and in this way it may be said to be in a man\'s power to have the assistance necessary for perseverance because it can be obtained by prayer.\" But to verify the proposition that it is in a man\'s power to persevere, it is necessary to grant both that he can, without needing any further grace, obtain by Prayer the assistance requisite for perseverance; also, that with only the sufficient grace common to all, without need of any special grace he can actually pray, and by Prayer obtain perseverance; otherwise it could not be said that every man had the grace necessary for perseverance, at least remotely or mediately, by means of Prayer.

But if Cardinal Gotti did not so understand it, at any rate this is what St. Francis de Sales teaches when he says that the grace of actual Prayer is given to everyone who will avail himself of it, and thence concludes that perseverance is in the power of everybody. The Saint says this clearly in his *Treatise on the Love of God*, where, after proving that constant Prayer is necessary to obtain from God the gift of final perseverance, he adds, that as the gift of Prayer is freely granted to all those who will consent to the heavenly inspirations, it is consequently in our power to persevere.

Cardinal Bellarmine teaches the same thing. He says: \"Assistance, then and there sufficient for salvation, is given mediately or immediately to all men \... We say mediately or immediately, because to those who have the use of reason we believe that holy inspirations are given by God, and that by these they have immediately the exciting grace, by which, if they will acquiesce in it, they can be disposed to be justified, and at last to obtain salvation.\"

## Evening Meditation

*\"Charity endureth all things\"*

HE THAT LOVES JESUS CHRIST WITH A STRONG LOVE DOES NOT CEASE TO LOVE HIM IN THE MIDST OF TEMPTATIONS AND DESOLATIONS

I.

St. Francis de Sales says: \"It is a mistake to estimate devotion by the consolations which we feel. True devotion in the way of God consists in having a determined will to execute all that is pleasing to God.\" Almighty God is wont to make use of aridities in order to draw closer to Him His most cherished souls. Attachment to our own inordinate inclinations is the greatest obstacle to true union with God. When, therefore, God intends to draw a soul to His perfect love, He endeavours to detach her from all affection to created goods. Thus His first care is to deprive her of temporal goods, of worldly pleasures, of property, honours, friends, relations, and bodily health; by the like means, that is, of losses, troubles, neglect, bereavements, and infirmities, He extirpates by degrees all earthly attachment, in order that the affections may be set on Him alone.

II\.

With a view to produce a longing for spiritual things God regales the soul at first with great consolations, with an abundance of tears and tenderness. She is thus easily weaned from the gratifications of sense, and seeks further to mortify herself with works of penance, fasts, cilices, and disciplines. At this stage the director must keep a check on her, and not allow her to practise mortifications\--at least not all those for which she asks permission \--because, under the spur of this sensible devotion, a soul might easily ruin her health by indiscretion. It is a subtle artifice of the devil, when he beholds a person giving himself up to God, and receiving the consolations and caresses which God generally gives to beginners, to do his utmost to plunge him into the performance of such immoderate penances as utterly to destroy his health; so that afterwards, because of bodily weakness, he not only gives up the mortifications, but prayer, Communion, and all exercises of devotion, and eventually sinks back into his old way of living. On this account, the director should be very sparing in allowing mortifications to those who are only just entering upon the spiritual life, and who desire to practise bodily mortifications. Let him exhort them to practise rather interior mortification by bearing patiently with affronts and contradictions, by obedience to superiors, by bridling the curiosity to see, to hear, and the like; and let him tell them that, when they have acquired the good habit of practising these interior mortifications, they will then be sufficiently perfect to proceed to the external. It would be, of course, a serious error to say, as some say, that external mortifications are of little or no use. Without doubt, interior mortification is most requisite for perfection; but it does not follow from this that external mortifications are unnecessary. St. Vincent de Paul declared that the person who did not practise external mortifications would be mortified neither interiorly nor exteriorly. And St. John of the Cross declared that the director who despised external mortifications was unworthy of confidence, even though he should work miracles.
