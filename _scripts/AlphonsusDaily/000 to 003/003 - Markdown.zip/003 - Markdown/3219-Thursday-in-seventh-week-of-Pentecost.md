# Thursday\--Seventh Week after Pentecost

## Morning Meditation

*THE PARTICULAR JUDGMENT*

Picture to yourself the state to which you will be reduced when death comes, and you are in your last agony, and scarcely another hour of life remains. You are about to appear before your Judge, Jesus Christ, to give an account of your whole life. Nothing in that hour will alarm you so much as a bad conscience. Put your accounts in order, therefore, before the coming of that great accounting day.

I.

Picture to yourself the state to which you will be reduced when death comes, and you are in your last agony, and scarcely another hour of life remains. You are about to appear before your Judge, Jesus Christ, to give an account of your whole life. Nothing in that hour will alarm you so much as a bad conscience. Put your accounts in order, therefore, before the coming of that great accounting day.

When you are on the point of entering into Eternity, remorse for past sins, diffidence, increased by the suggestions of the devil, and uncertainty as to your future lot \--oh, how all this will cast the soul into a tempest of confusion and fear! Let us therefore now unite ourselves to Jesus Christ, and to Mary, that at that decisive moment they may not abandon us.

How terrified shall we be at the thought that in a few moments we shall be judged by Jesus Christ! St. Mary Magdalen de Pazzi, being ill, was asked by her director why she trembled, and she answered: \"How terrible is the thought of having to appear before Christ as our Judge!\"

O Jesus, remember that I am one of those whom Thou hast redeemed with Thy Blood. *We beseech thee, therefore, help Thy servants, whom Thou hast redeemed with Thy precious blood!*

It is the common opinion among divines that in the same place and at the very moment in which the soul departs it is judged by Jesus Christ. So that at one and the same moment the trial is gone through and the sentence passed and put into execution.

O fatal moment, in which the lot of each one is decided for a happy or a miserable Eternity!

The Venerable Father da Ponte, when he considered the Judgment, trembled to such a degree as to shake the room in which he was.

O Jesus, if Thou wert to judge me now, what would become of me? Eternal Father, *look upon the face of thy Christ* (Ps. lxxxiii. 10). I sincerely repent of all the sins I have committed against Thee; look on the Blood, the Wounds of Thy Son, and have pity on me.

II\.

The soul goes forth and leaves the body, but sometimes it is still doubtful whether the person is alive or dead. The soul enters Eternity. The priest sprinkles the corpse with holy water and repeats the prayer of the Church: \"Come to his assistance, all ye Saints of God meet him, ye Angels of the Lord.\" But if the soul be lost, the Saints and Angels can no longer assist it.

Jesus will come to judge us appearing with the same Wounds that He received for us in His Passion. These Wounds will be a source of great consolation to penitents, who with sorrow shall have bewailed their sins during life, but will be a source of great terror to sinners who shall have died in their sins.

O God, what anguish for a man to behold Jesus for the first time, and as his indignant Judge! It will be more terrible than hell itself.

Man will then behold the majesty of the Judge; he will see how much He suffered for his love; he will see God\'s many mercies towards him, the many and great means He afforded him of working out his salvation; he will see the vanity of all worldly things, and the greatness of those which are eternal; he will see, in a word, all these truths, but\--too late! Then there will be no more time to repair past errors. What is done is done.

My beloved Redeemer, grant that when I first behold Thee, I may find Thee appeased; and for this end give me now light and strength to reform my life. I desire to love Thee always. If hitherto I have despised Thy graces, I now esteem them above all the kingdoms of the world.

## Spiritual Reading

*PRAYER, CONDITIONS OF PRAYER*

IV.-CONFIDENCE; THE FOUNDATION OF ONE\'S CONFIDENCE.

But, some one will say, on what am I, a miserable sinner, to found this certain confidence of obtaining what I ask? On what? On the promise made by Jesus Christ: *Ask, and you shall receive* (Jo. xvi. 24). \"Who will fear to be deceived, when the Truth promises?\" says St. Augustine. How can we doubt that we shall be heard, when God, Who is Truth itself, promises to give us that which we ask of Him in Prayer? \"We should not be exhorted to ask,\" says the same Father, \"unless He meant to give.\" This is the very thing to which He exhorts us so strongly, and which is repeated so often in the Scriptures\--*pray, ask, seek*, and you shall obtain what you desire: *You shall ask whatever you will, and it shall be done unto you* (Jo. xv. 7). And in order that we may pray to Him with due confidence our Saviour has taught us, in the \"Our Father,\" that when we have recourse to Him for the graces necessary for salvation (all of which are included in the Petitions of the Lord\'s Prayer) we should call Him, not *Lord*, but *Father\--Our Father*\--because it is His will that we should ask God for grace with the same confidence with which a son, when in want, or sick, asks food or medicine from his own father. If a son is suffering hunger, he has only to make his case known to his father and his father will forthwith provide him with food; and if he has received a bite from a venomous serpent, he has only to show his father the wound, and the father will immediately apply whatever remedy he has.

Trusting, therefore, in God\'s promises, let us always pray with confidence; not vacillating, but stable and firm, as the Apostle says: *Let us hold fast the confession of our hope without wavering: for he is faithful that hath promised* (Heb. x. 23). As it is perfectly certain that God is faithful to His promises, so ought our confidence also be perfectly certain that He will hear us when we pray. And although sometimes, when we are in a state of aridity, or disturbed by some fault we have committed, we perhaps do not feel while praying that sensible confidence which we would wish to experience, yet, for all this, let us force ourselves to pray, and to pray without ceasing, for God will not refuse us. Nay, rather He will hear us more readily, because we shall then pray with more distrust of ourselves, and confiding only in the goodness and faithfulness of God, Who has promised to hear the man who prays to Him. Oh, how God is pleased in the time of our tribulations, of our fears, and of our temptations to see us *hope against hope*; that is, in spite of the feeling of diffidence which we then experience because of our desolation! This is what the Apostle praised in the Patriarch Abraham, *who against hope believed in hope* (Rom. iv. 18).

St. John says that he who reposes a firm trust in God will certainly become a saint: *And every one that hath this hope in him sanctifieth himself, as he also is holy* (1 Jo. iii. 3). For God gives abundant graces to them that trust in Him. By this confidence it was that so many Martyrs and Virgins, and even children, in spite of the dread of the torments which, their persecutors prepared for them, overcame both their tortures and their persecutors.

Sometimes, I say, we pray, but it seems to us that God will not hear us. Ah! let us not then neglect to persevere in Prayer and to hope; let us then say with Job: *Although he should kill me, I will trust in him* (Job xiii. 15). O my God! though Thou shouldst drive me from Thy presence, I will not cease to pray, and to hope in Thy Mercy. Let us do so, and we shall obtain what we want from God. So did the Canaanitish woman, and she obtained all that she wished from Jesus Christ. This woman had a daughter possessed of a devil, and prayed our Saviour to deliver her: *Have mercy on me, my daughter is grievously tormented by a devil* (Matt. xv. 22). Our Lord answered her that He was not sent for the Gentiles, of whom she was one, but for the Jews. She, however, did not lose heart, but renewed her prayer with confidence: Lord, Thou canst console me Thou must console me. *Lord help me!* (Matt. xv. 25). Jesus answered: *It is not good to take the children\'s bread and to cast it to the dogs.* (Matt. xv. 26). But she replied: *Yea, Lord; for even the whelps eat of the crumbs that fall from the table of their masters* (Matt. xv. 27). Then our Saviour, seeing the great confidence of this woman, praised her, and did what she asked, saying: *O woman, great is thy faith; be it done to thee as thou wilt* (Matt. xv. 28). For who, says Ecclesiasticus has ever called on God for aid, and has been neglected and left unaided by Him? *Or who hath called upon him and he hath despised him?* (Ecclus. ii. 12).

St. Augustine says that Prayer is *a key which opens heaven to us*; the same moment in which our Prayer ascends to God, the grace which we ask for descends to us: \"The Prayer of the just *is the key of heaven; the* petition ascends, and the mercy of God descends.\" The royal Prophet says that our supplications and God\'s Mercy are united together: *Blessed be God, who has not turned away my prayer, nor his mercy from me* (Ps. lxv. 20. And hence the same St. Augustine says that when we are praying to God we ought to be certain that God is listening to us \"When you see that your prayer is not removed from you, be sure that His Mercy is not removed from you.\" And for myself, I speak the truth, I never feel greater consolation nor a greater confidence of my salvation than when I am praying to God, and recommending myself to Him. And I think that the same thing happens to all other believers. All the other signs of our salvation are uncertain and unstable, but that God hears the man who prays to Him with confidence is an infallible truth, as it is infallible that God cannot fail in His promises.

When we find ourselves weak and unable to overcome any passion, or any great difficulty in fulfilling that which God requires of us, let us take courage and say, with the Apostle: *I can do all things in him that strengtheneth me* (Philip. iv. 13). Let us not say, as some do: *I cannot; I distrust myself*. With *our own strength* certainly we *can do nothing*; but with *God\'s help we can do everything*. If God said to some one: Take this mountain on your shoulders and carry it, for I am helping you, would not the man be a fool or impious if he answered: I will not take it, for I have not strength to carry it? And thus, when we know how miserable and weak we are and when we find ourselves most encompassed with temptations, let us not lose heart, but let us lift up our eyes to God, and say, with David: *The Lord is my helper; and I will despise my enemies.* (Ps. cxvii. 7). With the help of my Lord, I shall overcome and laugh to scorn all the assaults of my foes. And when we find ourselves in danger of offending God, or in any other critical position, and are too confused to know what is best to be done, let us recommend ourselves to God, saying: *The Lord is my light and my salvation; whom shall I fear?* (Ps. xxvi. 1). And let us be sure that God will then certainly give us light, and will save us from every evil.

## Evening Meditation

*THE PRACTICE OF THE LOVE OF JESUS CHRIST*

*\"Charity hopeth all things\"*

HE THAT LOVES JESUS CHRIST HOPES FOR ALL THINGS FROM HIM

I.

Yes, O my God, I live in peace in this valley of tears, because such is Thy will; but I cannot help feeling unspeakable bitterness at finding myself at a distance from Thee, and not yet perfectly united with Thee, Who art my centre, my All, and the fulness of my repose! For this reason the Saints, though they were all inflamed with the love of God, did nothing but sigh after Paradise. David cried out: *Woe is me, that my sojourning is prolonged!* (Ps. cxiv. 5). *I shall be satisfied when thy glory shall appear* (Ps. xvi. 15). St. Paul said of himself: *Having a desire to be with Christ* (Phil. i. 23). St. Francis of Assisi said:

\"I look for such a meed of bliss That all my pain seems happiness.\"

These were all so many acts of perfect Charity. The angelic Doctor teaches us that the highest degree of Charity which a soul can reach upon this earth is to desire intensely to go and be united with God, and to enjoy Him in Heaven. But, as we have already seen, this enjoyment of God in Heaven does not consist so much in the fruition of the delights there lavished on her by Almighty God, as in the pleasure she takes in the happiness of God Himself Whom she loves incomparably more than herself.

O God, my Creator and my Redeemer, Thou hast created me for Heaven; Thou hast redeemed me from hell to bring me into Heaven; and I have so many times, in Thy very face, renounced my claim to Heaven by my sins, and have remained contented in seeing myself doomed to hell! But blessed for ever be Thy infinite mercy, which, I hope, has pardoned me, and many a time rescued me from perdition. Ah, my Jesus, would that I had never offended Thee! Would that I had always loved Thee! I rejoice that at least I have still time to do so. I love Thee! O Love of my soul, I love Thee with my whole heart; I love Thee more than myself! I see plainly that Thou wishest to save me, that I may be able to love Thee for all eternity in that kingdom of love. I thank Thee, and beseech Thee to help me for the remainder of my life, in which I wish to love Thee most ardently, that I may ardently love Thee in eternity.

II\.

The Holy Souls in Purgatory feel no pain more acutely than that of their yearning to possess God, from Whom they remain still at a distance. And this sort of pain will afflict those especially who in their lifetime had but little desire of Paradise. Blessed Cardinal Bellarmine also says that there is a certain place in Purgatory called *career honoratus*, or *prison of honour*, where certain souls are not tormented with any pains of sense, but merely with the pain of privation of the sight of God. Examples of this are related by St. Gregory, Venerable Bede, St. Vincent Ferrar, and St. Bridget; and this punishment is not for the commission of sin, but for coldness in desiring Heaven. Many souls aspire to perfection, but for the rest, they are very indifferent whether they go to enjoy the sight of God or continue on earth. But eternal life is an inestimable good that has been purchased by the death of Jesus Christ; and God punishes such souls as have been remiss during life in their desires to obtain it.

Ah, my Jesus, when will the day arrive that shall free me from all danger of losing Thee, and consume me with love, by unveiling before my eyes Thy infinite beauty, so that I shall be under the necessity of loving Thee? Oh, sweet necessity! Oh, happy and dear and most desired necessity, which shall relieve me from all fear of evermore displeasing Thee, and shall oblige me to love Thee with all my strength! My conscience alarms me, and says: \"How canst thou presume to enter Heaven?\" But, my dearest Redeemer, Thy merits are all my hope. O Mary, Queen of Heaven, thy intercession is all-powerful with God; in thee I put my trust!
