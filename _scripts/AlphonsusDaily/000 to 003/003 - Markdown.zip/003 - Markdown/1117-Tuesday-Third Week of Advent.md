# Tuesday\--Third Week of Advent

## Morning Meditation

*CONSIDERATIONS ON THE RELIGIOUS STATE. VII.*

*Consider the harm done to Religious by tepidity.*

Negligent souls are commonly abandoned by God. St. Teresa saw the place prepared for her in hell had she not detached herself from a certain worldly affection which, however, was but slightly culpable. *He that contemneth small things shall fall by little and little* (Ecclus. xix. 1).

I.

Consider the misery of the Religious who, after having left his home, his parents, and the world with all its pleasures, and after having given himself to Jesus Christ, consecrating to Him his will and his liberty, exposes himself to the danger of being damned by leading a lukewarm and negligent life. Alas! such a Religious is not far from perdition, who, called into the House of God to become a Saint, leads a lukewarm life. God threatens to reject and abandon such Religious if they do not amend: *But because thou art lukewarm I will begin to vomit thee out of my mouth* (Apoc. iii. 16).

St. Ignatius of Loyola, seeing that a Lay-brother of the Society had become lukewarm in the service of God, called him one day and said to him: \"Tell me, my brother, why did you come into Religion?\" He answered \"To serve God.\" \"O my brother!\" replied the Saint, \"what have you said? If you had answered that you had come to serve a Cardinal, or a prince of this earth, you would be more excusable; but you say that you came to serve God, and is it thus you serve Him?\" Father Nieremberg says that some are called by God to be saved as Saints, and that if they do not take care to live as Saints, but thinking to be saved as imperfect Christians, they will not be saved at all. And St. Augustine says that such are, in most cases, abandoned by God: \"God is accustomed to abandon negligent souls.\" And how does He abandon them? By permitting them from lighter faults, which they see and do not amend, to fall into grievous ones, lose divine grace and their Vocation. St. Teresa of Jesus saw the place prepared for her in hell, had she not detached herself from an earthly, though not a grievously sinful affection. *He that contemneth small things shall fall by little and little.*

Many wish to follow Jesus Christ as St. Peter did, who, when his Master was arrested in the garden, says St. Matthew, *followed him afar off* (Matt. xxvi. 58). But by doing so that will easily happen to them which happened to St. Peter, namely, when the occasion came, he denied Jesus Christ. A lukewarm Religious will be contented with the little he does for God; but God, Who called him to a perfect life, will not be contented, and, in punishment for his ingratitude, will not only deprive him of special favours, but will sometimes permit his fall. \"When you say: \'It is enough,\' you are lost,\" says Augustine. The fig-tree of the Gospel was cast into the fire, only because it brought forth no fruit.

O my God! reject me not, as I deserve, for I will amend my life. I know full well that a life negligent as mine cannot satisfy Thee. I know that I have, by my lukewarmness, shut the door of my heart against the graces which Thou didst desire to bestow upon me. O Lord! do not abandon me yet awhile; I will rise from my miserable state. I will for the future be more careful to overcome my passions, to follow Thy inspirations, and I will never through slothfulness omit my duties; I will perform them with greater diligence. In short, I will, from this time forward, do all I can to please Thee, and I will neglect nothing which I know to be pleasing to Thee.

II\.

Father Louis de Ponte said: \"I have committed many faults, but I have never made peace with them.\" Miserable is the Religious who, being called to perfection, makes peace with his defects. As long as we detest our imperfections, there is hope that we may become Saints; but when we commit faults and make little of them, then, says St. Bernard, the hope of becoming Saints is lost. *He who soweth sparingly shall also reap sparingly* (2 Cor. ix. 6). Ordinary graces do not suffice to make one a Saint; extraordinary ones are necessary. But how shall God be liberal with His favours to one who acts sparingly and with reserve in his Love for Him?

Moreover, to become a Saint, one must have courage and strength to overcome all repugnances; and let no one ever believe, says St. Bernard, that he will be able to attain to perfection unless he distinguishes himself in the practice of virtue: \"What is *perfect*, cannot but be *singular*.\" Reflect, my brother, for what have you left the world and all it can give? It was to become a Saint. But that lukewarm and imperfect life which you lead, is that the way of becoming a Saint? St. Teresa animated her daughters by saying to them: \"My sisters, you have done the principal thing necessary to become Saints; the lesser remains yet to be done.\" The same I say to you; you have, perhaps, done the chief part already; you have left your country, your parents, and home, your property and your amusements, the lesser part now remains to be done to become a Saint. Do it.

Since Thou, O my Jesus! hast been so liberal with Thy graces towards me, and hast deigned to give Thy Blood and Thy life for me, why should I act with such reserve towards Thee? Thou art worthy of all honour and love, and to please Thee one ought gladly to undergo every labour, and suffer every pain. But, O my Redeemer, Thou knowest my weakness, help me by Thy powerful grace; in Thee I confide. O immaculate Virgin Mary, thou who hast helped me to leave the world, help me to overcome myself and to become a Saint.

## Spiritual Reading

*COUNSELS CONCERNING A RELIGIOUS VOCATION*

VIII\. DETACHMENT (*continued*)

*III. From Self-Esteem*

He who enters Religion *must be entirely detached from all self-esteem*. There are many who leave their home, their comforts, their relations, but arrive bringing with them a certain esteem for themselves: such attachment would be the worst of all. Here is the greatest sacrifice we have to offer to God, namely the giving up, not only of our goods, our pleasures, our home, but of our own selves to Him. This is that denial of self which Jesus recommended more than anything else to His followers. And in order to deny himself, a man must tread under foot all self-esteem, by desiring and embracing every imaginable contempt that he may meet with in Religion; as, for instance, seeing others, whom perhaps he thinks less deserving, preferred to himself, or himself considered unfit to be employed, or only employed in lower or more laborious occupations. It must be understood that in the House of God those charges are the highest and the most honourable that are imposed by obedience. God forbid that any one should seek for or aspire to any office or charge of pre-eminence. This would be a strange thing in Religion, and would mark a Religious as proud and ambitious, and as such he should receive a penance, and be mortified especially on this very point. Better would it be, perhaps, that a Religious Order were destroyed than there should enter in that accursed pest of ambition which, when it enters, disfigures the most perfect Communities, and the most beautiful works of God.

On the contrary, he ought to feel interiorly consoled who sees himself made fun of and despised by his companions. I say interiorly consoled, for as to *nature*, this is not possible, nor need the Religious be uneasy at the resentment of his feelings, for it is enough that the spirit embraces such things, and that he rejoices in the superior part of the soul. Thus also when he sees himself continually reprimanded and mortified, not only by Superiors, but also by equals and inferiors, he ought heartily, and with a tranquil mind, to thank those who thus reprimand him, and have the charity to admonish him, answering that he will be more careful not to fall into that fault again.

One of the most ardent desires of the Saints in this world was to be despised for the love of Jesus Christ. It was this St. John of the Cross asked for, when Jesus Christ appeared to him with a Cross on His shoulder, and said: \"John, ask from Me what thou wishest,\" and St. John answered: \"O Lord, to suffer and to be despised for Thee.\" The Doctors of the Church teach, with St. Francis de Sales, that the highest degree of humility is to be pleased with objections and humiliations. And in this consists also our greatest merit before God. Some insult suffered in peace for the love of God is of greater value in His sight than a thousand disciplines and a thousand fasts.

We must know that occasions to suffer some slight, either from Superiors or from companions, are to be found even in the most holy Communities. Read the Lives of the Saints, and you will see how many mortifications fell to the lot of a St. Francis Regis, St. Francis of Jerome, Father Torres, and others. The Lord sometimes permits that even among Saints there should exist, without any fault of theirs, certain natural antipathies, or at least, a certain diversity of character among subjects of the greatest piety, which will cause them to suffer many contradictions. At other times things will be believed that are not true. God Himself will permit this in order that the subjects may have occasion to exercise themselves in patience and humility.

In short, he will gain little in Religion and lose much who cannot quietly put up with contempt and contradictions; and, therefore, he who enters Religion to give himself entirely to God should feel ashamed not to know how to bear contempt when he appears before Jesus Christ, Who *was filled with opprobrium* for love of us. Let each one be attentive to this, and resolve to take pleasure in abjections, and to prepare himself to suffer many in Religion, for without the least doubt he will have many to bear. Otherwise, the disquiet caused by contradictions and contempt badly endured would trouble him to such a degree as to bring him to lose his Vocation, and make him abandon the Religious life. Oh, how many have lost their Vocation on account of impatience in humiliations! But of what service to an Institute, or to God, can be he who does not know how to bear contempt for God\'s love? And how can one ever be said to be dead to himself, according to that promise which he made to Jesus Christ on entering Religion, if he remains still alive to resentment and disquiet, when he sees himself humbled? Away then with such subjects so full of self-esteem! Yes, far away! It is well that they go as soon as possible, lest they infect the rest with their pride. In Religion each one ought to be, as it were, dead, and especially to self-esteem, otherwise it were better for him not to enter, or to depart if he has already entered.

## Evening Meditation

*JESUS THE CHARITABLE PHYSICIAN OF OUR SOULS*

I.

*But unto you the sun of justice shall rise, and health in his wings* (Mal. iv. 2).

Your Physician shall come, says the Prophet, to cure the infirm; and He will come swiftly like the bird that flies, and like the sun, which, on rising above the horizon, instantly sends its light to the other pole. But behold Him, He is already come. Let us console ourselves, and return thanks to Him.

St. Augustine says: \"He descends even to the bed of the sick\"; that is to say, even to taking our flesh, for our bodies are the beds of our infirm souls.

Physicians, if they love their patients, do indeed make every possible effort to cure them; but what physician, in order to cure the sick man, ever took upon himself his disease? Jesus Christ is truly that Physician, Who took on Himself our infirmities in order to cure them. Neither would He content Himself with sending another in His place, but He chose to come Himself to fulfil this charitable office in order to gain to Himself all our love.

Praised and blessed for ever be Thy Charity, O my Redeemer! And what would become of my soul, so infirm and afflicted with the many wounds of my sins, if I had not Thee, my Jesus, Who art both able and willing to heal me? O Blood of my Saviour, I trust in Thee! Wash me and heal me.

II\.

*He hath borne our infirmities and carried our sorrows* (Is. liii. 4). He was pleased to heal our wounds with His own Blood, and by His death deliver us from eternal death which we had deserved. In short, He chose to take the bitter medicine of a life of continual sufferings and a painful death to obtain life for us, and to deliver us from our many ills.

*The chalice which my Father hath given me, shall I not drink it?* (Jo. xviii. 11), He said to Peter. It was necessary then that Jesus Christ should embrace so many ignominies to heal our pride; that He should embrace such a life of poverty to cure our covetousness; that He should suffer a sea of torments, so as to die of pure agony to cure our eagerness for sensual pleasures.

O my Love, I repent of having offended Thee. Thou hast led a life of such tribulations and hast died such a bitter death to prove to me the love which Thou bearest me! I would fain show Thee also how much I love Thee, but what can I do \-- I am so infirm, so miserable and so weak? O God of my soul Thou art Omnipotent; Thou canst cure me and make me holy. Oh, kindle in me a great desire of pleasing Thee. I renounce all my satisfactions to please Thee my Redeemer, Who dost deserve to be pleased at all cost. O Sovereign Good, I esteem Thee and love Thee above every good; make me love Thee with all my heart, and always implore Thy love. Hitherto I have offended Thee, and have not loved Thee, because I have not sought Thy love. I now beg this love of Thee, and the grace always to ask it of Thee. Hear me, by the merits of Thy Passion.

O Mary, my Mother, thou art always prepared to listen to him that prays to thee. Thou lovest him that loves thee. I love thee, my Queen. Obtain for me the grace to love God, and I ask for nothing more. Amen.
