# Twentieth Sunday after Pentecost

## Morning Meditation

*ST. TERESA\'S DESIRE FOR DEATH*

Death is an object of the greatest terror to souls attached to this world. Those who love God especially desire it. St. Teresa in thinking of the danger she ran as long as life lasted, of offending God and losing Him, used to say that a single day, even a single hour was too long to have to live. \"Alas! Lord, as long as we remain in this miserable life, life eternal is in jeopardy.\"

I.

If the worldly-minded have a fear of losing their goods, fleeting and miserable as they are, much greater is the fear the Saints have of losing God, Who is a Good infinite and eternal, and Who promises to bestow Himself in Heaven as a recompense upon him who has loved Him on earth, admitting him to the enjoyment of His beauty and of His own happiness. Hence as their whole fear during life has been simply the fear of sinning, and thus losing the friendship of that Lord Whom they have loved so well, so their whole desire has been to die in the grace of God, and by death to gain the assurance of loving and possessing Him forever.

Death, then \-- that object of the greatest terror to souls attached to this world \-- is what those that love God especially desire: for, says St. Bernard, it is for these happy souls both the termination of their labours and the gate of life. Hence we see that among the Saints, one would call this life a prison and pray the Lord to deliver him out of it: *Deliver my soul from this prison* (Ps. cxli. 8). Another, like St. Paul, would call it a real death: *Who shall deliver me from the body of this death?* (Rom. vii. 24).

But how are we to express the grief and the extreme anguish that our Saint experienced through her desire for death, more especially after the time when the Lord called her to His perfect love? She protests, in her Life, written in obedience to her confessor, that the desire that she had of dying, in order to see God, was so great, that it did not even afford her the leisure to think of her sins. This humble spouse of Jesus crucified spoke in this manner because she was continually bewailing those imperfections in her love of her Spouse into which she had formerly fallen \-- imperfections she pronounced to be monstrous and deserving of hell, but in reality, as her biographers declare, her failings never amounted to a mortal sin.

The Saint, in thinking, moreover, of the danger she was in, as long as life should last, of offending God and losing Him, used to say that a single day, and even a single hour, seemed to her too long to have to live. Hence she would exclaim: \"Alas! Lord, as long as we remain in this miserable life, life eternal is ever in jeopardy. O life! enemy of my welfare, who will be able to bring thee to an end? I endure thee, because God endures thee. I preserve thee, because thou dost appertain to Him; may I never prove treacherous or ungrateful. Oh! when will that day of benediction arrive on which I shall behold thee, O life, swallowed up in the boundless ocean of the sovereign truth, when thou wilt no longer possess the liberty to sin?\"

O beautiful fatherland! O blessed fatherland of God-loving souls! where they love Him without fear of losing Him; without tepidity, and for ever! I greet thee from afar, from this valley of tears, and I sigh for thee, because I hope that in thee I shall love my God with all my powers for evermore.

II\.

To our Saint\'s fear of the possibility of offending God in this life was joined the great desire that this loving soul entertained of seeing face to face the only object of her love, that she might thus gain the power of loving Him more perfectly, and of altogether uniting herself to Him. For this reason she could not endure to see herself at such a distance from the country of the Blessed; with abundance of tears, she would thus utter her complaint before her Spouse: \"Alas! alas! Lord, this banishment is long indeed! What shall a soul confined in this prison do? Oh! Jesus, the life of man is long indeed! It is short, when considered as a means of gaining the life that is the true one; but it is long for that soul that desires to behold herself in the presence of her God.\" At other times, blending with her loving pains her distrust in her own merits and her hope in God, she would occupy herself in the composition of the following beautiful harmony of ejaculations so pleasing to her Beloved: \"O life!\" she would say, \"O life! how canst thou keep thyself apart from thy Life? O death! O death! I know not who can fear thee, because in thee is life! Yet who shall not fear thee after having spent a part of this life without the love of his God? O my soul! serve thy God, and hope that in His mercy He will heal thy miseries.\"

But in order to understand the extent of the burning desire our Saint had for death, it is necessary that we should have a knowledge of the pain she experienced in continuing in life. She related to her confessor that this was such that it seemed already to destroy and bring her life to an end. Under its influence, too, she would even fall into an ecstasy. To give vent to her affections, she drew up on this subject those burning words of which that celebrated hymn of hers is composed, which thus begins:

\"I live, from myself am far away:\

And hope to reach a life so high,\

That I\'m for ever dying because I do not die!\"

Elsewhere she says: \"When will it be, O my God, that I shall at last see my whole soul perfectly united to Thee, so that all its faculties may have complete fruition of Thee?\"

In a word, the only relief and consolation she found in this life was in thinking of her death. So she used to comfort herself, while on earth, with words like these: \"Then, then, O my soul, you will have entered into your rest, when you shall be holding converse with that sovereign Good and shall know what He knows; when you shall love what He loves, and enjoy all that constitutes His blessedness; for then you will be rid of your own wretched will.\" Thus, it may be said, that the life of our Saint was sustained by the hope of that life eternal, for which she had sacrificed all the goods of this world; \"I had rather live and die,\" she tells us, \"hoping for the life eternal, than have all the goods of the earth in my possession. Do not Thou abandon me, O Lord, for I hope in Thee. If only I may serve Thee without intermission, do with me whatsoever Thou pleasest.\"

O my holy advocate, Teresa, I rejoice with thee that thou hast reached the haven, the termination of thy sighs! Now Thou dost no longer believe, thou beholdest the beauty of God! Thou no longer hopest, thou art possessed of the Sovereign Good! Thou art now rejoicing in the clear vision of that God Whom thou hast so long desired and loved! Thy love is now satiated! There is nothing for thy loving heart to long for more! O my Saint, have compassion on me who am still in the midst of the storm. Pray for me that I may obtain salvation and go to join thee in loving that God Whom thou so greatly desirest to see loved.

## Spiritual Reading

*\"PARADISE! PARADISE!\"*

When the dignity of Cardinal was offered to St. Philip Neri, he cast his biretta into the air, and, looking up to Heaven, replied: \"Paradise! Paradise!\" The Blessed Giles would fall into an ecstasy, when the children, out of frolic, said to him: \"Brother Giles, Paradise! Paradise!\"

It is an opinion among theologians, that in Purgatory there is a peculiar pain called the pain of languor, which is inflicted upon those who had but little desire for Paradise during life on earth, and reasonably so, for we have but little love for God if we desire but little to enjoy His infinite beauty unveiled before our eyes, and the more so as it is impossible for us here in life not to be continually offending Him, at least in venial matters. Even if we do love Him here below, our love is, nevertheless, so imperfect, that we scarcely know that we love Him at all.

Let us, then, yearn for Paradise, where we shall offend God no more, and where we shall ever love Him with all our powers. When the troubles of this life press heavily upon us, let us animate ourselves by the hope of Paradise in order to bear them with tranquillity. When the world or the devil presents for our acceptance fruits that are forbidden, let us with good courage turn our back upon them, and lift up our eyes to Paradise. If the dread of God\'s judgments alarms us, let us nerve ourselves by hoping in the goodness of our God, Who to make us understand how ardently He desires to give Paradise to us, has commanded us, under pain of damnation, to hope for it through His mercy. He even willed to purchase it at the cost of His Blood, and His Death, that so He might obtain that great blessedness for us; and to assure us of it the more, He has been pleased to give us a pledge of it in the gift of Himself to us in the Most Holy Sacrament of the altar.

If our weakness terrifies us, let us fortify our hope by the same goodness of our Lord, Who, after having given us His merits to entitle us to Paradise, will likewise give us the strength to persevere in His grace even to our life\'s end, if we have recourse to His mercy, and pray to Him for that strength and perseverance.

The holy Mother Teresa used to say:

\"Let your desire be to see God; your fear, to lose Him; your joy, whatever can bring you to Him.\"

Burning with the desire of seeing God, the Saint composed her famous \"Canticle,\" \"I die because I cannot die!\" and on this text she wrote many beautiful stanzas, of which the following are two:

Ah, Lord, my Light, and living Breath!\

Take me, Oh, take me from this death,\

And burst the bars that sever me\

From my true Life above:\

Think how I die, Thy face to see,\

And cannot live away from Thee,\

O my eternal Love!\

And ever, ever weep and sigh,\

Dying because I cannot die.

I weary of this endless strife;\

I weary of this dying life\--\

This living death \-- this heavy chain;\

This torment of delay,\

In which her sins my soul detain;\

Ah, when shall it be mine? Ah, when,\

With my last breath to say\--\

\"No more I weep \-- no more I sigh!\

I\'m dying of desire to die.\"\

*HYMN IN HONOUR OF ST. TERESA*

Ye angels most inflamed\

With fires of heavenly love,\

Bright Seraphim, descend\

From your high thrones above;\

To this most chosen soul\

Your loving succor bring \--\

To her, the spouse belov\'d\

Of Christ your God and King.

Jesus, your Love, your Life,\

Who loves the pure of heart,\

Has pierced Teresa\'s soul\

With love\'s own flaming dart;\

And lo! she pines away,\

She languishes, she sighs;\

For Him Who gave the wound,\

Of very love she dies.

\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\...\.....

To see her loving Spouse\

So fierce is her desire\

That evermore she burns,\

Consuming in its fire,\

That sweet and longing wish\

Into His arms to fly,\

Is but a living death,\

Because she cannot die.

No angels come to aid;\

Come Thou, Who in this breast\

Hast kindled flames so dear,\

Come Thou, and give her rest;\

Sick is her soul with love,\

And wounded is her heart;\

Thou didst inflict the wound,\

Then, Jesus, cure its smart.

Thy spouse was ever true,\

To please Thy Heart Divine,\

All earth could give she left,\

All she could give is Thine;\

And now, she loves Thee well,\

And sighs to come to Thee;\

She longs to take her flight,\

Ah! set her spirit free.\

(ST. ALPHONSUS.)

## Evening Meditation

*CONFORMITY TO THE WILL OF GOD*

VI\. GOD WISHES ONLY OUR GOOD.

I.

Oh, how great indeed is the folly of those who resist the Divine Will! They will have to endure sufferings, for no one can ever prevent the accomplishment of the Divine decrees. *Who resisteth his will?* (Rom. ix. 19). And, besides, they will have to bear the burden of their sorrows without deriving benefit from them; nay, they will draw down upon themselves even greater chastisements in the next life, as well as greater disquietude in this: *Who hath resisted him, and hath had peace?* (Job ix. 4). Let the sick man make as great an outcry as he will about his pains; let him who is in poverty murmur and rage and blaspheme against God as much as he pleases \-- what will he gain by it all, but the doubling of his afflictions? \"What are you in search of, O foolish man,\" says St. Augustine, \"when seeking good things? Seek that one Good in Whom are all things that are good.\" What are you going in search of, poor foolish man, outside your God? Find God, unite yourself to His holy will, bind yourself up with it; and you will be ever happy, both in this life and in the next.

In short, what does God will but our good? Whom can we ever find to love us more than He? It is His will, not merely that no one should perish, but that all should save and sanctify their souls: *Not willing that any should perish, but that all should return to penance* (2 Peter iii. 9). *This is the will of God, your sanctification* (1 Thess. iv. 3). It is in our good that God has placed His own glory, being, as St. Leo says, of His own nature, goodness infinite. And as it is of the nature of goodness to desire to spread itself abroad, God has a supreme desire to make the souls of men partakers of His own bliss and glory. And if, in this life, He sends us tribulations, they are all for our own good: *All things work together unto good* (Rom. viii. 28). Even chastisements, as was observed by the holy Judith, do not come to us from God for our destruction, but in order to secure our amendment and salvation: *Let us believe that they have happened for our amendment, and not for our destruction* (Judith, viii. 27).

II\.

In order to save us from evils that are eternal, the Lord throws the shield of His good will around us: *O Lord, thou hast crowned us as with a shield of thy good will* (Ps. v. 13). He not only desires, but is eager for our salvation: *The Lord is careful for me* (Ps. xxxix. 18). \-- For what is there that God will ever refuse us, says St. Paul, after having given us His own Son? *He that spared not even his own Son, but delivered him up for us all, how hath he not also with him given us all things?* (Rom. viii. 32). This, then, is the confidence in which we ought to abandon ourselves to the Divine dispensations, all of which have our good for their object. Let us therefore repeat, whatever circumstances may happen to befall us: *In peace, in the self-same, I will sleep and I will rest; for thou, O Lord, singularly hast settled me in hope* (Ps. iv. 10). Let us also place ourselves entirely in God\'s hands, for He will certainly take care of us: *Casting all your care upon him, for he hath care of you* (1 Peter v. 7). Then, let our thoughts be fixed on God, and on the fulfilment of His will, that He may think of us and of our good. \"Daughter,\" said the Lord to St. Catharine of Sienna, \"do thou think of Me, and I will ever think of thee.\" Let us frequently repeat with the sacred spouse, *My Beloved to me, and I to him* (Cant. ii. 16). The thoughts of my Beloved are for my welfare; I will think of nothing but of pleasing Him, and bringing myself into perfect conformity with His holy will. The holy Abbot Nilus used to say that we ought never to pray to God to make our will succeed, but to accomplish His will in us. And whenever things befall us that are not according to our wishes, let us accept them all, as from God\'s hands, not merely with patience, but with joy, as did the Apostles when they *went from the presence of the council, rejoicing that they were accounted worthy to suffer reproach for the name of Jesus* (Acts, v. 41).
