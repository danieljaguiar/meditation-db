# Tuesday\--Third Week after Epiphany

## Morning Meditation

ST. FRANCIS DE SALES (January 29th)

HIS FAITH, HOPE, AND CHARITY

They who love God never doubt in matters of Faith. It is only those who do not live according to the dictates of their Faith who doubt its Truths. O my God, cries out St. Francis, the beauty of our holy Faith appears to me so delightful that I could die of love for it!

I.

*Great was the Faith of St. Francis de Sales*. Such was his delight when he thought of the beauty and excellence of Faith, that he was heard to exclaim, \"O my God, the beauty of our holy Faith appears to be so delightful that I could die of love for it, and it seems to me that I ought to enclose this precious gift which God has bestowed upon me, in a heart full of the sweetest perfumes of devotion.\" Hence he was never satisfied with giving God thanks for having blessed him with the favour of being born a child of the true Church: \"O bountiful God,\" said he, \"great indeed are the favours by which Thou hast bound me to Thee; but how shall I ever sufficiently thank Thee for having enlightened me with the true Faith?\" And he declared that, although he had constantly had so much to do with heretics, he had never once doubted in the least of the truth of his Faith. They who love God never doubt in matters of Faith: it is only those who do not live according to the dictates of their Faith who doubt of its Truths.

*Great also was the Hope of St. Francis.* He was always firmly convinced that God continually watches over our welfare, and hence he was always calm and intrepid in the midst of the greatest dangers. In the very dangers which threatened his designs for the glory of God, he never lost confidence. And this he always endeavoured to instil into others. On one occasion he is related to have said to a timid soul: \"Do you desire to belong entirely to God? Why, then, do you fear on account of your weakness? Do you hope in God? And shall he who hopes in God be ever confounded? Be not afraid of your fears.\" He who loves God much, confides much in Him. Love always cuts out fear.

II\.

*Great likewise was his love for God.* The very fear which he experienced in the early part of his life, that he might not be worthy to love God for all eternity, ruined his health and nearly deprived him of life. It was his great Charity which inspired him to expose himself on so many occasions to death for God\'s sake. He was so careful to expel from his heart every affection which was not directed towards God, that he said, \"If I knew that there existed in my heart a single fibre of affection that is not from God and for God, I would immediately pluck it out.\" He always aspired to the purest love of God. He said: \"I would rather not exist than not be entirely devoted to God.\" In one of his letters he writes: \"My heart is filled with an unbounded desire of being forever sacrificed to the pure love of my Saviour.\" And he tells us how tender his love was, especially for Jesus Christ, when he says: \"Let us contemplate our Divine Redeemer nailed to the Cross and dying upon it for the love of us. Ah! why do we not cast ourselves upon the same Cross to die on it with Him, for His having been pleased through love for us to die Himself upon it? I will embrace Him and will never leave Him. I will die with Him and will burn in the flames of His love. The same flame shall consume the Divine Creator and His creature. I will live and die upon His bosom. Neither life nor death shall ever separate me from Him.\"

Holy Saint, since thou art now in Heaven loving Jesus face to face, obtain for me the grace to love Him, as thou didst love Him in thy lifetime.

## Spiritual Reading

*THE VARIOUS TORTURES TO WHICH THE MARTYRS WERE SUBJECTED*

The Rev. Father Mamachi, in his erudite work entitled *Manners and Customs of the First Christians*, gives an account of all those tortures suffered by the Martyrs, from the works of ancient writers who were their contemporaries, as St. Justin, Tertullian, Athenagoras, Origen, Eusebius of Caesarea, Clement of Alexandria, and others. This author describes at much length the various species of torture employed against the servants of Jesus Christ during the Ten Persecutions of the Roman Emperors. We shall be more brief, as our intention is merely to show how rich in merit were those sainted heroes when they closed their earthly career.

I. THE MARTYRDOM OF THE CROSS

Some were crucified in an erect posture, the same as Our Lord Jesus Christ; others with the head downwards, as St. Peter, according to Eusebius, who relates this on the authority of Origen; others in the manner in which the Martyrdom of St. Andrew is represented. Many were made to pass their arms under the transverse beam of the Cross, and had their hands nailed upon the upper part. Some were suspended from a tree by the hands, their arms having been first tied behind their backs, and heavy weights attached to their feet. Women were hung up by the hair, the agony of which torture was sufficient to cause death; others were hung by one or both feet, with the head downwards, and in many cases a large stone tied round the neck; finally, many had their hands nailed to a beam, with enormous weights at their feet.

II\. THE MARTYRDOM OF FIRE

Some were placed upon gridirons, others plunged into caldrons of boiling oil or pitch. Many were suffocated with smoke, or dressed in a garment smeared with some combustible matter, and so burned at a stake. Some were cast into fiery furnaces; others were crowded into a ship which was set on fire at sea; others were inclosed in a brazen bull and roasted alive; others again were tortured by red-hot plates of iron applied to their sides; and in fine, were thrown upon the earth, and molten lead poured over them, or were impaled upon a spit and roasted before a slow fire.

III\. THE TORTURE OF THE SCOURGE

Scourges were of various kinds \-- of leather, of cane, of the tendons of oxen, of iron links, and sometimes of rods of iron, shaped like thorns, which were called *scorpions*. The Martyrs were generally tied to a post, or between four posts, to increase their punishment; but some were placed in a kind of stock. This stock consisted of two large pieces of wood, one above the other, between which the feet of the sufferers were confined, and in this torture they were sometimes scourged; and others were thrown with their backs on a table filled with large nails, and then scourged with sticks or rods.

IV\. THE TORTURE OF IRONS

These were iron hooks on which the Christians were suspended, and iron claws that served to tear them to the bone and to their very entrails. Other instruments were destined to pull out all their teeth, one after the other. Their flesh was lacerated with iron combs, or they were flayed. They were tied to the ground and were cut with blows of the hatchet, or their members were gradually cut to pieces, from the toes to their thighs, and from the fingers to the breasts, so that nothing was left but the trunk. They were stretched with their backs against a wheel that dragged them over sharp irons fixed in the ground; or they were tied upon a table, then disembowelled and their intestines taken out.

V. OTHER TORTURES

The Martyrs were also tortured on the rack and with other torments. Sometimes they were exposed to the sun, their bodies being rubbed with honey that they might be stung by the flies and wasps. They were stoned, beheaded, strangled, drowned. There were some who were tied to two trees that had been bent by main force, which when released would tear them asunder. Others tied in a bag were thrown into the sea, or thrown to the dogs or wild beasts. Some were made to die under the press; others perished from hunger.

In some of our narrations the reader may find himself at a loss to account for such barbarity and fierceness as the tyrants practised upon the Martyrs, whose innocence and meekness might be expected to save them from persecution. Let us consider whence this fury came.

It at first originated in the hatred which the pagans bore towards Christians whose virtues were the strongest censure upon their infamous lives.

It was also caused by the instigation of the devils who vehemently abhorred these pious athletes, the more their example served to propagate the Faith and induce others to imitate them.

The principal reason of the persecution was the hatred that those tyrants conceived against the Martyrs at seeing themselves overcome by children, by tender virgins, by simple and ignorant men, who upbraided them with their insanity in following a false religion which authorized every vice and called upon them to worship as gods men who, during their lives, had given the most horrid examples of turpitude and crime that ever disgraced human nature.

Their rage was yet more increased at the sight of the very many miracles wrought through the servants of the true God. They saw wild beasts cast themselves at the feet of the Martyrs; they perceived that red-hot coals, molten lead, did not burn them, and witnessed other similar prodigies. In vain did they cry out: \"This is magic; these are incantations.\" The people were converted in the presence of these miracles, and thousands of them embraced the Faith, and this redoubled the irritation of the judges.

They believed that they were frightening the Christians by inventing new tortures, and flattered themselves that they were extinguishing the Faith by putting all the Christians to death. But the more they multiplied tortures, and immolated victims, the more did the number of the faithful increase. Tertullian relates that a certain governor in Asia, named Arrius, was putting to death those who confessed the Name of the Lord Jesus, when such a multitude presented themselves before his tribunal as caused him to shudder at the thought of shedding so much blood; he therefore contented himself with putting a few of them to death, and to the rest he said: \"If your desire of death be so irresistible, there are precipices enough from which to fling yourselves. Begone!\"

## Evening Meditation

*JESUS EMBRACED AFFLICTIONS FOR OUR SAKE.*

I.

The Apostle, St. Paul, speaking of the Divine Beatitude, calls God the only happy, the only powerful One: *The blessed and only mighty* (1 Tim. vi. 15). And with reason, because all the happiness which can be enjoyed by us, His creatures, is nothing more than the smallest participation in the infinite happiness of God.

God in creating man at the beginning did not place him on earth to suffer, but put him in *the paradise of pleasure* (Gen. ii. 15). He put man in a place of delights in order that he might pass thence to Heaven where he should enjoy for all eternity the glory of the Blessed. But by sin unhappy man made himself unworthy of the earthly, and closed against himself the gates of the heavenly, Paradise, wilfully condemning himself to death and everlasting misery. But in order to rescue man from such a state of ruin, what did the Son of God do? From being blessed and happy as He was He chose to become afflicted and tormented. He made a choice on earth of a life of toil and ignominies. Our Lord revealed to St. Margaret of Cortona that in His whole life He never experienced the smallest degree of sensible consolation: *Great as the sea is thy destruction* (Lam. ii. 13). The life of Jesus Christ was bitter as the sea, which is thoroughly bitter and salt, and contains not one drop of sweet water. And therefore Isaias rightly calls Jesus Christ *a Man of sorrows* (Is. liii. 3), as though He had been capable on this earth of nothing but anguish and sorrow. St. Thomas says that the Redeemer did not simply take sorrow on Himself, but that \"He endured sorrow in its highest degree\"; whereby He would signify that He chose to be the most afflicted Man that had ever been upon earth, or should ever be hereafter.

He comes forth, then, from the prison of His Mother\'s womb, but for what? Is it perhaps to enjoy Himself? He comes forth to fresh suffering, for He chose to be born in the depth of Winter in a cavern where beasts find stabling, and at the hour of midnight. And He is born in such poverty that He has no fire to warm Him, nor clothes enough to screen Him from the cold. \"A grand pulpit is that manger,\" says St. Thomas of Villanova. Oh, how well does Jesus teach us the love of suffering in the grotto of Bethlehem!

II\.

\"In the stable,\" adds Salmeron, \"all is vile to the sight, unpleasant to the hearing, offensive to the smell, hard and revolting to the touch.\" - Everything in the stable is painful: everything is painful to the sight, for one sees nothing but rugged and dark rocks; everything is painful to the hearing, for He hears only the cries of brute beasts; everything is painful to the smell, from the stench of the litter that is scattered around; and everything is painful to the touch, for His cradle is only a narrow manger, and His bed only a handful of straw. Look on this Infant God, how He lies bound up in swaddling clothes, so that He cannot stir. \"God endures,\" said St. Zeno, \"to be bound in swaddling-clothes, because He had come to pay the debts of the whole world.\" And hereupon St. Augustine remarks, \"O Blessed rags, with which we wipe away the uncleanness of sins!\" Observe Him how He trembles with cold; how He weeps, to let us know that He suffers, and offers to the Eternal Father those first tears to release us from that endless wailing which we had deserved! \"Blessed tears,\" says St. Thomas of Villanova, \"which blot out our iniquities!\" O tears for us most blessed, since they obtain for us the pardon of our sins!

And thus did the life of Jesus Christ continue always in affliction and sorrow. But a short time after He was born He was obliged to fly as an exile into Egypt to escape death at the hands of Herod. Then, in that barbarous country He passed many years of His childhood poor and unknown. Nor was the life which He led on His return from Egypt, dwelling at Nazareth, very different up to the time when He suffered death at the hands of the executioners on the Cross in a sea of sorrows and infamy.

O Jesus, my Saviour, I praise Thee, I thank Thee and I love Thee. I love Thee above all things; I love Thee more than myself; I love Thee with all my soul and I give myself all to Thee. Most holy Mary, my refuge and my consolation, recommend me to thy Son.
