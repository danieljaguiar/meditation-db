# Friday\--Third Week after Epiphany

*(For First Friday of February)*

## Morning Meditation

*\"MY SOUL IS SORROWFUL UNTO DEATH.\"*

The grief of the Heart of Jesus came, not on account of the torments He saw He should have to suffer, but from seeing the sins men would commit after His death. It was the sight of my sins that oppressed Thy Heart, O Jesus, and made Thee agonize and sweat Blood. This is the recompense I have made Thee!

I.

*My soul is sorrowful even unto death* (Matt. xxvi. 38). These were the words that proceeded from the sorrowful Heart of Jesus Christ in the Garden of Gethsemani before He went to die. Alas, whence came this extreme grief of His, which was so great that it was enough to take away His life? Perhaps it was on account of the torments that He saw He would have to suffer? No, for He had foreseen these torments from the time of His Incarnation. He had foreseen them, and had accepted them of His own free will: *He was offered because it was his own will* (Is. liii. 7). His grief came from seeing the sins men would commit after His death. It was then, according to St. Bernardine of Sienna, that He saw clearly each particular sin of each one of us. He had regard to every individual sin.

It was not, then, my Jesus, the sight of the scourges, of the thorns, and of the Cross which so afflicted Thee in the Garden of Gethsemani, \-- it was the sight of my sins! Each one of them so oppressed Thy Heart with grief and sadness that it made Thee agonize and sweat Blood. This is the recompense I have made Thee for the love Thou hast shown me by dying for me. Ah, let me share the grief Thou didst feel in the Garden for my sins, so that the remembrance of it may make me sorrowful all my life. Ah, my sweet Redeemer, if I could but console Thee as much now by my grief and love as I then afflicted Thee! I repent, my Love, with all my heart for having preferred my own miserable satisfaction to Thee. I am sorry and I love Thee above all things. Although I have despised Thee, yet I hear Thee ask for my love. Thou wouldst have me love Thee with all my heart: *Love the Lord thy God with all thy heart, and with all thy soul* (Matt. xxii. 37). Yes, my God, I love Thee with all my heart, I love Thee with all my soul. Do Thou give me the love Thou requirest of me. If I have hitherto sought myself, I will now seek none but Thee. And seeing that Thou hast loved me more than others, more than others will I love Thee. Draw me always more and more, my Jesus, to Thy love by the odour of Thine ointments, which are the loving attractions of Thy grace. Finally, give me strength to correspond to so much love which God has borne to an ungrateful worm and traitor. Mary, Mother of Mercy, help me by thy prayers.

II\.

*Neither by the blood of goats or of calves, but by his own blood, entered once into the Holies, having obtained eternal redemption* (Heb. ix. 12).

And of what worth would the blood of all goats or even of all men be, if they were sacrificed to obtain Divine grace for us? It is only the Blood of this Man-God would merit for us pardon and eternal salvation. But if God Himself had not devised this way to redeem us, as He did by dying to save us, who ever would have been able to think of it? His love alone designed it and executed it. Therefore holy Job did well to cry out to this God Who loves man so much: *What is man that thou shouldst magnify him? or why dost thou set thy heart upon him?* (Job vii. 17). Ah, my Jesus, one heart is but little with which to love Thee. If I loved Thee even with the hearts of all men, it would be too little. What ingratitude, then, would it be if I were to divide my heart between Thee and creatures! No, my Love, Thou wouldst have it all, and well dost Thou deserve it; I will give it all to Thee. If I do not know how to give it Thee as I ought, take it Thyself, and grant that I may be able to say to Thee with truth: *Thou art the God of my heart* (Ps. lxxii. 26). Ah, my Redeemer, by the merits of the abject and afflicted life that Thou didst will to live for me, give me true humility which will make me love contempt and an obscure life. May I lovingly embrace all infirmities, affronts, persecutions and interior sufferings, and all the crosses which may come to me from Thy hands. Let me love Thee, and then dispose of me as Thou wilt. O loving Heart of my Jesus, make me love Thee by discovering to me the immense Good that Thou art. Make me all Thine before I die. I love Thee, my Jesus, Who art worthy to be loved. I love Thee with all my heart; I love Thee with all my soul.

## Spiritual Reading

*HEROES AND HEROINES OF THE FAITH*

2\. ST. ARCADIUS (January 12).

St. Arcadius was a native of Africa, and most probably suffered Martyrdom in Caesarea (at present Cherchell, a small village in the province of Mascara, in Algiers), the capital of Mauritania. A furious persecution was raging \-- during which the Christians were cruelly dragged before the idols to sacrifice. Arcadius withdrew to a solitary place, where he employed his time in fasting and prayer. Meanwhile as he did not appear at the public sacrifices, soldiers were despatched to surprise him in his house, but not finding him, they arrested one of his relatives in order to make him discover the retreat of his kinsman.

Arcadius was unwilling that another should suffer on his account, and presented himself to the governor, saying that his relative might be discharged, as he had come to answer for himself. The governor replied that he also might depart unhurt if he would sacrifice to the gods. The Saint courageously answered: \"Thou art deceived if thou believest that threats of death can affright the servants of God. They say with St. Paul: *To me to live is Christ, and to die is gain* (Philipp i. 21). Invent therefore, what tortures thou canst, we shall never be separated from our God.\"

Hereupon the tyrant, full of wrath, and thinking the usual tortures too light for Arcadius, ordered that joint after joint should be chopped off the Saint\'s body, beginning with his toes. The barbarous butchery was instantly executed, during which the holy Martyr ceased not to bless the Lord. After his body had been reduced to a mere trunk, calmly surveying his mangled limbs scattered around him, he exclaimed: \"Oh, happy members that have served to manifest the glory of God! Now that I behold you separated from my body, you are dearer to me than ever. I now know that I belong to Jesus Christ, as I have always desired.\"

Then turning to those present who were idolaters, he said: \"Know ye that all these sufferings are easily overcome by those who continually keep before their eyes eternal life which God bestows upon His servants. Adore the true God, Who consoles me in these tortures; and abandon the worship of your false gods who cannot assist you in your need. He who dies for the true God acquires life everlasting. Behold, for having suffered these torments, I go to live with Him eternally, without fear of ever losing Him.\" Having finished his discourse, he placidly gave his soul to his Redeemer, on the 12th of January.

This Martyrdom filled the idolaters with confusion, and inspired the Christians with a great desire of laying down their lives for Jesus Christ. They afterwards collected the scattered limbs of the Martyr and gave them honourable burial.

## Evening Meditation

*THE GOODNESS AND KINDNESS OF GOD, OUR SAVIOUR*

I.

*The goodness and kindness of God our Saviour appeared* (Tit. iii. 4).

God has loved man from all eternity: *I have loved thee with an everlasting love* (Jer. xxxi. 3). St. Bernard says that before the Incarnation of the Word the Divine Power appeared in creating the world, and the Divine Wisdom in governing it, but when the Son of God became Man, then was made manifest the Love which God had for men. And, in fact, after seeing Jesus Christ accept so afflicted a life and so painful a death, we would be offering Him an insult if we doubted the great love which He bears us. Yes, He does surely love us, and because He loves us, He wishes to be loved by us. *And Christ died for all, that they also who live may not now live to themselves, but for him who died for them and rose again* (2 Cor. v. 15).

Ah, my Saviour, when shall I begin to understand the love Thou hast had for me? Hitherto instead of loving Thee, I have repaid Thee with offences and contempt of Thy graces, but since Thou art infinite in goodness I will not lose confidence. Thou hast promised to pardon him who repents; for Thy mercy\'s sake fulfil Thy promise to me. I have dishonoured Thee by putting Thee aside to follow my own pleasures; but now I grieve for it from the bottom of my soul, and there is no sorrow that afflicts me more than the remembrance of having offended Thee, my Sovereign Good. Pardon me and unite me entirely to Thee by an eternal bond of love, that I may not leave Thee any more, and that I may live only to love Thee and to obey Thee. Yes, my Jesus, for Thee alone will I live, Thee only will I love. Once I left Thee for creatures, now I leave all to give myself wholly to Thee. I love Thee, O God of my soul, I love Thee more than myself. O Mary, Mother of God, obtain for me the grace to be faithful to God till death.

II\.

*By this hath the charity of God appeared towards us, because God hath sent his only-begotten Son into the world that we might live by him* (1 John iv. 9).

All men were dead by sin, and they would have remained dead if the Eternal Father had not sent His Son to restore them to life by His death. But how? What is this? A God to die for man! A God! And who is this man? \"Quid sum ego?\" asks St. Bonaventure. \"What am I? O Lord, and why hast Thou loved me so much?\" But it is in this that the infinite love of God shines forth. *By this hath the charity of God appeared*. The Holy Church exclaims on Holy Saturday, \"O wonderful condescension of Thy mercy toward us! O inestimable affection of charity! That Thou mightest redeem a slave, Thou didst deliver up Thy Son!\" O immense compassion! O prodigy! O excess of the love of God! To deliver a servant and a sinner from the death that he deserves, God\'s innocent Son is condemned to die!

Thou, then, O my God, hast done this that we might live by Jesus Christ: *that we might live by him*. Yes, indeed, it is but meet that we should live for Him, Who has given all His Blood and His life for us. My dear Redeemer, in the presence of Thy Wounds and of the Cross on which I see Thee dead for me, I consecrate to Thee my life and my whole will. Ah, make me all Thine, for from this day forward I seek and desire none but Thee. I love Thee, infinite Goodness; I love Thee, infinite Love. While I live may I always repeat, *My God, I love Thee! I love Thee!* Let my last words in death be: *My God, I love Thee! I love Thee!*
