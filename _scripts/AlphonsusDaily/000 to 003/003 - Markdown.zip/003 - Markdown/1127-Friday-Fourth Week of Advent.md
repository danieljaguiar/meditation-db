# Friday\--Fourth Week of Advent

## Morning Meditation

*JESUS WISHES TO BE LOVED.*

*A child is born to us and a son is given to us* (Is. ix. 6).

Behold the end for which the Son of God willed to be born an Infant \-- to give Himself to us from His Childhood, and thus draw to Himself our love. Thus He wished to be born because He wished to be loved.

I.

God conferred so many blessings on men in order to draw them to love Him; but these ungrateful men not only did not love Him, but they would not even acknowledge Him as their Lord. Only in one corner of the earth, in Judea, was He recognized as God by His chosen people; and by them He was more feared than loved. He, however, Who wished to be more loved than feared by us, became Man like unto us, chose a poor, suffering obscure life, and a painful and ignominious death. And why? To draw our hearts to Himself. If Jesus Christ had not redeemed us, He would have been no less great or less happy; but He determined to procure our salvation at the cost of so many labours and sufferings, as if His happiness depended on ours. He might have redeemed us without suffering; but no \-- He willed to free us from eternal death by His own death; and though He was able to save us in a thousand ways, He chose the most humiliating and painful way of dying through pure suffering on the Cross, to purchase the love of us, ungrateful worms of the earth. And what, indeed, was the cause of His miserable Birth and His most sorrowful death, if not the love He had for us?

Ah, my Jesus, may Thy love for me destroy in me all earthly affections, and consume me in the fire which Thou didst come to kindle on the earth. I curse a thousand times those shameful passions which cost Thee so much pain. I repent, my dear Redeemer, with all my heart, of all the offences I have committed against Thee. For the future I will rather die than offend Thee; and I wish to do all that I can to please Thee. I love Thee, my only Good, my Love, my All.

II\.

*Drop down dew, O ye heavens, from above, and let the clouds rain the just (Is. xlv. 8). Send forth the Lamb, the Ruler of the earth* (Is. xvi. 1).

Thus did the holy Prophets desire for so many years the coming of the Saviour. The same Prophet Isaias said: *Oh, that thou wouldst rend the heavens, and wouldst come down: the mountains would melt away at thy presence \... the waters would burn with fire* (Is. lxiv. 1, 2). Lord, he said, when men shall see that Thou didst come on earth out of love for them, the mountains shall be made smooth, that is, men in serving Thee will conquer all the difficulties that at first appeared to them insuperable obstacles. The waters shall burn with fire, and the coldest hearts will feel themselves burning with Thy love, at the sight of Thee made Man; and how well has this been verified in many happy souls! \-- in St. Teresa, in St. Philip Neri, St. Francis Xavier, who even in this life were consumed by this holy fire. But how many such are there? Alas! but too few.

Ah, my Jesus, amongst these few I wish also to be. How many years ought I not already to be burning in hell, separated from Thee, hating and cursing Thee forever! But no, Thou hast borne with me with so much patience, that Thou mightest see me burn, not with that unhappy flame, but with the blessed fire of Thy love; for this end Thou hast given me so many illuminations, and hast so often wounded my heart while I was far from Thee; finally, Thou hast done so much that Thou hast forced me to love Thee by Thy sweet attractions. Behold, I am now Thine. I will be Thine always and altogether. It remains for Thee to make me faithful, and this I confidently hope from Thy goodness. O my God! who could ever have the heart to leave Thee again and to live even a moment without Thy love? I love Thee with all my heart, but this is too little. My Jesus, hear me, give me more love, more love, more love. O Mary, pray to God for me.

## Spiritual Reading

*ENCOURAGEMENT TO NOVICES*

VIII\. ON THE MEANS OF PERSEVERING IN THE RELIGIOUS STATE

1\. The first means for persevering in the Religious State is to *avoid wilful faults*. Let each one be persuaded that the devil tempts him to commit faults, not so much that he may do evil, as that he may lose his Vocation, for by deliberate faults he begins to lose his fervour in prayer, at Communion, and all the spiritual exercises. The Lord then justly witholds His especial graces, according to that of St. Paul: *He who sows sparingly, shall reap sparingly* (2 Cor. ix. 6). And this the more certainly if his defect be pride, for God resists the proud, and over these the devil acquires great power. So that whilst on the one hand, the tepidity of the novice increases, on the other, the Divine light diminishes; and thus it will not be difficult for the enemy to succeed in making him give up his Vocation.

2\. Another means is *to blow up the mine;* that is, to *reveal the temptation to the Superior*. St. Philip Neri said, \"that a temptation made known, is a temptation half conquered.\" As an abscess, if unopened, becomes gangrened, so a temptation concealed brings on our own ruin. Experience shows that those who hide such temptations in their own bosoms, allow themselves to be brought into a position where they know not whether they should take the right or the left (that is, to doubt which way they ought to take, the right or the left), and generally lose their Vocation. It is necessary, therefore, to make one great effort, and discover all to the Superior. God will be so pleased by this act of humility, and by the violence the novice does to his feelings, that He will instantly enlighten his darkness and dissipate his doubts.

3\. The third means is *Prayer*, that is, *recourse to God, that He may give you the grace of Perseverance*, a grace which, according to St. Augustine, can only be obtained by prayer. But let that novice who has received from God the gift of Vocation, and is tempted to abandon it, take care when he prays to Our Lord, not to say: \"Lord, show me what I ought to do; enlighten me\" \-- because God has already given him light by calling him to His holy House, and if he only asks for this grace, the devil, who can easily change himself into an angel of light, may deceive him and make him believe that the thought of leaving Religion is an effect of divine light. His prayer should rather be: \"O Lord, Thou hast given me a Vocation, give me also strength to persevere in it.\" A certain young man was called by God to the Religious state, and his Vocation being approved by his director, after many trials he joined a Religious Community. His parents did all in their power against him, and succeeded in prevailing upon him to go to another place, that he might more thoroughly examine his Vocation; unfortunately, instead of returning to the Community, he went home, satisfying his parents by this step, but displeasing God. When I asked him how it happened that he committed such an error, he replied, that he had prayed to God in these words: *Speak, Lord, for thy servant heareth* (1 Kings iii. 9). And afterwards he adopted the resolution of returning to his family. I said to him: \"O my son, you were mistaken in your prayer. Your Vocation was certain, being confirmed by so many evident signs; you should not have said: *Loquere, Domine,* for God had already spoken, but: *Confirma hoc, Deus, quad operatus es in me* (Ps. lxvii. 26). (Give me, O Lord, strength to execute Thy will, which Thou hast made known to me). You omitted to do this, and, therefore, you lost your Vocation.\" Let the misfortune of this young man serve as an admonition to others. Again, let not the novice endeavour to tranquillise his mind by the light of his own reason in such times of temptation, for they are indeed seasons of darkness and confusion; let him simply offer himself anew to God, saying: \"O my God, I give myself to Thee, I will never leave Thee, help me lest I become unfaithful to Thee.\" By repeating these words whenever the temptation returns, and, as I have already said, by making his state known to his Superior, he will certainly be victorious. He should recommend himself particularly at such times, to Mary, the Mother of Perseverance.

A novice once suffered himself to yield to a temptation of this kind, and was on the point of quitting the monastery, but, passing before an image of the Mother of God, he stopped and knelt down to repeat an Ave Maria, when he suddenly found himself fixed to the spot and unable to rise; upon which he repented, and made a vow of perseverance. He was immediately freed, and rising, went to ask pardon of the Master of novices, and continued firm in his Vocation.

Finally, I entreat you, my brother, whenever you are tempted concerning your Vocation, to reflect on these two points. First, that the grace of Vocation which God has given you, He has not given to many of your companions, some, perhaps, more deserving than you: *He hath not done in like manner to every nation* (Ps. clvii. 19). Therefore you should fear to be so ungrateful as to turn your back upon Him, for by so doing you would greatly endanger your eternal salvation. And rest assured that you will not have peace, but will be tormented, even to your dying day, with remorse because of your infidelity.

Secondly, if the temptation should present itself to your mind, that if you remain in Religion you will fall into despair and repent of it, and have to render an account to God for it, or things like those we have already spoken of; call to your thoughts the hour of death: you will not then regret that you followed your Vocation, but you will be filled with peace and contentment, instead of the anguish and remorse which would have followed on your having abandoned it. Keep this thought before your mind, and you will not lose your Vocation; you will enjoy in life, and at death, that peace, and hereafter that crown of glory, which God has prepared for His faithful servants.

*An Act of Oblation and Prayer which the Novice should make frequently to obtain from God the Grace of Perseverance in his Vocation*

My God, how can I ever thank Thee enough for having called me so lovingly to Thy family? How have I merited this grace after having committed so many offences against Thee? How many of my companions are left in the world amidst so many dangers of losing their souls, and in occasions of sin! and I am admitted to Thy House, and to the company of so many of Thy dear servants, and to so great an abundance of all things necessary for my sanctification! I hope one day O Lord, to testify my gratitude to Thee in Heaven, by singing eternally Thy mercies to me. Meanwhile I am all Thine, and desire to be so for ever. I will remain faithful and will never leave Thee, even had I to lay down my life, nay, a thousand lives, for Thy sake. I here dedicate myself to Thy will without reserve. Do with me whatever Thou pleasest. Let me live desolate, infirm, despised, if such be Thy pleasure. It is enough that I obey and please Thee. I desire only the grace to love Thee with all my strength, and to remain faithful to Thee till death. Most Holy Mary, my dear Mother, it is you who have obtained from God the so great graces which I have received, pardon of my sins, my Religious Vocation, and the strength to follow it; accomplish your work and obtain for me Perseverance unto death. This is my hope: so may it be!

SOME ADVICE TO A NOVICE UPON THE MEANS BY WHICH HE MAY PRESERVE HIS FERVOUR

When reproved or accused, never excuse yourself, and love cordially in God the person who accuses or reproves you. Love to be made little of in whatever manner it may be, whether in employment, or dress, or cell, or food, etc. Do not give your opinion unless you are asked.

Mortify yourself in all things, according to prudence and obedience, in eating, in sleeping, in hearing, seeing, etc.

Observe modesty when alone, as well as in the presence of others. Lay not your hand upon any person, nor look steadfastly in his face; keep your eyes continually cast down, especially in the church, at table, during recreation, and when abroad. Observe silence, except when there is need to speak for the glory of God, or for your own or your neighbour\'s benefit. Be careful particularly during the time of recreation, not to raise your voice too loud. Avoid disputing or talking about your birth, talents, or riches; about eating, hunting, sports, war, or on the means of acquiring honours, riches, and such secular subjects, but endeavour to introduce pious conversation upon the vanity of honours, riches and pleasures of the world, on the love we owe to Jesus and Mary, on the happiness of the Saints, and on the means of advancing in perfection.

If you commit a fault, immediately humble yourself, make an act of contrition, and then rest in peace.

Desire nothing but what God wills.

Seek not consolations; and, in aridity, say to God with entire humility and resignation: \"O Lord, I do not deserve consolations; I am content to remain in this state all my life.\"

Frequently raise your mind to God by means of ejaculations, such as the following:

My God, I desire nothing but Thee,\
Show me Thy will and I will accomplish it.\
Do with me what Thou wilt.\
I desire, O God, whatever Thou willest.\
My Jesus, I love Thee, I love Thee.\
I renounce all; Thou alone are sufficient for me.\
My God and my all.\
Jesus our love, and Mary our hope.\
O good Jesus, mayst Thou be ever praised.\
My life was Thy death, Thy death is my life.

## Evening Meditation

*THE LOVE OF GOD MANIFESTED TO MEN BY THE BIRTH OF JESUS.*

I.

*The grace of God our Saviour hath appeared to all men instructing us that \... we should live \... godly in this world, looking at the blessed hope and coming of the glory of the great God and our Saviour Jesus Christ* (Titus ii. 11).

Consider that by the *grace* that is said to have *appeared* is meant the tender love of Jesus Christ towards men \-- a love we have not merited, and which, therefore, is called a \"grace.\" This love was, however, always the same in God, but did not always appear. It was at first promised in many prophecies and foreshadowed by many figures; but at the Birth of the Redeemer this Divine love appeared and manifested itself by the Eternal Word showing Himself to man as an Infant, lying on straw, crying and shivering with cold; beginning thus to make satisfaction for us for the penalties we have deserved, and so making known to us the affection which He bore us, by giving up His life for us: *In this we have known the charity of God, because he hath laid down his life for us* (1 Jo. iii. 16). Therefore the love of our God *appeared to all men*.

But why is it, then, that all men have not known it, and that even to this day so many are ignorant of it? This is the reason: *The light is come into the world, and men loved darkness rather than the light* (Jo. iii. 19). They have not known Him, and they do not know Him, because they do not wish to know Him, loving the darkness of sin rather than the light of grace.

O my holy Infant! now I see Thee, poor, afflicted and forsaken; but I know that one day Thou wilt come to judge me, seated on a throne of splendour, and attended by the angels. Forgive me, I implore Thee, before Thou hast to judge me. Then Thou wilt have to act as a just Judge; but now Thou art my Redeemer, and the Father of mercy. I have been of those ungrateful ones who have not known Thee, because I did not choose to know Thee, and therefore, instead of being inclined to love Thee by the consideration of the love Thou hast borne me, I only thought of satisfying my own desires, despising Thy grace and Thy love. But into Thy sacred hands I commend my soul, which I have so long neglected; do Thou save it: *Into thy hands I commend my spirit; thou hast redeemed me, O Lord, the God of truth* (Ps. xxx. 6).

II\.

But let us endeavour not to be of the number of those unhappy souls who are ignorant and ungrateful. If in times past we have shut our eyes to the light, thinking little of the love of Jesus Christ, let us try, during the days that remain to us in this life, to have ever before our eyes the sufferings and death of our Redeemer, in order to love Him Who has loved us so much: *Looking for the blessed hope and the coming of the glory of the great God and our Saviour Jesus Christ*. Thus may we justly expect, according to the divine promises, that Paradise which Jesus Christ has acquired for us by His Blood. At His first coming Jesus appeared as an Infant, poor and humble, and showed Himself on earth born in a stable, covered with miserable rags, and lying on straw; but at His second coming He will appear as Judge on a throne of majesty: *We shall see the Son of Man coming in the clouds with great power and majesty* (Matt. xxiv. 30). Blessed then will he be who shall have loved Him, and miserable those who shall not have loved Him.

In Thee do I place all my hopes, knowing that, to ransom me from hell, Thou hast given Thy Blood and Thy life: *Thou hast redeemed me, O Lord, the God of truth*. Thou didst not condemn me to death when I was living in sin, but hast waited for me with infinite patience, in order that, coming to myself, I might repent of having offended Thee, and might begin to love Thee, and that thus Thou mightest be able to forgive and save me. Yes, my Jesus, I will please Thee. I repent, above every other evil, of all the offences I have committed against Thee; I repent, and love Thee above all things. Do Thou save me in Thy mercy, and let it be my salvation to love Thee always in this life and in eternity. My dearest Mother Mary, recommend me to thy Son. Do thou represent to Him that I am thy servant, and that I have placed all my hope in thee. He hears thee, and refuses thee nothing.
