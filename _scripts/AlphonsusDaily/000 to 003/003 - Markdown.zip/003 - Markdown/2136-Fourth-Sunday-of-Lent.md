# Fourth Sunday of Lent

## Morning Meditation

*THE TENDER COMPASSION OF JESUS TOWARDS SINNERS*

The Lord wrought the miracle of the multiplication of food recorded by St. John through compassion for the bodily needs of those poor people. But far more tender is His compassion for the necessities of the souls of poor sinners who are deprived of Divine grace. O infinite love of our God towards sinners, exclaims St. Bernard, to redeem a slave, neither has the Father spared His Son, nor the Son Himself!

I.

Through the bowels of His mercy towards men who groaned under the slavery of sin and Satan, our most loving Redeemer descended from Heaven to earth, to redeem and save them from eternal torments by His own death. Such was the language of St. Zachary, the father of the Baptist, when the Blessed Virgin, who had already become Mother of the Eternal Word, entered his house. *Through the bowels of the mercy of our God, in which the Orient from on high hath visited us.* (Luke i. 78).

Jesus Christ, the Good Shepherd, Who came into the world to obtain salvation for us His sheep, has said: *I am come that they may have life, and may have it more abundantly.* (Jo. x. 10). Mark the expression, *more abundantly*, which signifies that the Son of Man came on earth not only to restore us to the life of grace we lost, but to give us a better life than that which we forfeited by sin. Yes; for as St. Leo says, the benefits which we have derived from the death of Jesus are greater than the injury which the devil has done us by sin. The same doctrine is taught by the Apostle who says that, *where sin abounded, grace did more abound.* (Rom. v. 20).

But, my Lord, since Thou didst resolve to take human flesh, would not a single prayer offered by Thee be sufficient for the redemption of all men? What need, then, was there of leading a life of poverty, humiliation, and contempt for thirty-three years, of suffering a cruel and shameful death on an infamous gibbet, and of shedding all Thy Blood by dint of torments? I know well, answers Jesus Christ, that one drop of My Blood, or a simple prayer, would be sufficient for the salvation of the world; but neither would be sufficient to show the love which I bear to men: and therefore, to be loved by men when they should see Me dead on the Cross for the love of them, I have resolved to submit to so many torments and to so painful a death. *I am the good shepherd. The good shepherd giveth his life for his sheep\...I lay down my life for my sheep.* (Jo. x. 11-15).

II\.

O men! O men! what greater proof of love could the Son of God give us than to lay down His life for us His sheep? *In this we have known the charity of God: because he hath laid down his life for us.* (1 Jo. iii. 16). No one, says the Saviour, can show greater love to his friends than to give his life for them. *Greater love than this no man hath, that a man lay down his life for his friends.* (Jo. xv. 13). But Thou, O Lord, hast died not only for friends, but for us who were Thy enemies by sin. *When we were enemies we were reconciled to God by the death of his Son.* (Rom. v. 10). O infinite love of our God, exclaims St. Bernard; \"to spare a slave neither the Father spared the Son, nor the Son Himself.\" To pardon us, who were rebellious servants, the Father would not pardon the Son, and the Son would not pardon Himself, but, by His death, has satisfied the Divine justice for the sins which we have committed.

When Jesus Christ was near His Passion, He went one day to Samaria; the Samaritans refused to receive Him. Indignant at the insult offered by the Samaritans to their Master, St. James and St. John, turning to Jesus, said: *Lord, wilt thou that we command fire to come down from heaven and consume them?* (Luke ix. 54). But Jesus, Who was all sweetness, even to those who insulted Him, answered: *You know not of what spirit you are. The Son of Man came not to destroy souls, but to save.* He severely rebuked the disciples. What spirit is this, He said, which possesses you? It is not My spirit: Mine is the spirit of patience and compassion; for I am come, not to destroy, but to save the souls of men: and you speak of fire, of punishment, and of vengeance. Hence, in another place, He said to His disciples: *Learn of me, because I am meek and humble of heart.* (Matt. xi. 29). I do not desire you to learn of Me to chastise, but to be meek, and to bear and pardon injuries.

## Spiritual Reading

*HEROES AND HEROINES OF THE FAITH*

ST. SIMEON, ARCHBISHOP OF SELEUCIA\* AND COMPANIONS

(April 21)

Ecclesiastical history informs us that the Faith of Jesus Christ was preached in Persia by the Apostles themselves, and the number of Christians in that kingdom was consequently very considerable during the reign of Sapor, about the middle of the fourth century. The Magians, or priests of the Persian religion, became alarmed at the spread of Christianity, and, together with the Jews, induced Sapor to persecute the faithful.

\*He is also styled Bishop of Ctesiphon, a city built by the Parthians, on the bank of the river Tigris, opposite to that upon which the ancient Seleucia, now Bagdad, stood.

St. Simeon was, at that time, Archbishop of Seleucia, and his zealous solicitude for his flock caused him to be regarded as the principal defender of the Christian Faith. In order to effect his ruin, his enemies represented to Sapor that he was in continual correspondence with the Roman emperor, to whom, they said, he revealed the most important concerns of the state. Sapor lent a willing ear to these calumnies, and, regarding Simeon as his enemy, resolved not only upon his death, but upon the total extermination of the Christians in his dominions. He began by confiscating their property; and finding that they bore this with patience, he ordered that the clergy who would not abjure Jesus Christ should be beheaded, and that all Christian churches should be levelled to the ground.

The holy bishop was arrested and brought before the tyrant; but, lest it should be thought that he was about to ask pardon for having preached the Christian religion, he did not comply with the Persian custom of prostration, although he had frequently done so on former occasions. Sapor, enraged at this omission, asked him why he refused to render him the homage to which his rank entitled him. The Saint answered: \"When I, on former occasions, appeared in thy presence, I was not led to deny the true God, and therefore refused not to comply with the usual ceremonies; but now I cannot do so, as being called upon to defend my God and my religion.\" The king exhorted him to adore the sun, declaring that great riches and honours would be the reward of his obedience; while his own death, and the extermination of the Christians, would inevitably be the consequence of non-compliance. The Saint, having given the most decided refusal, was sent to prison in the hope that he would be thus induced to change his resolution.

While St. Simeon was being led to prison, Usthazades, the aged Lord chamberlain, prostrated himself before him. But the holy prelate, despising this mark of veneration, and turning his back upon him, reprimanded him because though being a Christian he had adored the sun. The apostate wept bitterly at this rebuke, and throwing off his white robes, dressed himself in mourning. Thus clothed he sat at the king\'s gate, and, with many tears, frequently exclaimed: \"Wretch that I am! If Simeon my friend, treats me thus harshly for my fault, and turns away his face from me, what am I to expect from that God Whom I have denied?\"

Sapor, being informed of the affliction of the courtier, sent for him, and inquired whether any calamity had befallen him. The other replied: \"Ah! would to God that all calamities had befallen me, and not that which is the cause of my grief! I weep because I did not die long ago, but live to behold that sun, which, to please thee, I have adored. I deserve a double death\--one for having denied Jesus Christ, and another for having deceived thee.\" He then protested in the most solemn manner that he would never, henceforward, deny his God. The king became infuriated at these words, and believing that the Christians had turned his head, swore that he would put them all to death; entertaining, however, some compassion for the poor old man, he did all he could to gain him over. Usthazades, notwithstanding, continued to protest that he never again would be so foolish as to give to creatures the honour due to the Creator; and Sapor, finding that his constancy was invincible, ordered him to be beheaded.

While he was being led to execution, he asked a friend to request of Sapor, that, in consideration of his past services, he would order him to be preceeded by a crier, who would proclaim to the people that Usthazades had not been condemned for any crime, but merely for being a Christian, and having refused to abandon his God.\* Sapor the more willingly acceded to his wish as he was anxious to terrify the Christians by showing them that he would not tolerate the profession of their religion, even in an old man who had served him so faithfully.

\*The happy penitent was too much afflicted at his apostasy to be solicitous for his honour, and seems to have made this request in order that the real cause of his death being made public, the scandal which he had given might be repaired. \--Ed.

The king then turned his thoughts towards St. Simeon, and again endeavoured to gain him over; but seeing that all his arts were ineffectual, he commanded him to be beheaded. As a last resource, however, he ordered the heads of one hundred Christians be first struck off in presence of the Saint, who, far from being intimidated, exhorted the sufferers to constancy by telling them how glorious was their lot in acquiring the rewards of eternal life by dying for their Saviour. After the Martyrdom of these hundred Christians, the holy bishop was beheaded on Good Friday, and thus united his death to that of Jesus Christ.

Together with the bishop were beheaded two venerable priests of his church, Ananias and Abdechalas. Pusicius, the prefect of the king\'s workmen, seeing that Ananias, in preparing to receive the stroke, was trembling, exclaimed: Father, shut thy eyes for one moment, and thou shalt instantly see the light of Christ.\"

These words proclaimed Pusicius to be a Christian; he was accordingly arrested and brought before the king, whom he upbraided with his cruelty towards the Christians. Sapor, enraged at his freedom of speech, caused him to be put to death in a strange and most cruel manner\--his tongue was pulled out, not from his mouth, but through an incision made in his neck. His virgin daughter, who had consecrated herself to God, was also arrested and put to death.

All these holy Martyrs died about the year 344.

## Evening Meditation

*REFLECTIONS AND AFFECTIONS ON THE PASSION OF JESUS CHRIST*

I.

*If any man will come after me, let him deny himself\...and follow me.* (Matt. xvi. 24). Since, then, O my Redeemer, Thou dost go before me with Thy Cross, innocent as Thou art, and dost invite me to follow Thee with mine, go forward, for I will not abandon Thee. If, in time past, I have abandoned Thee, I confess that I have done wrong. Give me now what Thou wilt, embracing it, as I do, whatsoever it be, and willing, as I am, to accompany Thee with it even unto death: *Let us go forth from the camp, bearing his reproach.* (Heb. xiii. 13). And how, O Lord, can it be possible for us not to love sufferings and shame for Thy love, Who for our salvation didst love them so much!

But since Thou dost invite us to follow Thee, yea, it is our wish to follow Thee and to die with Thee: give us only the strength to carry it out. This strength we ask of Thee, and hope for, by Thy merits. I love Thee, O my most lovely Jesus, I love Thee with all my soul, and I will never abandon Thee more; enough for me has been the time in which I have gone astray from Thee. Bind me now to Thy Cross. If I have despised Thy love, I repent of it with all my heart; and I now prize it above every good.

II\.

Ah, my Jesus, and who am I that Thou wishest to have me as a follower of Thine, and commandest me to love Thee, and if I will not love Thee, threatenest me with hell? And why, I will say to Thee with St. Augustine, shouldst Thou hold out to me that threat of eternal miseries? For what greater misery could befall me than that of not loving Thee, O most lovely God, my Creator, my Redeemer, my Paradise, my All? I see that, as a just chastisement for my offences against Thee, I have justly deserved to be condemned to the inability of ever loving Thee more; but because Thou dost still love me, Thou dost continue to command me to love Thee, evermore repeating to my heart, \"Thou shalt love the Lord thy God with all thy heart, with all thy soul, and with all thy mind.\" I thank Thee, O my Love, for this sweet precept; and in order to obey Thee, I do love Thee with all my heart, with all my soul, and with all my mind. I repent of not having loved Thee in time past. At this moment I would rather choose to undergo every suffering than live without loving Thee, and I purpose evermore to seek Thy love. Help me, O my Jesus, to be ever making acts of love towards Thee, and to depart out of this life while making an act of love, that so I may come to love Thee, face to face, in Paradise, where I shall ever after love Thee without imperfection and without interruption, with all my powers, for all eternity.

O Mother of God, pray for me. Amen.
