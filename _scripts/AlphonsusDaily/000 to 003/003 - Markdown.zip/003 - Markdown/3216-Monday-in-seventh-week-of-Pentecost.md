# Monday\--Seventh Week after Pentecost

## Morning Meditation

*DEATH\--THE FINAL PREPARATIONS*

At the approach of death the Crucifix will be presented to you, and you will be admonished that Jesus Christ must be your only refuge, your only consolation. To those who have had but little love for Jesus Crucified, this will bring fear rather than encouragement. O my God, assist me by Thy graces to change my life!

I.

If you were about to die, what would you not give for another year, or another month? Resolve, therefore, to do now what you will not be able to do when the hour of your death comes.

Who knows but that this year, or this very month, or even this very day may be your last?

You would not wish to die in the state in which you now are; and will you dare to continue to live on in this state? You lament over those who die suddenly, because they have no time to prepare for death; and you have this precious time, and will you not prepare?

O my God, I will not force Thee to cast me away! I thank Thee for the mercies which Thou hast bestowed upon me; assist me by Thy grace to change my life. I see that Thou desirest to save me; and I desire to be saved that I may praise and love Thee for all eternity.

At the approach of death the Crucifix will be presented to you, and you will be admonished that Jesus Christ must be your only refuge and consolation. To those who have had but little love for Jesus Crucified, this will bring fear rather than encouragement. On the contrary, what a consolation will it be to those who have left all for the love of Jesus!

My beloved Jesus, Thou shalt be my only love in life and in death! *My God and my All*!

For the dying whose consciences are in a bad state, how terrible will be the sole mention of Eternity! They will not hear anything else spoken of but their malady, physicians, remedies; and if the affairs of their soul be mentioned they soon grow weary, change the subject, and beg of you to let them be at rest!

The sinner will exclaim: \"Oh, that I had time to amend my life!\" But it will be said to him: *Depart out of this world*. \"Call in additional medical aid,\" he will answer; \"and try other remedies\". But of what avail will these be? His hour is come; he must depart and go into Eternity.

To him who loves God how consoling will it be to hear it said: *Depart*! He will not be terrified, but rejoice at the thought of being soon out of all danger of losing his sovereign and only Good.

*Let thy place be this day in peace, and thy abode in holy Sion*. What a joyful announcement to him who dies in a well-grounded certainty of being in the grace of God!

O Jesus, in Thy precious Blood I place my hope, that Thou wilt conduct me into that place of peace, where I shall be able to say: O God of my heart, I have now no longer any fear of losing Thee!

*Have compassion, O Lord, on his sighs: have compassion on his tears*. My God, I will not wait until the hour of death to bewail my offences against Thee; I now detest and abhor them, and am sorry for them with my whole heart, and would willingly die of sorrow for having committed them. I love Thee, O infinite Goodness! I desire to live and to die in sorrow and in love.

*Remember, O Lord, he is thy creature; not made by strange gods, but by thee, the only living and true God*. O my God, Thou Who hast created me for Thyself, cast me not away from Thy face. If I have despised Thee, I now love Thee more than myself, and I desire to love Thee alone.

He who has had but little love for Jesus Christ will tremble at the coming of the Holy Viaticum; but he, on the contrary, who has loved only Jesus, will be filled with confidence and love, when he beholds his Lord at hand to accompany him in his passage into Eternity.

While Extreme Unction is being administered, the devil will remind the dying man of all the sins committed by means of the senses. Let us therefore hasten to weep for them before the approach of death.

When he has received all the Sacraments, his relatives and friends will retire, and he will be left alone in the presence of the Crucifix.

O Jesus, when all have abandoned me, do not Thou depart from me! In thee, O Lord have I hoped, let me never be confounded (Ps. xxx. 2).

## Spiritual Reading

*PRAYER, CONDITIONS OF PRAYER*

I-THAT THE PRAYER BE OFFERED FOR ONE\'S SELF OR FOR THINGS NECESSARY FOR SALVATION

*Amen, amen, I say to you, if you ask the Father anything in my name, he will give it you* (Jo. xvi. 23). Jesus Christ, then, has promised that whatever we ask the Father in His Name, the Father will give us. But always with the understanding that we ask under the *proper conditions*. Many seek, says St. James, and obtain not, because they seek improperly: *Ye ask and receive not, because ye ask amiss* (James iv. 3). So St. Basil, following out the argument of the Apostle, says: \"You sometimes ask and receive not, because you have asked badly; either without faith, or lightly, or you have requested things not fit for you, or you have not persevered.\" \"Faithlessly\" (*infideliter*), with little faith or confidence; \"lightly\" (*leviter*), that is, with little desire for the grace you ask; \"things not fit for you\", that is, things not conducive to your salvation; or, you have left off praying. Hence St. Thomas reduces to four in number the conditions required to make Prayer efficacious. These four Conditions are:

A.\--That the Prayer be offered for one\'s self;

B.\--For things necessary for salvation;

C.\--Piously;

D.\--With Perseverance.

A.-THAT THE PRAYER BE OFFERED FOR ONE\'S SELF.

The First Condition, then, of Prayer is that you make it for yourself. The Angelic Doctor holds that one man cannot *ex condigno* (i.e. by title of justice) obtain for another eternal life; and, consequently, not even those graces which are requisite for his salvation, for, as he says, the promise is made not to others, but only to those that pray: *He will give to you.*

There are, nevertheless, many Theologians, Cornelius a Lapide, Sylvester, Tolet, Habert, and others, who hold the opposite doctrine, on the authority of St. Basil, who teaches that Prayer, by virtue of God\'s promise, is infallibly efficacious, even for those for whom we pray, provided they put no positive impediment in the way. And they support their doctrine by Scripture: *Pray for one another, that you may be saved; for the continual prayer of the just man availeth much* (James v. 16). *Pray for them that persecute and calumniate you* (Luke vi. 28). And better still, on the text of St. John: *He that knoweth his brother to sin a sin which is not to death, let him ask, and life shall be given to him who sinneth not unto death* (1 Jo. v. 16). St. Ambrose, St. Augustine, the Venerable Bede, and others explain the words who sinneth not unto death to mean the sinner who does not intend to remain obstinate till death; since for such a one a very extraordinary grace would be required. But for other sinners, who are not guilty of such malice, the Apostle promises their conversion to him who prays for them: *Let him ask, and life shall be given him for him that sinneth.*

Besides, it is quite certain that the prayers of others are of great use to sinners, and are very pleasing to God. The Lord complains of His servants who do not recommend sinners to Him, as He once complained to St. Mary Magdalen de Pazzi, to whom He said one day: *See, my daughter, how many Christians are in the devil\'s hands; if My elect did not deliver them by their prayers they would be devoured*. But God specially requires this of Priests and Religious. The same Saint used to say to her nuns: \"My sisters, God has not separated us from the world that we should only do good for ourselves but also that we should appease Him in behalf of sinners\" and God one day said to her: \"I have given to you, My chosen spouses the City of Refuge (i.e. the Passion of Jesus Christ), that you may have a place where you may obtain help for My creatures. Therefore have recourse to it, and thence stretch forth a helping hand to My creatures who are perishing, and even lay down your lives for them.\" For this reason the Saint, inflamed with holy zeal, used to offer God the Blood of the Redeemer fifty times a day in behalf of sinners, and was quite consumed with the desire she had for their conversion. She used to say: What pain it is, O Lord, to see how one could help Thy creatures by giving one\'s life for them and not be able to do so! In every exercise she recommended sinners to God; and it is written in her Life that she scarcely passed an hour in the day without praying for them. Frequently too, she arose in the middle of the night and went before the Blessed Sacrament to pray for them; and yet for all this, when she was once found bathed in tears, on being asked the cause, she answered, \"Because I seem to myself to do nothing for the salvation of sinners.\" She went so far as to offer to endure even the pains of hell for their conversion, provided that in that place she might still love God; and often God gratified her by inflicting on her grievous pains and infirmities for the salvation of sinners. She prayed especially for Priests, seeing that their good life was the occasion of salvation to others, while their bad life was the cause of ruin to many; and therefore she prayed God to visit their faults upon her, saying: \"Lord, make me die and return to life again as many times as is necessary to satisfy Thy justice for them!\" And it is related in her Life that the Saint, by her prayers, did indeed release many souls from the hands of Lucifer.

I wished to speak rather particularly of the zeal of this Saint; but, indeed, no souls that really love God neglect to pray for poor sinners. For how is it possible for a person who loves God, and knows what love He has for our souls, and what Jesus Christ has done and suffered for their salvation, and how our Saviour desires us to pray for sinners\--how is it possible, I say, that he should be able to look with indifference on the numbers of poor souls who are living without God, and are slaves of hell, without being moved to importune God with frequent prayers to give light and strength to those wretched beings, so that they may rise from the miserable state of perdition in which they are slumbering? True it is that God has not promised to grant our requests when those for whom we pray put a positive impediment in the way of their conversion; but still, God of His goodness has often deigned, at the Prayer of His servants, to bring back the most blind and obstinate sinners to a state of salvation by means of extraordinary graces. Therefore let us never omit, when we say or hear Mass, when we receive Holy Communion, when we make our Meditation or the Visit to the Blessed Sacrament, to recommend poor sinners to God. And a learned author says that he who prays for others will find that his prayers for himself are heard much sooner. But this is a digression. Let us now return to the examination of the other conditions that St. Thomas lays down as necessary for the efficacy of Prayer.

B.-THAT WE PRAY FOR THINGS NECESSARY FOR SALVATION.

The Second Condition assigned by the Saint is that we ask those favours which are *necessary for salvation*; because the promise annexed to Prayer was not made with reference to temporal favours, which are not necessary for the salvation of the soul. St. Augustine, explaining the words of the Gospel, *whatever ye shall ask in my name*, says that what is in any way detrimental to salvation is not asked in the Name of the Saviour. Sometimes, says the same Father, we seek some temporal favours, and God does not hear us; but He does not hear us because He loves us and wishes to be merciful to us. The physician knows better than the patient what is good for the sick man. The physician who loves his patient will not allow him to have those things that he sees would do him harm. Oh, how many, if they had been sick or poor would have escaped those sins which they commit in health and affluence! And, therefore when men ask God for health or riches, He often denies them because He loves them, knowing that these things would be to them an occasion of losing His grace, or at any rate of growing tepid in the spiritual life. Not that we mean to say that it is any defect to pray to God for the necessaries of this present life, so far as they are not inconsistent with our eternal salvation, as the Wise Man said: *Give me only the necessaries of life* (Prov. xxx. 8). Nor is it a defect, says St. Thomas, to have anxiety about such goods, if it is not inordinate. The defect consists in desiring and seeking these temporal goods, and in having an *inordinate anxiety* about them, as if they were our highest good. Therefore, when we ask of God these *temporal favours*, we ought always to ask them *with resignation*, and with the condition *if they will be useful to our souls*; and when we see that God does not grant them, let us be certain that He then denies them to us for the love He bears us, and because He sees that they would be injurious to the salvation of our souls.

It often happens that we pray God to deliver us from some dangerous temptation, and yet that God does not seem to hear us, but permits the temptation to continue troubling us. In such a case let us understand that God permits even this for our greater good. It is not *temptation* nor *bad thoughts* that separate us from God, but *our consent to the evil*. When a soul in temptation recommends itself to God, and by His aid resists, oh, how it then advances in perfection, and unites itself more closely to God! And this is the reason why God does not hear it. St. Paul earnestly prayed to be delivered from the temptation of impurity: *There was given me a sting of my flesh, an angel of Satan to buffet me; for which thing thrice I besought the Lord that it might depart from me*. But God answered him that it was enough to have His grace: *My grace is sufficient for thee* (2 Cor. xii. 7). So that even in temptation we ought to pray with resignation, saying: *Lord, deliver me from this trouble, if it is expedient to deliver me; and if not at least give me help to resist.* And here comes in what St. Bernard says, that when we beg any grace of God, He gives us either that which we ask or some other thing more useful to us. He often leaves us to be buffeted by the waves in order to try our faithfulness, and for our greater profit. He would seem to be deaf to our prayers. But no; let us be sure that God then really hears us, and secretly aids us, and strengthens us by His grace to resist all the assaults of our enemies. See how He Himself: assures us of this by the mouth of the Psalmist: *Thou calledst upon me in affliction, and I delivered thee: I heard thee in the secret place of tempest; I proved thee at the waters of contradiction* (Ps. lxxx. 8).

The other considerations assigned by St. Thomas to Prayer are, that it is to be made *piously and perseveringly*; by *piously* he means with *humility and confidence* \--by *perseveringly*, continuing to pray until death. We must now speak distinctly of each of these three conditions which are the most necessary for Prayer, namely, of *Humility, Confidence*, and *Perseverance*.

## Evening Meditation

*THE PRACTICE OF THE LOVE OF JESUS CHRIST*

*\"Charity hopeth all things\"*

HE THAT LOVES JESUS CHRIST HOPES FOR ALL THINGS FROM HIM

I.

I wish here to propose a doubt which may rise in the mind of one who loves God, and strives to conform himself in all things to His blessed will. If it should be ever revealed to such an one that he was to be eternally lost, would be obliged to bow to it with resignation in order to practise conformity with the will of God? St. Thomas says no; and further, that he would sin by consenting to it, because he would be consenting to live in a state that involves sin, and is contrary to the last end for which God created him; for God did not create souls to hate Him, but to love Him in Heaven: so that He does not wish the death even of the sinner, but that all should be converted and saved. The holy Doctor says that God wishes no one to be damned except through sin; and therefore, a person, by consenting to his damnation, would not be acting in conformity with the will of God, but with the will of sin. But suppose that God, foreseeing the sin of a person, should have decreed his damnation, and that this decree should be revealed to him, would he be bound to coincide in it? In the same passage the Saint says, by no means; because such a revelation must not be taken as an irrevocable decree, but made merely *by way of communication*, as a threat of what would follow if he persists in sin.

II\.

But let every one banish such baneful thoughts from his mind, as only calculated to cool his confidence and love. Let us love Jesus Christ as much as possible here below; let us always be sighing to go hence, and to behold Him in Paradise, that we may there love Him perfectly; let us make it the grand object of all our hopes to go thither to love Him with all our strength. We are commanded even in this life to love God with our whole strength: *Thou shalt love the Lord thy God with thy whole heart, with thy whole soul, and with all thy strength* (Luke x. 27); but the angelical Doctor says that man cannot perfectly fulfil this precept upon earth; only Jesus Christ, Who was both God and Man, and the most holy Mary, who was full of grace and free from Original sin, perfectly fulfilled it. But we miserable children of Adam, infected as we are with sin, cannot love God without some imperfection; and it is in Heaven alone, when we shall meet God face to face, that we shall love Him, nay more, that we shall be necessitated to love Him with all our strength.
