# Friday\--Sixth Week after Pentecost

## Morning Meditation

VENIAL SIN

Venial sin is, unfortunately regarded as a slight evil. Is that called a slight evil which is an offence against God!

A man will go on committing venial sins, and foolishly says: \"It will be enough for me to be saved!\" But I answer: By continuing that course you will not be saved! For, as St. Gregory says, the soul never remains where it falls, but descends much lower.

I.

Venial sin is, unfortunately, regarded as a slight evil. Is that called a slight evil which is an offence against God!

A man will go on committing venial sins, and foolishly says: \"It will be enough for me to be saved!\" But I answer: By continuing that course you will not be saved! For, as St. Gregory says, the soul never remains where it falls, but descends much lower.

St. Isodore writes that he who makes no account of venial sins is permitted by the Almighty to fall into mortal sins, in punishment of his little love of God. And our Lord Himself said to the Blessed Henry Suso that those who have not a horror of venial sins expose themselves to much greater dangers than they are aware of; because it thus becomes much more difficult for them to persevere in grace.

The Council of Trent teaches that we cannot persevere in grace without the special assistance of God; but he is quite undeserving of such special assistance who offends God by voluntary venial sins, and without a thought of amendment. Chastise me not, O Lord, as I have deserved! Remember not the many offences I have committed against Thee, and deprive me not of Thy light and assistance. I desire to amend; I desire to be Thine. O Omnipotent God, accept of me and change me! This is my hope.

Our Lord said to Blessed Angela de Foligno: \"Those who have been enlightened by Me to aim at perfection, but who debase their souls and walk in the ordinary way, will be abandoned by me.\"

He who serves God, but is not afraid of offending Him by venial gratifications, would seem to think that God deserves no better. He declares, in fact, that God is not deserving of so much love as to oblige us to prefer His pleasure to our own satisfaction.

Habitual defects, says St. Augustine, are a kind of leprosy, which renders the soul so disgusting that God deprives it of His loving embraces.

I see, O Lord, that Thou hast not yet abandoned me, as I have deserved; strengthen me, therefore, to shake off my tepidity. I desire never more deliberately to offend Thee. I desire to love Thee with my whole soul. O Jesus, help me! In Thee do I confide.

II\.

St. Francis de Sales says that it is an artifice of Satan: to bind souls first with a hair, that he may afterwards bind them with a chain, and make them slaves. Let us. therefore be on our guard not to be entangled by any passion. A soul that is entangled by passion is either lost or in great danger of being lost.

\"The devil,\" said Mary Victoria Strada, \"when he cannot have much is content with little, but by that little he gains much in the end.\"

Our Lord declares that the lukewarm are loathsome and disgusting to Him: *Because thou art lukewarm\...I will begin to vomit thee out of my mouth* (Apoc. iii.. 16). This means abandonment by God.

Tepidity is a kind of fever, which is scarcely perceived, but if neglected becomes fatal; inasmuch as tepidity renders the soul insensible to remorse of conscience.

O Jesus, do not cast me off, as I have deserved! Look not on my ingratitude, but on the sufferings Thou hast endured for my sake. I am sorry for all my offences against Thee. I love Thee, O my God, and from this day forward I desire to do all in my power to please Thee. O Love of my soul! I have much offended Thee; grant that for the remainder of my life I may love Thee very much. O Mary, my hope, succour me by thy holy intercession.

## Spiritual Reading

PRAYER, ITS NECESSITY

V-THE INTERCESSION OF THE BLESSED VIRGIN

If it be true that the intercession of the Saints is necessary for us, much more is it true of the intercession of the Mother of God, whose prayers are certainly of more value in His sight than those of all the rest of the inhabitants of Heaven together. For St. Thomas says that the Saints, in proportion to the merits by which they have obtained grace for themselves, are able also to save others; but that Jesus Christ, and so also His Mother, have merited so much grace, that They can save all men. \"It is a great thing in any Saint that he should have grace enough for the salvation of many besides himself; but if he had enough for the salvation of all men, this would be the greatest of all; and this is the case with Christ, and with the Blessed Virgin.\" And St. Bernard speaks thus to Mary: \"Through thee we have access to thy Son, O discoverer of grace and Mother of salvation, that through thee He may receive us, Who through thee was given to us.\" These words signify, that as we have access to the Father only by means of the Son, Who is the *Mediator of Justice*, so we have access to the Son only by means of the Mother, who is *mediator of grace*, and who obtains for us, by her intercession, the gifts which Jesus Christ has merited for us. And therefore St. Bernard says, in another place, that Mary has received a twofold fulness of grace. The first was the Incarnation of the Eternal Word, Who was made Man in her most holy womb; the second in that fulness of grace which we receive from God by means of her prayers. Hence the Saint adds: \"God has placed the fulness of all good in Mary, that if we have any hope, any grace, any salvation, we may know that it overflows from her who *ascendeth abounding with delights*. She is a garden of delights, whose odours spread abroad and abound, that is, the gifts of graces.\" So that whatever good we have from God, we receive all by the intercession of Mary. And why so? Because, says St. Bernard, it is God\'s will: \"Such is His will, Who would have us receive everything through Mary.\" But the more precise reason is deduced from the expression of St. Augustine, that Mary is justly called our Mother because she co-operated by her charity in the birth of the faithful to the life of grace, by which we become members of Jesus Christ, our Head: \"But clearly she is the Mother of His members (which we are), because she co-operated by her charity in the birth of the faithful in the Church, and they are members of that Head.\" Therefore, as Mary co-operated by her charity in the spiritual birth of the faithful, so also God willed that she should co-operate by her intercession to make them enjoy the life of grace in this world, and the life of glory in the next; and therefore the Church makes us salute her and give her absolutely the titles of \"our *Life*, our *Sweetness*, and our *Hope*.\"

Hence St. Bernard exhorts us to have continual recourse to the Mother of God, because her prayers are certain to be heard by her Son: \"Go to Mary, I say, without hesitation; the Son will hear the Mother.\" And then he adds: \"My children, she is the ladder of sinners, she is my chief confidence, she is the whole ground of my hope.\" He calls her \"ladder\", because, as you cannot mount the third step except you put your foot on the second, nor can you arrive at the second except by the first, so you cannot come to God except by means of Jesus Christ, nor can you come to Christ except by means of His Mother. Then he calls her \"his greatest security, and the whole ground of his hope\"; because, as he affirms, God wills that all the graces which He gives us should pass through the hands of Mary. And he concludes by saying that we ought to ask all the graces which we desire through Mary; because she obtains whatever she seeks, and her prayers cannot be rejected. \"Let us seek grace, and let us seek it through Mary; because what she seeks she finds, and she cannot be disappointed.\" The following Saints teach the same as St. Bernard: St. Ephrem \"We have no other confidence than from thee, O purest Virgin!\" St. Ildephonsus: \"All the good things that the Divine Majesty has determined to give, He has also decreed to commit to thy hands; for to thee are entrusted the treasures and the ornaments of grace.\" St. Germanus: \"If thou desertest us, what will become of us, O life of Christians?\" St. Peter Damien: \"In thy hands are all the treasures of the mercies of God.\" St. Antoninus: \"He who seeks graces without her, attempts to fly without wings.\" St. Bernardine of Sienna \"Thou art the dispenser of all graces; our salvation is in thy hands.\" In another place, he not only says that all graces are transmitted to us by means of Mary, but he also asserts that the Blessed Virgin, from the time she became Mother of God, acquired a certain *jurisdiction* over all the graces that are given to us. \"Through the Virgin the vital graces are transfused from Christ, the Head, into His mystical body. From the time when the Virgin Mother conceived in her womb the Word of God, she obtained a certain jurisdiction (if I may so speak) over every temporal procession of the Holy Ghost; so that no creature could obtain any grace from God except by the dispensation of His sweet Mother.\" And he concludes: \"Therefore all gifts, virtues, and graces are dispensed through her hands to whom she wills, and as she wills.\" St. Bonaventure says the same: \"Since, the whole Divine nature was in the womb of the Virgin, I do not fear to teach that she has a certain jurisdiction over all the streams of grace; for her womb was, as it were, an ocean of the Divine nature, whence all the streams of grace must emanate.\" On the authority of these Saints many Theologians have piously and reasonably defended the opinion that there is no grace given to us except by means of the intercession of Mary; so Mendoza, Vega, Paciucchelli, Segneri, Poire, Crasset, and others, as also the learned Alexander Natalis, who says: \"Since it is from God we expect all good things, He wishes us to ask them through the intercession of the Virgin Mother, when, as is fitting, we invoke her.\" And he quotes in confirmation the passage of St. Bernard: Such is His Will, Who has determined that we should receive all through Mary.\" Contenson says the same, in a comment on the words addressed by Jesus on the Cross to St. John, *Behold thy mother* (Jo.xi.x. 27); as though He said: \"No one shall be partaker of My Blood except by the intercession of My Mother. My Wounds are Fountains of grace; but their stream shall flow to no one, except through the channel of Mary. O My disciple John, I will love you as you love her.\"

Besides it is certain that if God is pleased when we have recourse to the Saints, He will be much more pleased when we avail ourselves of the intercession of Mary, that she by her merits may compensate for our unworthiness, according to the words of St. Anselm: \"that the dignity of the intercessor may supply for our poverty. So that to invoke the Virgin is not to distrust God\'s Mercy but to fear our own unworthiness.\" St. Thomas, speaking of her dignity, says it is, in a sense, infinite. \"From the fact that she is the Mother of God she has a certain infinite dignity.\"

CONCLUSION

Let us conclude this point by giving the gist of all that has been said hitherto.

He who prays is certainly saved. He who does not pray is certainly damned. All the Blessed (except infants) have been saved by Prayer. All the damned have been lost through not praying. If they had prayed they would not have been lost. And this is, and will be, their greatest torment in hell, to think how easily they might have been saved, only by asking God for His graces. But now for these miserable ones the time for Prayer is over.

## Evening Meditation

THE PRACTICE OF THE LOVE OF JESUS CHRIST

*\"Charity hopeth all things.\"*

HE THAT LOVES JESUS CHRIST HOPES FOR ALL THINGS FROM HIM

I.

The Lord God loves those who love Him: *I love them that love me* (Prov. viii. 17). He showers down His graces on those that seek Him by love: *The Lord is good \... to the soul that seeketh him* (Lament. 25). Consequently, the soul that loves God most has the greatest hope in His goodness. This confidence produces that imperturbable tranquillity in the Saints which makes them always joyful and full of peace, even amid the severest trials; for their love of Jesus Christ, and the conviction they have of His liberality towards those who love Him, leads them to trust solely in Him; and thus they find a lasting repose. The sacred spouse abounded with delights, because she loved none but her Spouse, and leaned entirely on Him for support; and she was full of contentment, since she well knew how generous her Beloved is towards all that love Him; so that of her it is written: *Who is this that cometh up from the desert, flowing with delights, leaning upon her beloved?* (Cant. viii. 5). These words of the Wise Man are most true: *All good things came to me together with her* (Wis. vii. 11). With Charity all blessings are introduced into the soul.

II\.

The primary object of Christian Hope is God, Whom the soul enjoys in the Kingdom of Heaven. But we must not suppose that the hope of enjoying God in Paradise is any obstacle to Charity; since the hope of Paradise is inseparably connected with Charity, which there receives its full and complete perfection. Charity is that infinite treasure, spoken of by the Wise Man, which makes us the friends of God: *An infinite treasure to men, which they that use become the friends of God* (Wis. vii. 14). The angelic Doctor, St. Thomas, says that friendship is founded on the mutual communication of goods; for as friendship is nothing more than a mutual love between friends, it follows that there must be a reciprocal interchange of the goods which each possesses. Hence the Saint says: \"If there be no communication, there is no friendship.\" On this account Jesus Christ says to His disciples:

I have called you friends, because all things whatsoever I have heard of my Father I have made known to you (Jo. xv. 15). Since He had made them His friends, He had communicated all His secrets to them.
