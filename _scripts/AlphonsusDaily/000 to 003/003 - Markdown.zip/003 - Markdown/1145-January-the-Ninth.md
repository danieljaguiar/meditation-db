# January the Ninth

## Morning Meditation

*SALVATION ALONE IS NECESSARY.*

The affair of eternal salvation is not only the *most important*, it is the *only affair* to which we have to attend in this life. Only one thing is necessary. If you save your soul, it will do you no harm to have lived here in poverty, afflictions and contempt.

I.

*But one thing is necessary* (Luke x. 42). It is not necessary that in this world we should be honoured with dignities, favoured with riches, with good health, and earthly pleasures; but it is necessary that we should be saved; for there is no middle course \-- we must either be *saved* or be *damned*. After this short life, we shall be either eternally happy in Heaven, or eternally wretched in hell.

How many worldly persons there are who, loaded with riches and honours in this life, and lifted up to high positions, and even to thrones, now find themselves in hell, where all their fortune in this world serves only to increase their pains and their despair. This is what the Lord warned us of: *Lay not up for yourselves treasures on earth; but lay up for yourselves treasures in heaven, where neither moth nor rust doth destroy* (Matt. vi. 19). The acquisition of earthly goods perishes with death; but the acquisiton of spiritual goods is an unrivalled treasure, and is eternal.

God has taught us that He wills the salvation of all, and to all He gives the power of being saved. Miserable is he who is lost; it is all his own doing: *Destruction is thy own, O Israel; thy help is only in me* (Osee xiii. 9). And this will be the greatest pain of the damned, the thought that they are lost through their own fault. Fire and the worm (that is, the remorse of conscience) will torture the damned in punishment for their sins, but the worm will forever torment them more terribly than the flame. How much pain do we not suffer through the loss of any object of value \-- a diamond, a watch, a purse of money \-- especially when this happens through our own carelessness! We cannot eat or sleep, for thinking of our loss, so long as there is hope of repairing it in some way or other. What, then, will be the torment of one who, through his own fault, has lost God and Paradise, without a hope of ever recovering them!

O my God! what is it that will befall me? Shall I be lost? One lot or the other must be mine. I hope to be saved; but who shall assure me of it? I know that I have repeatedly deserved hell. Yes, my Saviour, Thy death is my hope.

II\.

*We have erred from the way* (Wis. v. 6). The eternal complaint of the souls miserably damned will be: We have gone astray, destroying ourselves of our own accord, and there is no remedy for our error! In most of the misfortunes that occur to persons in this life, a remedy comes with time, or with a change of state, or, at least, through a holy resignation to the will of God. But none of these remedies will help us when we have reached eternity, if in this life we have wandered from the path to Heaven.

Therefore, the Apostle St. Paul exhorts us to labour for our eternal salvation with a continual fear of losing it: *Work out your salvation with fear and trembling* (Phil. ii. 12). This fear will cause us to walk with caution, and to avoid occasions of evil; it will aid us continually to recommend ourselves to God, and thus we shall be saved. Let us pray the Lord that He will fix this thought in our hearts \-- that upon the life we lead in this world depends the question whether we shall be eternally blessed or eternally miserable without hope of remedy.

My God, many times have I despised Thy grace; I deserve no mercy, but Thy Prophet teaches me that Thou showest mercy to all who seek Thee. In the past I have fled from Thee; but now I seek nothing, I ask nothing, I love nothing but Thee. Do not despise me in Thy goodness. Remember the Blood Thou hast shed for me. This Blood, and thy intercession, O Mary, Mother of God, are my only hope.

## Spiritual Reading

*THE GREAT THOUGHT OF ETERNITY*

St. Augustine called the thought of Eternity *the great thought \-- Magna cogitatio*. This thought has brought the Saints to count all the treasures and greatness of this life as nothing more than straw, dust, smoke, and refuse. This thought has sent anchorites to hide themselves in deserts and caves, noble youths, and even kings and emperors, to shut themselves up in cloisters. This thought has given courage to Martyrs to endure the torture of piercing nails and heated irons, and even of being burnt in the fire.

No; we are created not for this earth: the end for which God has placed us in the world is \-- that with our good deeds we may inherit eternal life. *The end is eternal life* (Rom. vi. 22). Therefore, St. Eucherius said that the only affair we should attend to in this life is Eternity; that is, win a happy Eternity, and escape a miserable one: the object for which we contend is Eternity. If assured of this end, we are forever blessed; if we fail in it, forever miserable.

Happy he who lives with Eternity ever in view, in a lively Faith that he must speedily die, and enter upon Eternity. *The just man lives by faith* (Gal. iii. 11). It is Faith that makes the just live in the sight of God, and which gives light to their souls, by withdrawing from them earthly affections, and placing before their thoughts the eternal blessings which God promises to them that love Him.

St. Teresa said that all sins had their origin in a want of Faith. Therefore in order to overcome our passions and temptations, we ought constantly to revive our Faith by saying: *I believe in life everlasting.* I believe that after this life, which will soon be ended, an eternal life awaits me, either full of joys, or full of pains, according to my merits or demerits.

St. Augustine says that the man who thinks of Eternity, and yet is not converted to God, has either lost his senses or his Faith. \"O Eternity!\" (these are his words), \"he that meditates upon thee, and repents not, either has not Faith, or if he has Faith, he has no heart.\" In reference to this, St. John Chrysostom relates that the Gentiles, when they saw Christians sinning, thought them either liars or fools. If you believe not, they said, what you say you believe, you are liars; if you believe in Eternity and sin, you are fools. \"Woe to sinners who enter upon Eternity without having known it, because they would not think upon it!\" exclaims St. Caesarius; and then he adds: \"But oh, double woe! They enter upon it and they never come forth.\"

St. Teresa used to say to her disciples: \"My children, there is *one soul, one Eternity!*\" By which she meant: My children, we have *one soul*, and when that is lost, all is lost; and, *once lost*, it is lost *forever!* In a word, upon the last breath we breathe in dying, depends whether we shall be forever blessed, or forever in despair. If the Eternity of the next life, if Paradise, if hell, were mere fictions of literary men, things of doubtful reality, even then we ought to bestow all our care to live well, and not to risk our soul to be lost forever. But it is not so; these things are not doubtful; they are beyond dispute; they are things of Faith; they are more real than the things we see with our bodily sight.

Let us then pray to our Lord: *Increase our Faith* (Luke xvii. 5); for we may, if weak in Faith, become worse than Luther or Calvin. On the other hand, one thought of living Faith upon the Eternity that awaits us can make us Saints.

St. Gregory writes that they who meditate on Eternity are neither puffed up by prosperity, nor cast down by adversity; for they desire nothing and fear nothing in this world. When infirmities or persecutions come upon us, let us think of the hell we have deserved through our sins. Thus every cross will seem light, and we shall thank the Lord, saying: *It is the mercy of the Lord that we are not consumed* (Lament. iii. 22). And with David: *Unless the Lord had been my helper, my soul had almost dwelt in hell* (Ps. xciii. 17). Through myself I was already lost; Thou hast done this, O God of mercy! Thou hast stretched forth Thy hand, and drawn me forth from hell: Thou hast delivered my soul, that it should not perish (Is. xxxviii. 17).

O my God, Thou knowest how often I have deserved hell; but, notwithstanding, Thou biddest me hope, and I desire to hope. My sins terrify me, but Thy death gives me courage, and Thou dost promise pardon to him that repents. A contrite and humbled heart, O God, Thou wilt not despise. I have dishonoured Thee in the time past, but now I love Thee above all things, and I grieve more than for any other evil, that I have offended Thee. O my Jesus, have mercy upon me. Mary, Mother of God, pray for me.

## Evening Meditation

*THE DWELLING OF JESUS IN EGYPT*

I.

Jesus chose to dwell in Egypt during His infancy, that therein He might lead a hard and a more abject life. According to St. Anselm and other writers, the Holy Family lived in Heliopolis. Let us with St. Bonaventure contemplate the life of Jesus during the seven years He remained in Egypt, as was revealed to St. Mary Magdalen de Pazzi.

The house is very poor, for St. Joseph has little wherewith to pay rent; their bed is poor, their food poor; their life, in short, is one of strict poverty, for day by day they barely gain their livelihood by the work of their hands, and they live in a country where they are unknown and are despised, having neither relatives nor friends.

The Holy Family does indeed live in great poverty; but oh, how well-ordered are the occupations of these three sojourners! The Holy Infant speaks not with His tongue, but in His Heart He continually speaks to His Heavenly Father, offering all His sufferings, and every moment of His life for our salvation. And Mary does not speak, but at the sight of that dear Infant she meditates on the Divine love, and the favour that God has conferred upon her by choosing her for His Mother. Joseph also works in silence; but at the sight of the Divine Child his heart is inflamed, and he thanks the Child for having chosen him for the companion and guardian of His life.

O Holy Infant, Who livest in this country of barbarians, poor, unknown, and despised, I acknowledge Thee for my God and Saviour, and I thank Thee for all the humiliations and sufferings Thou didst endure in Egypt for the love of me. By Thy manner of life there Thou dost teach me to live as a pilgrim on this earth, giving me to understand that this is not my country; but that Paradise which Thou hast purchased for me by Thy death, is my home. Ah, my Jesus, I have been ungrateful to Thee because I have thought but little of what Thou hast done and suffered for me. When I think that Thou, the Son of God, didst lead a life of such tribulation upon this earth, so poor and neglected, how is it possible that I should go about seeking the amusements and good things of the earth? Take me, I pray Thee, my dear Redeemer, for Thy companion; admit me to live always united with Thee upon this earth, in order that, united with Thee in Heaven, I may love Thee there, and be Thy companion throughout eternity.

II\.

In this house Mary weans Jesus: at first she fed Him from her breast, now she feeds Him with her hands; she holds Him in her lap, takes from the porringer a little bread soaked in water, and puts it into the sacred mouth of her Son. In this house Mary released her Infant from His swathing-bands, and made Him His first little garments and dressed Him in them. In this house the Child Jesus begins to walk and speak. Let us adore the first steps of the Incarnate Word, and the first words of Eternal Wisdom uttered by Him. Here also He began to do the work of a little servant-boy, occupying Himself in all the little services that a child can render.

Ah, weaning! ah, little garment! ah, first steps! ah, lisping words! ah, little services of the little Jesus, how do you not wound and inflame the hearts of those who love Jesus and meditate on everything in His life. Behold God trembling and falling! God lisping! God become so weak that He can occupy Himself in nothing but little household affairs, unable even to lift a bit of wood, if too heavy for the strength of a child! O Holy Faith, enlighten us, and make us love this good Lord, Who for the love of us has submitted Himself to so many miseries! It is said that on the entrance of Jesus into Egypt all the idols of the country fell down; oh, let us pray God that He will make us love Jesus from our hearts, since in the soul into which the love of Jesus enters, all idols of earthly affections are overthrown.

Give me light, O God; increase my Faith. What are riches, or pleasures, or dignities, or honours! All is vanity and folly. The only real riches, the only real good, is to possess Thee Who art the Infinite Good. Blessed he who loves Thee! I love Thee, O my Jesus, and I seek none other but Thee. I desire Thee, and Thou desirest me. If I had a thousand kingdoms, I would renounce them all to please Thee. \"My God and my All!\" If in times past I have sought after the vanities and pleasures of this world, I now detest them, and am sorry that I have done so. My beloved Saviour, from this day forward Thou shalt be my only delight, my only love, my only treasure. Most holy Mary, pray to Jesus for me. Beseech Him to make me rich in His love alone, and I desire nothing more.
