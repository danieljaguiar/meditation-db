# Thursday\--Second Week after Epiphany

## Morning Meditation

(For Twenty-Fifth of January)

*THE LIFE OF SORROW JESUS LED EVEN FROM HIS BIRTH*

The Prophet Isaias calls Jesus Christ *the man of sorrows*, because His life was to be full of sorrow. His Passion did not begin at the time of His death. It commenced with His life \-- a life of internal and external sorrows from beginning to end.

I.

Jesus Christ could have saved man without suffering and without dying; but no, He chose a life full of tribulations in order to make us know how much He loved us. Therefore the Prophet Isaias called Him *the Man of sorrows* (Is. liii. 3), because the life of Jesus Christ was to be a life full of sorrows. His Passion did not begin at the time of His death, but from the commencement of His life.

Behold Him, as soon as He is born, laid in a stable where for Jesus everything is a torment. His sight is tormented by seeing nothing in the cave but black, rough walls. His sense of smell is tormented by the stench of the dung of beasts lying there. His sense of touch is tormented by the pricking of the straw that serves Him as a bed. Soon after His birth He is obliged to fly into Egypt where He passed several years of His childhood poor and despised. The life which He afterwards led in Nazareth was not less poor and lowly. Behold Him at length terminating His life in Jerusalem, dying on a Cross by dint of torments.

O my sweet Love, have I, then, by my sins kept Thee in a state of affliction all Thy life long? Oh, tell me, then, what I can do that Thou mayest forgive me, for I will leave nothing undone. I repent, O sovereign Good, of all the offences I have committed against Thee; I repent, and I love Thee more than myself. I feel a great desire to love Thee. It is Thou that givest me this desire; give me, therefore, strength to love Thee ardently.

II\.

Thus, then, the life of Jesus was one of continual suffering, and, indeed, a double suffering; for He had constantly before His eyes all the sorrows that would afflict Him until the day of His death. Sister Mary Magdalen Orsini, complaining one day before the Crucifix, said to Him: \"O Lord, Thou wert on the Cross only for three hours, but I have suffered this pain for several years.\" Jesus answered her: \"Oh, ignorant that thou art, what dost thou say? I suffered even from My Mother\'s womb all the pains of My life and My death.\" But all these sufferings did not so much afflict Jesus Christ \-- because He chose voluntarily to suffer them \-- as did the sight of our sins, and of our ingratitude for His great love. St. Margaret of Cortona was never satisfied with weeping over the offences she committed against God. Wherefore her confessor said to her one day: \"Margaret, cease crying, because God has already forgiven thee.\" But she replied: \"Ah, Father, how can I cease weeping, when I know that my sins kept Jesus Christ in a state of affliction all His life?\"

It is only just, O Jesus, that I, who have offended Thee so much, should also love Thee much. Oh, remind me constantly of the love Thou hast borne me, in order that my soul may always burn with the love of Thee; that it may think of Thee alone, desire Thee alone, and strive to please Thee alone. O God of love, I, who once was the slave of hell, now give myself entirely to Thee. Accept me in Thy mercy, O Jesus, and bind me with Thy love, from this day forth. I will love Thee in life, and loving Thee I will die. O Mary, my Mother and my hope, help me to love Thy dear Jesus and mine. This favour alone I desire and hope from thee.

## Spiritual Reading

*\"THE HAND OF THE LORD IS NOT SHORTENED.\"*

True it is that from time to time divers heresies have sprung up in the Church, which have been productive of much evil; *but the hand of the Lord hath not been shortened*. Even in these latter days we have had authentic accounts of very considerable advances made by the Church, both among heretics and pagans. A learned author writes that ten thousand Arians have recently been converted in Transylvania. In Prussia a very large number of Catholic churches have been erected. In Denmark the public profession of the Catholic Religion is now tolerated. The missions in England are being carried on with very happy results. We have been assured by persons of authority and undoubted veracity, that in the East forty thousand Armenian and other oriental heretics have been received into the communion of our holy Church; that in Syria, Palestine, Egypt, and Chaldea the number of Catholics is every day increasing; and that during the last few years several Nestorian Bishops have abjured the errors of that sect. Finally, during the present Century a considerable number of pagans have been converted in India and China.

But to return to the Martyrs. The number of Christians who had received the Crown of Martyrdom previous to the accession of Constantine was almost incredible. Many authors calculate the number of those who had laid down their lives for the Faith to have been nearly eleven millions! So that if this number were equally distributed in the course of one year, thirty thousand would be allotted to each day.

Oh, the beautiful harvest of holy Martyrs that Paradise has reaped since the preaching of the Gospel! But, O God, what will be the confusion of the tyrants and of all the persecutors of the Faith on the day of General Judgment, at the sight of the Martyrs once so despised and so maltreated by them, when these celestial heroes shall appear in glory, extolling the greatness of God, and armed with the sword of divine justice to avenge themselves for all the injuries and cruelties exercised against them, as was foretold by David: *The high praises of God in their mouths, and two-edged swords in their hands to execute vengeance upon the nations; to bind their kings in fetters, and their nobles in manacles of iron* (Ps. cxlix. 6). Then shall the Martyrs judge the Neros, the Domitians, and other persecutors, and shall condemn them; yea, as we read in the Gospel of St. Matthew, *even to the exterior darkness, where there shall be weeping and gnashing of teeth* (Matt. xxii. 13).

But it will be for us a subject of more profitable meditation to reflect upon another scene which the great day of general and irrevocable doom will present \-- the despair of so many Christians who, having died in mortal sin, will behold with unavailing anguish the triumph of so many Martyrs, who, rather than lose God, suffered themselves to be despoiled of all things, and underwent the most horrid torments that hell could suggest or tyrants inflict; while they, rather than yield a point of honour or forego a momentary gratification, despised the suggestions of divine grace and lost their souls forever!

## Evening Meditation

*THE CONTEMPT WITH WHICH THE SINNER TREATS GOD*

I.

God Himself declares that the sinner treats Him with contempt and complains of it in these words: *I have brought up children, and exalted them; but they have despised me* (Is. i. 2). I have brought up My children, I have preserved and nourished them, but with base ingratitude they have despised Me. But who is God Who is thus despised by men? He is the Creator of Heaven and earth; He is the sovereign, infinite Good, in Whose sight men and Angels are as a drop of water, or a grain of sand: *as a drop of a bucket \... as a little dust* (Is. xl. 15). In a word, all things created, in the presence of His infinite greatness, are as though they were not: *All nations are before him as if they had no being at all, and are counted to him nothing and vanity* (Is. xl. 17).

Behold me, O God, a daring sinner who has presumed to despise Thy infinite majesty. But whilst Thou art infinite majesty, Thou art also infinite mercy. I love Thee, O Lord, and because I love Thee I am sorry for having offended Thee; do Thou have pity on me.

And, O God, who am I who have despised Thee? A poor helpless worm who have nothing but what Thou in Thy bounty hast bestowed upon me. Thou hast given me my soul, my body, the use of reason, and numberless other benefits in this world; and I have made no other use of them all but to offend Thee, my Benefactor. Nay, more; at the very time that Thou didst preserve my life, that I might not fall into hell as I deserved, I abused Thy goodness and forbearance. O my Saviour, how couldst Thou have had such patience with me? Wretch that I am, how many nights have I slept under Thy displeasure! But Thou wouldst not have me perish. I trust, O my Jesus, in Thy Blessed Passion that Thou wilt enable me to change my life. Let not that sacred Blood be lost, which with so much pain and sorrow Thou didst shed for my salvation.

II\.

Man is a miserable worm that can do nothing; he is so blind that he knows nothing; so poor and naked that he possesses nothing. And this miserable worm voluntarily insults God! Vile dust, says St. Bernard, dares to provoke such tremendous Majesty!

O God, what have I done? Thou, my Redeemer, hast shown such regard for my soul as to shed Thy Blood for its salvation, and I have been so wretched as to allow it to perish for a mere nothing, for a caprice, for a maddening passion, for a miserable gratification, in contempt of Thy grace and love. Ah! if Faith did not assure me that Thou didst promise to pardon those who repent, I should not now dare to implore Thy forgiveness. O my Saviour, I kiss Thy sacred Wounds, and for the love of these Wounds I beseech Thee to forget the injuries I have committed against Thee. Thou hast said that when the sinner repents, Thou wilt forget all his ingratitude. I am sorry above every evil for having despised Thee, my sovereign Good; make haste to pardon me, as Thou hast promised; let me be quickly reconciled to Thee. I love Thee now more than myself; may I never more incur Thy displeasure! O Mary, refuge of sinners, succour a poor sinner who invokes thy assistance.
