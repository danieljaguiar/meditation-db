# Saturday after Septuagesima

## Morning Meditation

*SOULS THAT LOVE GOD DESIRE TO GO TO SEE HIM IN HEAVEN.*

The worldly-minded fear losing their earthly goods, fleeting and miserable things that they are, but the Saints only fear losing God Who is a Good infinite and eternal. Wherefore death is an object of terror to souls attached to the earth, while it is specially desired by those who love God; for, says St. Bernard, it is the termination of labour and the gate of life. They cry out with St. Paul: *Who shall deliver me from the body of this death?* (Rom. vii. 24).

I.

*While we are in the body we are absent from the Lord* (2 Cor. v. 6). Souls who, in this life love God alone are like noble pilgrims, destined, according to their present state, to be the eternal brides of the King of Heaven, but now live far away without seeing Him; wherefore they do naught but sigh for their departure to the country of the Blessed, where they know that their Spouse awaits them.

They know, indeed, that their Beloved is ever present with them, but is, as it were, hidden by a veil, and does not show himself. Or, to speak more correctly, He is like the sun behind clouds, which from time to time, sends forth a ray of its splendour, but displays not itself fully. These beloved brides have a veil before their eyes, which prevents them from seeing Him Whom they love. They live, nevertheless, contented, uniting themselves to the Will of the Lord Who chooses to keep them in exile, and far away from Himself; but with all this, they cannot but continually sigh to see Him face to face, in order to be more inflamed with love towards Him.

Therefore, each one of them often sweetly complains to its beloved Spouse because He shows Himself not and says to Him: \"O Thou only love of my heart, since Thou hast so loved me, and hast wounded me with Thy holy love, why hidest Thou Thyself, and allowest me not to see Thee? I know that Thou art infinite Beauty; I love Thee more than myself, though I have never yet beheld Thee. Open to me Thy beautiful countenance; I would know Thee all revealed, in order that I may no more look to myself nor to any creature, and may think only of loving Thee, my highest Good.\"

II\.

When to souls thus enamoured of God there shines forth a ray of Divine goodness and of the love which God bears them, they would wish to be dissolved and melt away for desire of Him, and though for them the sun is still concealed behind the clouds, and His fair face hidden, and their own eyes veiled, so that they cannot gaze on Him face to face; yet what shall be their joy when the clouds disperse, and the gates open, and the veil is taken from their eyes, and the fair countenance of their Beloved appears so that in the clear light of day they look upon His beauty, His goodness, His greatness, and the love He bears them!

O death, why dost thou so long delay to come? If thou comest not, I cannot depart to behold my God. It is thou that must open to me the gates, that I may enter into the palace of my Lord. O blessed country, when will the day come when I shall find myself within thy eternal tabernacles? O Beloved of my soul, my Jesus, my Treasure, my Love, my All! When will that happy moment come, when, leaving this earth, I shall see myself all united with Thee? I deserve not this happiness; but the love Thou hast shown me, and, still more, Thy infinite goodness makes me hope that I shall be one day joined to those happy souls, who, being wholly united with Thee, love Thee, and will love Thee with a perfect love through all eternity. O my Jesus, Thou seest the alternative in which I am placed, of being either united with Thee for ever, or for ever far from Thee! Have mercy upon me. Thy Blood is my hope; and thy intercession, O my Mother Mary, is my comfort and my joy. Amen.

## Spiritual Reading

*PREPARATION FOR DEATH*

Some devout souls, with great spiritual profit to themselves, are accustomed to renew every month, after having been at Confession and Communion, the *Protestation for Death*, imagining themselves at the point of death and about to depart from this world. Unless you do this during life you will find it hard at death to embrace with resignation and love death and all its pains. In her last illness that great servant of God, Sister Catherine of St. Albert, of the Order of St. Teresa, sighed and said: \"Sisters, I do not sigh through fear of death, for I have lived twenty-five years expecting it, but I sigh at the sight of so many Christians who spend their life in sin, leaving themselves only the hour of death to make their peace with God, when I can scarcely pronounce the Name of Jesus!\"

# EXERCISES FOR THE PREPARATION FOR DEATH

## *Preparation for a Happy Death*

Under the Protection of St. Joseph, Patron of the Dying

*Sorrows and Joys of St. Joseph*

1\. O glorious St. Joseph, most pure Spouse of most holy Mary, even as the trouble and anguish of thy heart was great in the perplexity of abandoning thy most chaste and stainless Spouse; so, too, inexplicable was thy delight when the Angel revealed to thee the sovereign mystery of the Incarnation.

Through this sorrow and this joy of thine, we pray thee now, and in our last agony, to comfort our souls with the joy of a good life and of a holy death like unto thine between Jesus and Mary.

\"Our Father,\" \"Hail Mary,\" and \"Glory be to the Father.\"

2\. O glorious St. Joseph, most blessed Patriarch, who wast selected for the office of reputed Father of the Word made Man; the grief which thou didst feel at seeing the Child Jesus born in such great poverty was suddenly changed for thee into heavenly exultation at hearing the angelic harmony, and seeing the glories of that most resplendent night.

Through this sorrow and this joy of thine, we beseech thee to obtain for us that, after the journey of this life is over, we may pass hence to hear the angelic praises, and to enjoy the splendours of the glory of Heaven.

\"Our Father,\" \"Hail Mary,\" and \"Glory be to the Father.\"

3\. O glorious St. Joseph, who didst fulfil most obediently all God\'s commands, the most Precious Blood which the Child Redeemer shed in the Circumcision struck death into thy heart, but the Name of Jesus revived it, and filled it full of joy.

Through this sorrow and this joy of thine, obtain for us that, all vices having been taken from us during life, we may expire in exultation with the Most Holy Name of Jesus in our hearts and upon our lips.

\"Our Father,\" \"Hail Mary,\" and \"Glory be to the Father.\"

4\. O glorious St. Joseph, most faithful Saint, who wast a partaker in the Mysteries of our Redemption, if Simeon\'s prophecy or that which Jesus and Mary were to suffer caused thee a mortal pang, it filled thee also with a blessed joy at the salvation and glorious resurrection of innumerable souls, which he at the same time foretold would thence proceed.

Through this sorrow and this joy of thine, obtain for us that we may be of the number of those who, through the merits of Jesus, and at the intercession of the Virgin Mother, are to rise again in glory.

\"Our Father,\" \"Hail Mary,\" and \"Glory be to the Father.\"

5\. O glorious St. Joseph, most watchful guardian and familiar attendant of the Incarnate Son of God, how much didst thou suffer in supporting and in serving the Son of the Most High, particularly in the flight which thou hadst to make into Egypt; but how much again didst thou rejoice at having always with thee that same God, and at seeing the idols of Egypt fall to the ground!

Through this sorrow and this joy of thine, obtain for us that, by keeping far from us hell\'s tyrant, especially by flying from dangerous occasions, every idol of earthly affection may fall from our hearts; and that, wholly occupied in the service of Jesus and of Mary, we may live for them alone, and die a happy death.

\"Our Father,\" \"Hail Mary,\" and \"Glory be to the Father.\"

6\. O glorious St. Joseph, Angel of the earth, who didst marvel at beholding the King of Heaven subject to thy commands, if thy consolation at bringing Him back from Egypt was disturbed by the fear of Archelaus, yet when assured by the Angel, thou didst dwell in joy with Jesus and Mary at Nazareth.

Through this sorrow and this joy of thine, obtain for us that our hearts, unclouded by hurtful fears, may enjoy peace of conscience, and that we may live secure with Jesus and Mary, and with them may also die.

\"Our Father,\" \"Hail Mary,\" and \"Glory be to the Father.\"

7\. O glorious St. Joseph, model of all holiness, when without fault of thine thou hadst lost the Child Jesus, thou didst seek Him for three days in the greatest sorrow, until with joyful heart thou didst possess again thy Life, finding Him in the Temple among the doctors.

Through this sorrow and this joy of thine, with fervent sighs we supplicate thee to interpose in our behalf, that so it may never befall us to lose Jesus by mortal sin; but that, if unhappily we ever lose Him, we may seek Him again with unwearied sorrow, until once more we find His favour, especially at the moment of our death, so that we may pass to the enjoyment of Him in Heaven, and there with thee sing His Divine mercies for all eternity.

\"Our Father,\" \"Hail Mary,\" and \"Glory be to the Father.\"

*Antiph.* Jesus Himself was beginning about His thirtieth year, being (as it was supposed) the Son of Joseph.

*V.* Pray for us, O holy Joseph.

*R.* That we may be made worthy of the promises of Christ.

*Let us pray.*

O God, who by Thy ineffable Providence didst vouchsafe to choose the Blessed Joseph for the Spouse of Thy most holy Mother; grant, we beseech Thee, that he whom we venerate as our protector on earth may be our intercessor in Heaven. Who livest and reignest for ever and ever. Amen.

Jesus, Mary, and Joseph, I give you my heart and my soul.

Jesus, Mary, and Joseph, assist me in my last agony.

Jesus, Mary, and Joseph, may I breathe out my soul in peace with you.

*After which is said the following.*

PRAYER FOR A HAPPY DEATH

O Lord Jesus, God of goodness and Father of mercies, I approach to Thee with a contrite and humble heart; to Thee I recommend my last hour, and that which then awaits me.

When my feet, now motionless, shall admonish me that my mortal course is drawing to an end;

*R.* Merciful Jesus, have mercy on me.

When my hands, trembling and benumbed, no longer able to hold Thy crucified Image, shall let it fall from their feeble grasp upon my bed of pain;

*R.* Merciful Jesus, have mercy on me.

When my eyes, dim and troubled at the horror of approaching death, shall fix on Thee their languid and expiring looks;

*R.* Merciful Jesus, have mercy on me.

When my lips, cold and trembling, shall pronounce for the last time Thy adorable Name;

*R.* Merciful Jesus, have mercy on me.

When my cheeks, pale and livid, shall inspire the beholders with pity and dismay; and my hair, bathed in the sweat of death, and stiffening on my head, shall forbode my approaching end;

*R.* Merciful Jesus, have mercy on me.

When my ears, soon to be for ever shut to the discourse of men, shall open to hear Thy voice pronounce the irrevocable decree which shall decide my lot for eternity;

*R.* Merciful Jesus, have mercy on me.

When my imagination, agitated by horrid and terrifying phantoms, shall be sunk in mortal anguish; when my soul, affrighted at the sight of my iniquities and the terrors of Thy judgments, shall have to fight against the angel of darkness, who will endeavour to conceal Thy mercies from my eyes, and plunge me into despair;

*R.* Merciful Jesus, have mercy on me.

When my poor heart, oppressed with the pains of sickness, and exhausted by its struggles against the enemies of its salvation, shall be seized with the pangs of death;

*R.* Merciful Jesus, have mercy on me.

When the last tears, forerunners of my dissolution, shall drop from my eyes, receive them as a sacrifice of expiation for my sins, that I may die the victim of penance; and in that dreadful moment,

*R.* Merciful Jesus, have mercy on me.

When my friends and relations, encircling my bed, shall shed the tear of pity over me, and invoke Thy clemency in my behalf;

*R.* Merciful Jesus, have mercy on me.

When I shall have lost the use of my senses, and the world shall have vanished from my sight; when I shall groan with anguish in my last agony and in the sorrows of death;

*R.* Merciful Jesus, have mercy on me.

When my last sighs shall summon my soul to go forth from my body, receive them as the effects of a holy impatience to fly to Thee; and; in that moment,

*R.* Merciful Jesus, have mercy on me.

When my soul, trembling on my lips, shall bid adieu to the world, and leave my body lifeless, pale and cold, receive this separation as a homage, which I shall willingly pay to Thy Divine Majesty; and in that last moment of my mortal life,

*R.* Merciful Jesus, have mercy on me.

When at length my soul, admitted to Thy Presence, shall first behold with terror Thy awful Majesty, reject me not, but receive me into Thy bosom, where I may for ever sing Thy praises; and in that moment when eternity shall begin to me,

*R.* Merciful Jesus, have mercy on me.

*Let us pray.*

O God Who hast doomed all men to die, but hast concealed from all the hour of their death; grant that I may pass my days in the practice of holiness and justice, and that I may deserve to quit this world in Thy holy love; through Jesus Christ our Lord, Amen.

After the Hymn, the Blessed Sacrament will be exposed, and *O Salutaris* sung. Then follows-

*THE PROTESTATION FOR DEATH*

My God, prostrate in Thy Presence, I adore Thee; and I intend to make the following protestation, as if I were on the point of passing from this life into eternity.

My Lord, because Thou art the Infallible Truth, and hast revealed it to the Holy Church, I believe in the Mystery of the Most Holy Trinity, Father, Son, and Holy Ghost; three Persons, but only one God; Who for all eternity rewards the just in Heaven, and punishes the wicked in hell. I believe that the Second Person, that is, the Son of God, became Man, and died for the salvation of mankind; and I believe all that the Holy Church believes. I thank Thee for having made me a Christian, and I protest that I will live and die in this holy Faith.

My God, my Hope, trusting in Thy promises, I hope from Thy mercy, not through my own merits, but through the merits of Jesus Christ, for the pardon of my sins, perseverance, and, after this miserable life, the glory of Paradise. And should the devil at death tempt me to despair at the sight of my sins, I protest that I will always hope in Thee, O Lord, and that I desire to die in the loving arms of Thy goodness.

O God, worthy of infinite love, I love Thee with my whole heart more than I love myself; and I protest that I desire to die making an act of love, that I may thus continue to love Thee eternally in Heaven, which for this end I desire and ask of Thee. And if hitherto, O Lord, instead of loving Thee, I have despised Thy infinite goodness, I repent of it with all my heart, and I protest that I wish to die, always weeping over and detesting the offences I have committed against Thee. I purpose for the future rather to die than ever to sin again; and for the love of Thee I pardon all who have offended me.

O God, I accept of death, and of all the sufferings which will accompany it; I unite it with the sufferings and death of Jesus Christ, and offer it in acknowledgment of Thy supreme dominion, and in satisfaction for my sins. Do Thou, O Lord, accept of this sacrifice which I make of my life, for the love of that great Sacrifice which Thy Divine Son made of Himself upon the Altar of the Cross. I resign myself entirely to Thy Divine will, as though I were now on my deathbed, and protest that I wish to die, saying, *O Lord, always Thy will be done*.

Most holy Virgin, my Advocate and my Mother, Mary, thou art and wilt always be, after God, my hope and my consolation at the hour of death. From this moment I have recourse to thee, and beg of thee to assist me in that passage. O my dear Queen, do not abandon me in that last moment; come then to take my soul and present it to thy Son. Henceforward, I shall expect thee; and I hope to die under thy mantle and clinging to thy feet. My Protector St. Joseph, St. Michael Archangel, my Angel Guardian, my holy Patrons, do you all assist me in that last combat with hell.

And Thou, my Crucified Love, Thou, my Jesus Who wert pleased to choose for Thyself so bitter a death, to obtain for me a good death, remember at that hour that I am one of those dear sheep Thou didst purchase with Thy Blood. Thou who, when all the world shall have forsaken me and not one shall be able to assist me, canst alone console me and save me, do Thou make me worthy then to receive Thee in the Viaticum, and suffer me not to lose Thee for ever, and to be banished for ever to a distance from Thee, No, my beloved Saviour, receive me then into Thy sacred Wounds, for I now embrace Thee. At my last breath I intend to breathe forth my soul into the loving Wound in Thy Side, saying now for that moment: *Jesus and Mary, I give you my heart and my soul*.

*R.* Jesus and Mary, I give you my heart and my soul. O happy suffering, to suffer for God! Happy death, to die in the Lord!

I embrace Thee now, my good Redeemer, that I may die in Thy embraces. If, O my soul, Mary assists you at your departure, and Jesus receives your last breath, It will not be death, but a sweet repose.

Then follows the *Tantum Ergo*, etc.

## Evening Meditation

*MARY RENDERS DEATH SWEET TO HER CLIENTS.*

I.

*He that is a friend loveth at all times, and a brother is proved in distress* (Prov. xvii. 17).

We can never know our friends and relatives in the days of prosperity: it is only in the time of adversity that we see them in their true colours. People of the world never abandon a person in prosperity; but should misfortune overtake him, and particularly if death be at hand, they immediately forsake him. The Blessed Virgin does not act thus with her clients. In all their afflictions, and more particularly in the sorrows of death, the greatest that can be endured in this world, this good Lady and Mother not only does not abandon her faithful servants, but as during our exile on earth she is *our life*, so at our last hour she is *our sweetness*, by obtaining for us a peaceful, happy death. For from the day on which Mary had the privilege and the sorrow of assisting at the death of Jesus her Son Who was the Head of all the predestined, it has become her privilege to assist also at their deaths. And for this reason the Holy Church teaches us to beg this most Blessed Virgin to assist us especially at the moment of our death. *Pray for us sinners now and at the hour of our death*.

O how great are the sufferings of the dying! They suffer from remorse of conscience on account of past sins; from the fear of the approaching Judgment and from the uncertainty of salvation. Then it is that hell arms itself and spares no effort to gain the soul on the point of entering into eternity, for the devils know that only a short time remains in which to gain it, and that if they lose it then they lose it for ever. *The devil is come down unto you having great wrath knowing that he hath but a short time* (Apoc. xii. 12).

Oh, how quickly do the rebellious spirits fly from the presence of this great Queen! At the hour of death if only we have the protection of Mary what need we fear from all our infernal enemies? O you are indeed fortunate if at death you are bound in the sweet chains of the love of the Mother of God! These chains are chains of salvation.

O my most sweet Mother, how shall I die, poor sinner that I am? Even now the thought of that supreme moment in which I must expire and appear before the Judgment seat of God, and the remembrance of having myself so often written my condemnation by consenting to sin, makes me tremble. I am confounded and fear much for my salvation. O Mary, in the Blood of Jesus and in thy intercession is all my hope.

II\.

A great lover of Mary said before expiring: \"O my Father, would that you could know the happiness I now enjoy from having served the most holy Mother of God! I cannot tell you the joy I now experience!\" Father Suarez in consequence of his devotion to Mary died with such peace and joy that he said: \"I could not have thought that death was so sweet!\" You will, without doubt, experience the same joy and contentment in death if you can then remember that you have loved this good Mother who cannot be otherwise than faithful to her children who were faithful in serving and honouring her by their Visits, Rosaries, Fasts, and still more by frequently thanking and praising her and often recommending themselves to her powerful protection.

Nor will this consolation be withheld even if you have been for a time a sinner, provided that from this day you are careful to live well and to serve this most gracious and benign Lady. Though you may have hitherto offended God she will procure you a sweet and happy death. And if at that moment you are greatly alarmed and lose confidence at the sight of your sins, she will come and encourage you as she has so many others. Let us, then, be of good heart though we be sinners; and let us feel assured that Mary will come and assist us at death, and by her presence comfort and console us, provided only that we serve her lovingly during the remainder of our life. Our Queen, addressing St. Matilda one day, promised to assist all her clients at death who, during life, had faithfully served her. \"I a most tender Mother,\" said Mary, \"will faithfully be present at the death of all who piously serve me and will console and protect them.\" O God, what a consolation will it be at that last moment of our lives, when our eternal lot has to be decided, to see the Queen of Heaven assisting and consoling us with the assurance of her protection!

O Consoler of the afflicted, console a poor creature who recommends himself to thee! The remorse of a burdened conscience fills me with affliction. I know not if I have sufficiently grieved for my sins. All my actions are imperfect and sullied. Hell awaits my death in order to accuse me: the outraged justice of God demands satisfaction. My Mother, what will become of me? If thou dost not help me I am lost. Wilt thou not succour me? O compassionate Virgin, console me! Obtain me true sorrow for my sins, and the strength to amend my life and be faithful to God during the rest of my days. When I am in the last agonies of death, O Mary, my hope, do not abandon me. Then, more than ever, help and encourage me that I may not despair at the sight of my sins which the devil will then place before my eyes. O my Queen, pardon my temerity and come thyself to console me by thy presence. Thou hast conferred this grace upon so many others, do not refuse it to me. If my boldness is great, greater still is thy goodness, for it seeks out the most miserable in order to console them. It is this that gives me confidence. For thy eternal glory, be it said that thou hast snatched an unhappy creature from hell to which he was already condemned and hast led him into thy kingdom. O yes, sweet Mother, I hope to have the happiness of remaining always at thy feet in Heaven, thanking and blessing and loving thee for ever! O Mary, I shall expect thee at my last hour. Deprive me not of this consolation. So may it be! Amen. Amen.

In many churches the devout Exercises for a Happy Death are performed once a month, and with great and lasting profit to innumerable souls. A Plenary Indulgence can be gained by all the faithful who assist. These Exercises can be performed privately by each in his or her own home, and, as St. Alphonsus suggests, it would be well for all to do so at least *once a month*. The following is the usual order of the devout Exercises publicly or privately performed.

1\. The Rosary of the Blessed Virgin is recited, or the Seven Joys and Sorrows of St. Joseph.

2\. Then the Sermon, or a *Reading*, or a *Meditation* on Death. See Vol I. Part 1. pp. 23, 70, 270. 274, 370. etc,: Part II, pp. 1, 16, 19, 26, 31, 34, 61, 68, 73. 87, 126, 163.

3\. Then the Prayer for a Happy Death, p. 381, after which a suitable hymn is sung \-- *e.g. God of Mercy and Compassion*, or a hymn to St. Joseph, patron of a happy death.

4\. The Blessed Sacrament is then exposed for Benediction as usual, and after the *O Salutaris Hostia* the *Protestation for Death* is recited, p. 383. Then the *Tantum Ergo*, etc.

Plenary Indulgence, ou the usual conditions, to all who on the fourth Sunday of the month assist at this devout Exercise in any Church of the Redemptorist Fathers. The prayers, \"Sorrows and Joys of St. Joseph,\" do not essentially belong to the Preparation for Death, and may therefore be omitted, They were composed by the Ven. Father Januarius Sarnelli, C.SS.R. (one of the first companions of St, Alphonsus), who in the year 1744 died at Naples in the odour of sanctity.
