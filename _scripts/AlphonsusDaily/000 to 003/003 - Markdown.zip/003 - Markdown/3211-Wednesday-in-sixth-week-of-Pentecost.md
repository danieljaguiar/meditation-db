# Wednesday\--Sixth Week after Pentecost

## Morning Meditation

*MORTAL SIN\--ITS MALICE*

To understand how great is the malice of mortal sin we must first know who God is, and what a wretched being man is who dares to despise Him. Before God all the Saints and Angels are as nothing, and it is a worm of the earth who has the insolence to despise Him!

I.

What is mortal sin? According to St. Thomas and St. Augustine, *it is a turning-away from God*; an act of contempt for God\'s grace and love, and a throwing-of of all respect for Him, by which the sinner declares to God\'s very face: I will not serve Thee! I will act as I please, and, if by so doing, I displease Thee and forfeit Thy friendship, I care not!

To understand how great is the malice of mortal sin, we must first know who God is, and what a wretched being man is who despises Him. Before God all the Saints and Angels are as nothing, and shall a worm of the earth have the insolence to despise Him?

But more than this. Man, by committing sin, not only despises a God of infinite majesty, but a God Who has so loved him as to die for the love of him. An eternity, therefore, would not be sufficient to bewail but one mortal sin.

He who commits mortal sin dishonours God by preferring before Him a whim, a fit of passion, a wretched gratification. A God so great and so good! And so dishonoured!

O Lord, if Thou hadst not sacrificed Thyself on the Cross for the love of me, I should lose all hope of pardon; but Thy death gives me confidence. *Into thy hands I commend my spirit* (Ps. xxx. 6). I commend to Thee my soul for which Thou hast been pleased to shed Thy Blood and sacrifice Thy life; grant that it may love Thee and never more lose Thee. I love Thee, my Jesus, my Love, and my Hope. And how shall I ever be able, after having learned how much Thou hast loved me, to separate myself from Thee, my only Good?

What an affliction it is to us to be injured by one for whom we have done much! God is not capable of grief; but could He grieve, He would die of grief and sorrow at being despised by a creature for whom He gave even His very life.

O my accursed sins, a thousand times do I detest and abhor you! You have caused me to offend my Redeemer, Who has loved me so much!

Unhappy souls, now confined in hell, you who, during life, said that sin was a slight evil, have you not to acknowledge now that all your torments are far less than what you deserved for your sins?

II\.

Sin must surely be a great evil since God, Who is Mercy itself, is obliged to punish it with an eternal hell. Yea, more! In order to satisfy Divine justice for sin, a God was obliged to sacrifice His own life!

O God, we know that hell is the most horrible punishment, and have we no fear of sin, which may cast us into that hell? We know that God has died, in order that He might be able to pardon our sins; and do we still continue to commit sin?

The loss of the least worldly possession makes us uneasy and sad; and does the loss of God distress us not?\--a loss that should not fail to overwhelm us with affliction and grief for the remainder of our lives!

I give Thee thanks, O Lord, for having given me time to bewail my offences against Thee. O Jesus, I abhor and hate them. Give me still greater sorrow, still greater love, that I may lament all my sins, not so much on account of the punishment I have deserved for them, as for having offended Thee, my most amiable God.

What disquiet and fears agitate a courtier who is afraid of having offended his prince? And do we, who know for certain that we have displeased God, and forfeited His friendship, live tranquil, without grief or sorrow!

What care do not men take to avoid poison, which destroys only the body? And yet what great negligence in regard to sin which poisons the immortal soul, and robs us of God!

Let us not be ensnared by that wile of the devil, by which he suggests to us how easily we can afterwards confess a sin. Oh, how many has the enemy drawn into hell by this stratagem!

O my God, for how many years have I deserved to dwell in hell! Thou hast been waiting for me, that I may forever bless Thy mercy, and love Thee. Yes, my Jesus, I bless Thee and love Thee; and I trust in Thy merits that I shall nevermore be separated from Thy love. But if after so many graces and mercies I again offend Thee, how shall I presume that Thou wilt not abandon me, or ever again forgive me? Permit it not, O Lord, that I ever offend Thee again!

## Spiritual Reading

*PRAYER, ITS NECESSITY*

III-ON INVOKING THE SAINTS AND ON PRAYING TO THE SOULS IN PURGATORY

Here a question arises, whether it is *necessary* to have recourse to the intercession of the Saints to obtain the grace of God.

1\. That it is a *lawful* and *useful thing to invoke the Saints*, as intercessors, to obtain for us, by the merits of Jesus Christ, that which we, for our demerits, are not worthy to receive, is a Doctrine of the Church, declared by the Council of Trent. \"It is good and useful to invoke them by supplication, and to have recourse to their aid and influence to obtain benefits from God through His Son Jesus Christ.\"

Such invocation was condemned by the impious Calvin, but most foolishly. For if it is lawful and profitable to invoke *living Saints* to aid us, and to beseech them to assist us in prayers, as the Prophet Baruch did: *And pray ye for us to the Lord our God* (Baruch i. 13); and St. Paul: *Brethren, pray for us* (1 Thess. v. 25); and as God Himself commanded the friends of Job to recommend themselves to his prayers, that by the merits of Job He might look favourably on them: *Go to my servant Job, \... and my servant Job shall pray for you; his face I will accept* (Job xlii. 8); if, then, it is lawful for us to recommend ourselves to the living, how can it be unlawful to invoke the Saints who in Heaven enjoy God face to face? This is not derogatory to the honour due to God, but it is doubling it; for it is honouring the King not only in His Person but in His servants. Therefore, says, St. Thomas, it is good to have recourse to many Saints, \"because by the prayers of many we can obtain that which we cannot by the prayers of one.\" And if any one object: But why have recourse to the Saints to pray for us, when they are already praying for all who are worthy of it? The same Doctor answers that no one can be said to be worthy that the Saints should pray for him; but that \"he becomes worthy by having recourse to the Saints with devotion.\"

2\. Again, it is disputed whether it is useful to recommend one\'s self to the Souls in Purgatory. Some say that the Souls in that state cannot pray for us; and these rely on the authority of St. Thomas, who says that those Souls, while they are being purified by pain, are inferior to us, and therefore \"are not in a state to pray for us, but rather require our prayers.\" But many other Doctors, as Bellarmine, Cardinal Gotti, Lessius, and others affirm with great probability that we should piously believe that God manifests our prayers to those Holy Souls, that they may in turn pray for us; and that so the charitable interchange of mutual prayer may be kept up between them and us. Nor do St. Thomas\'s words present much difficulty; for, as Sylvius and Gotti say, it is one thing *not to be in a state to pray*, another *not to be able to pray*. It is true that those Souls are not in a state to pray, because, as St. Thomas says, while suffering they are inferior to us, and rather require our prayers; nevertheless, in this state they are well able to pray, as they are the friends of God. If a father keeps a son whom he tenderly loves in confinement for some fault; if the son then is not in a state to pray for himself, is that any reason why he cannot pray for others? And may he not expect to obtain what he asks, knowing, as he does, his father\'s affection for him? So the Souls in Purgatory, being beloved by God, and confirmed in grace, have absolutely no impediment to prevent them from praying for us. Still the Church does not invoke them, or implore their intercession, because ordinarily they have no cognisance of our prayers. But we may piously believe that God makes our prayers known to them; and then they, full of charity as they are, most assuredly do not omit to pray for us. St. Catherine of Bologna, whenever she desired any favour, had recourse to the Souls in Purgatory, and was immediately heard. She even testified that by the intercession of the Souls in Purgatory she had obtained many graces which had not been accorded to her by the intercession of the Saints. But here let me make a digression in favour of those Holy Souls.

3\. If we desire the aid of their prayers, it is but fair that we should succour them with our prayers and good works. I said it is fair, but I should have said, *it is a Christian duty*; for Charity obliges us to succour our neighbour when he requires our aid, and we can help him without grave inconvenience. Now it is certain that amongst our neighbours are to be reckoned the Souls in Purgatory, who, although no longer living in this world, yet have not left the Communion of Saints. \"The souls of the pious dead,\" says St. Augustine, \"are not separated from the Church,\" and St. Thomas says more to our purpose that the Charity which is due to the dead who died in the grace of God is only an extension of the same Charity which we owe to our neighbour while living: \"Charity, which is the bond that unites the members of the Church, extends not only to the living, but also to the dead who die in Charity.\" Therefore, we ought to succour, according to our ability, those Holy Souls as our neighbours; and as their necessities are greater than those of our other neighbours, for this reason our duty to succour them seems also to be greater.

But now, what are the necessities of those holy prisoners? It is certain that their pains are immense. The fire that tortures them, says St. Augustine, is more excruciating than any pain that man can endure in this life: \"That fire will be more painful than anything that man can suffer in this life.\" St. Thomas thinks the same, and supposes it to be identical with the fire of hell; \" The damned are tormented and the elect purified in the same fire.\" And this only relates to the *pain of sense*. But the *pain of loss*, that is, the privation of the sight of God, which those Holy Souls suffer, is much greater; because not only their natural affection, but also the supernatural love of God, wherewith they burn, draws them with such violence to be united with their Sovereign Good, that when they see the barrier which their sins have put in the way, they feel a pain so acute that, if they were capable of death, they could not live a moment. So that, as St. Chrysostom says, this pain of the deprivation of God tortures them incomparably more than the pain of sense: \"The flames of a thousand hells together could not inflict such torments as the pain of loss by itself.\" So that those Holy Souls would rather suffer every other possible torture than be deprived for a single instant of the union with God for which they long. So St. Thomas says that the pain of Purgatory exceeds anything that can be endured in this life: \"The pain of Purgatory must exceed all pain of this life.\" And Denis the Carthusian relates that a dead person who had been raised to life by the intercession of St. Jerome, told St. Cyril of Jerusalem that all the torments of this earth are refreshing and delightful when compared with the very least pain in Purgatory: \"If all the torments of the world were compared with the least that can be had in Purgatory they would appear to be comforts.\" And he adds that if a man had once felt these torments, he would rather suffer all earthly sorrows that man can endure till the Day of Judgment than suffer for one day the least pain of Purgatory. Hence St. Cyril wrote to St. Augustine: \"That as far as regards the infliction of suffering, these pains are the same as those of hell\--their *only difference* being that *they are not eternal*.\" Hence we see that the pains of these Holy Souls are excessive, while, on the other hand, they cannot help themselves; because, as Job says: *they are in chains, and are bound with the cords of poverty* (Job xxxvi. 8). They are destined to reign with Christ; but they are withheld from taking possession of their kingdom till the time of their purgation is accomplished. And they cannot help themselves (at least not sufficiently, even according to those Theologians who assert that they can by their prayers gain some relief) to throw off their chains, until they have entirely satisfied the justice of God. This is precisely what a Cistercian monk said to the sacristan of the monastery: \"Help me, I beseech you, with your prayers; for of myself I can obtain nothing.\" And this is consistent with the saying of St. Bonaventure: \"Destitution impedes solvency.\" That is, those souls are so poor, that they have no means of making satisfaction.

## Evening Meditation

*THE PRACTICE OF THE LOVE OF JESUS CHRIST*

*\"Charity believeth all things\"*

HE THAT LOVES JESUS CHRIST BELIEVES ALL HIS WORDS

I.

The true lover of Jesus Christ keeps Eternal Truths constantly in view, and orders all his actions according to them. Oh, how thoroughly does he who loves Jesus Christ understand the force of that saying of the Wise Man: *Vanity of vanities, and all is vanity* (Eccles. i. 2)-that all earthly greatness is mere smoke, mire and delusion; that the soul\'s only welfare and happiness consists in loving its Creator, and in doing His blessed will; that we are, in reality, no more than what we are before God; that it is of no advantage to gain the whole world, if the soul be lost; that all the goods of the world can never satisfy the human heart, that only God Himself can satisfy it; and in fine, that we must leave all in order to gain all.

My beloved Redeemer, O Life of my soul, I firmly believe that Thou art the only Good worthy of being loved! I believe that Thou art the greatest Lover of my soul, since through love alone Thou didst die, overwhelmed with sorrows, for love of me. I believe there is no greater blessing in this world, or in the next, than to love Thee, and to do Thy adorable will. All this I believe most firmly; so that I renounce all things that I may belong wholly to Thee, and that I may possess Thee alone.

II\.

*Charity believeth, all things*. There are other Christians\--though not so perverse as the class we have mentioned, who would fain believe in nothing, so that they may give full scope to their unruly passions, and live on undisturbed by the stings of remorse\--there are others, I say, who believe indeed, but their Faith is languid; they believe the most holy Mysteries of Religion, the Truths of Revelation contained in the Gospel, the Trinity, the Redemption, the holy Sacraments, and the rest; still they do not believe all. Jesus Christ has said: *Blessed are the poor! Blessed are they that hunger! Blessed are they that suffer persecution! Blessed are you when men shall revile you, and shall say all manner of evil against you!* (Matt. v. 3-11). This is the teaching of Jesus Christ in the Gospel. How, then, can it be said that those believe in the Gospel who say: \"Blessed are the rich! Blessed are those who have to suffer nothing! Blessed are those who can have their amusements and pitiable is the man who suffers persecution and ill-treatment from others\"? We must certainly say of such as these that either they do not believe the Gospel or that they believe only a part of it. He who believes all the Gospel esteems it his highest fortune, and a mark of Divine favour in this world, to be poor, to be sick, to be humiliated, to be despised and ill-treated by men. Such is the belief, and such the language, of one who believes all that is said in the Gospel, and has a real love for Jesus Christ.

Help me, through the merits of Thy sacred Passion, O my Jesus, and make me such as Thou wouldst have me to be. I believe in Thee, O infallible Truth! I trust in Thee, O infinite Mercy! I love Thee, O infinite Goodness! O infinite Love, I give myself wholly to Thee, Who hast given Thyself wholly to me in Thy Passion, and in the Holy Sacrament of the Altar.

And I recommend myself to thee, O Mary, Refuge of sinners, and Mother of God.
