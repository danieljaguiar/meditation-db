# Fifth Sunday after Pentecost

## Morning Meditation

SALVATION IS OUR ONLY BUSINESS IN THIS WORLD.

*One thing is necessary* (Luke x. 42). It is not necessary we should be rich, or honoured, or in the enjoyment of good health, but it is necessary we should be saved. For this end alone has God placed us in this world, and woe to us if we do not attain it!

I.

Of all our affairs there is none more important than that of our eternal salvation, on which depends our happiness or misery for eternity.

*One thing is necessary.* It is not necessary that we should be rich, honoured, or in the enjoyment of good health, but it is necessary that we should be saved. For this end alone has God placed us in the world; and woe to us if we do not attain it!

St. Francis Xavier said that the only good to be obtained in this world is salvation; and the only evil to be dreaded, damnation. What matter if we are poor, or despised, or infirm? If we are saved we shall be happy forever. On the contrary, what does it avail to be great, or to be monarchs? If we are lost, we shall be miserable for all eternity.

O God, what will become of me? I may be saved, and I may also be lost! And if I may be lost, why do I not resolve to adhere more closely to Thee?

My Jesus, have pity on me. I will amend my life. Give me Thy assistance. Thou hast died to save me, and shall I, notwithstanding, forfeit my salvation?

II\.

Have we already done enough to secure salvation? Are we already secure of not falling into hell?

*What exchange shall a man give for his soul?* (Matt. xvi. 26). If he lose his soul, what will compensate him for his loss?

What have not the Saints done to secure their salvation? How many kings and queens have renounced their kingdoms and shut themselves up in cloisters! How many young men have left their country, and have gone to live in deserts! How many young virgins have renounced marriage with the great ones of the world, to go and give their lives for Jesus Christ! And what are we doing?

O my God, how much has Jesus Christ done for our salvation! He spent thirty-three years in toil and labour; He gave His Blood and His Life; and shall we, through our own fault, be lost?

O Lord, I give Thee thanks for not having called me out of the world when I had forfeited Thy grace. Had I died then, what would have become of me for all eternity?

God desires that all should be saved: *He will have all men to be saved.* (1 Tim. ii. 4). If we are lost, it will be entirely our own fault. And this will be our greatest torment in hell.

St. Teresa says that even the loss of a trifle, of an ornament, of a ring, when it has happened through our own carelessness, occasions us the greatest uneasiness. What a torment, then, will it be to the damned to have wilfully lost all\--their souls, Heaven, and God!

Alas! death approaches; and what have I done for life eternal?

O my God, for how many years have I deserved to dwell in hell, where I could not repent, nor love Thee! Now that I can repent and love Thee, I will repent and I will love Thee.

## Spiritual Reading

I.\--THE ADVANTAGE OF A RETREAT MADE IN SOLITUDE AND SILENCE.\*

I have received your last letter in which you tell me you are still undecided as to the state of life you should choose, and that having communicated to your Pastor the advice I gave you\--namely, to go for that purpose to perform the Spiritual Exercises in the house your father owns in the country\--the said Pastor answered you it was not necessary to go there to torture your brains for eight days in solitude, but that it was enough for you to attend the Retreat he would soon have for the people in his own church. Now, as on this point of making the Exercises you again ask my advice, it is necessary I should answer you more at length, and show you how much greater the fruit of the Spiritual Exercises is when they are performed in silence, in some retired place, than in public, when one is obliged during the time to live in one\'s own house and converse with relatives and friends: and the more so in your case, for, as you write to me, you have in your own home no quiet room to which you can retire.

Besides, I am very much in favour of a Retreat performed in solitude, closed away from the world, as I know it is to such a Retreat I owe my own conversion and my resolution to give up the world. I will later suggest to you the means and precautions to be taken during the Spiritual Exercises in order to reap from them the fruit you desire. I beg of you, when you have read this letter yourself, to give it to your Rev. Parish Priest that he may read it also.

Let us, then, speak first of the great benefit of the Spiritual Exercises when performed in solitude, where one converses with God alone, and let us see the reason for this.

The truths of eternal life, such as the great affair of our salvation, the value of the time God gives us that we may amass merits for a happy Eternity, the obligations under which we are to love God for His infinite goodness and the immense love He has for us, \--these and similar things are not seen with the eyes of the flesh, but only with the eyes of the mind. It is, on the contrary, certain that, unless our understanding represents to the will the value of a good or the greatness of an evil, we shall never embrace that good nor reject that evil. And this is the ruin of those who are attached to this world. They live in darkness, and not seeing the greatness of eternal good and eternal evil, and allured by the senses, they give themselves up to forbidden pleasure and thus miserably perish.

Wherefore the Holy Ghost admonishes us that in order to avoid sin we must keep before our eyes the Last Things which are to come upon us; that is, Death, with which all the goods of this earth will come to an end for us, and the Divine Judgment, in which we shall have to give to God an account of our whole life. *Remember thy last end and thou shalt never sin* (Ecclus. vii. 40). And in another place God says: *Oh, that they would be wise and would understand and would provide for their last end* (Deut. xxxii. 29). By which words He wishes us to understand that if men would consider the things of the next life, they would all certainly take care to sanctify themselves, and would not expose themselves to the danger of an unhappy life in Eternity. But they shut their eyes to the light and thus, remaining blind, precipitate themselves into an abyss of evil. This is why the Saints always prayed the Lord to give them light. *Enlighten my eyes, that I never sleep in death* (Ps. xii. 4). *May God cause the light of his countenance to shine upon us* (Ps. lxvi. 2). *Make the way known to me wherein I should walk* (Ps. cxlii 8). *Give me understanding and I will learn thy commandments* (Ps. cxviii. 73).

Now in order to obtain this Divine light we must come close to God. *Come ye to him and be enlightened* (Ps. xxxiii. 6). For, as St. Augustine tells us, that as we cannot see the sun without the light of the sun itself, so we cannot see the light of God but by the light of God Himself. This light is obtained in the Spiritual Exercises; by them we come close to God, and God enlightens us with His light. The Spiritual Exercises mean nothing else than that we retire for a time from intercourse with the world, and go to converse with God alone, where God speaks to us by His inspirations, and we speak to God in our meditations by acts of love, by repenting of the sins by which we have displeased Him, by offering ourselves to serve Him for the future with all our heart, and by beseeching Him to make known to us His will, and give us strength to accomplish it.

Holy Job says: *Now I should have rest in my sleep with kings and consuls of the earth who build themselves solitudes* (Job iii. 13). Who are these kings that build themselves solitudes? They are, as St. Gregory says, those who rise above this world, and withdraw from its tumults to render themselves fit to talk alone with God. \"They build solitudes, that is, they separate themselves as far as possible from the tumult of the world, in order to be alone and to become fit to speak with God.\"

One day as St. Arsenius was reflecting on the means that he should take to become a saint, God caused him to hear these words: *Fuge! Tace! Quiesce!* \" Fly! Be silent! And rest!\" Fly from the world; be silent; cease to talk with men, and speak only with Me, and thus rest in peace and solitude. In conformity with this, St. Anselm wrote to one worried by many worldly occupations, who complained that he had not a moment of peace, and gave the following advice: \"Leave your occupations for a while; hide yourself from your tumultuous thoughts; apply yourself for a time to contemplate God and rest in Him: Say to God: Now teach my heart where and how I may seek Thee; where and how I may find Thee.\" Words that are applicable, each and all, to yourself. Fly, says he, for a short time from those earthly occupations which render you so unquiet, and rest in solitude with God. Say to Him: O Lord, show me where and how I may find Thee, that I may speak alone with Thee, and at the same time hear Thy words.

God speaks indeed to those who seek Him, but He does not speak in the midst of the tumult of the world. The Lord is not in the commotion of the earthquake, as was said to Elias when God called him to solitude. The voice of God, as it is said in the same place, is as the breath of a gentle air, which is scarcely heard, and then not by the ear of the body, but by that of the heart, without noise and in a sweet retreat. This is exactly what the Lord says through Osee: *I will lead her into solitude, and I will speak to her heart* (ii. 14). When the Lord wishes to draw a soul to Himself, He leads it into solitude, far from the embarrassment of the world and intercourse with men, and there speaks to it in words of fire. The word of God is said to be of fire, because it melts a soul, as the sacred Spouse says: *My soul melted when he (my beloved) spoke* (Cant. v. 6). It prepares the soul to submit readily to the direction of God, and to embrace the manner of life which God wishes. The word of God is so exceedingly efficacious that at the very time it is heard it operates in the soul all that God requires.

\*This little treatise was written by St. Alphonsus in the form of a letter to a young man who consulted him as to the state of life he should choose. ED.

## Evening Meditation

THE PRACTICE OF THE LOVE OF JESUS CHRIST.

*\"Charity beareth all things.\"*

HE THAT LOVES JESUS CHRIST BEARS ALL THINGS FOR HIM, AND ESPECIALLY ILLNESS, POVERTY, AND CONTEMPT.

I.

Father Balthazar Alvarez said that a Christian must not imagine himself to have made any progress in perfection until he has succeeded in penetrating his heart with a lasting sense of the sorrows, poverty, and ignominies of Jesus Christ, so as to be able to support with loving patience every sorrow, privation, and contempt, for the sake of Jesus Christ.

In the first place, let us speak of bodily infirmities, which, when borne with patience, merit for us a beautiful crown.

St. Vincent de Paul said: \"Did we but know how precious a treasure is contained in infirmities, we would accept them with joy as the greatest of all possible blessings.\" Hence the Saint himself, though constantly afflicted with ailments that often left him no rest day or night, bore them with so much peace and serenity of countenance that no one could guess that anything ailed him at all. Oh, how edifying to see a sick person bear his illness with a peaceful countenance, as did St. Francis de Sales! When he was ill, he simply made known his complaint to the physician, obeyed him exactly by taking the prescribed medicines, however nauseous; and for the rest, he remained at peace, never uttering a single complaint in all his sufferings. What a contrast to this is the conduct of those who do nothing but complain even for the most trifling indisposition, and who would like to have around them all their relatives and friends in order to have their sympathy! Far different was the instruction of St. Teresa to her nuns: \"My sisters, learn to suffer something for the love of Jesus Christ, without letting all the world know of it.\" One Good Friday Jesus Christ favoured the Venerable Father Louis da Ponte with so much bodily suffering that no part of him was exempt from its particular pain; he mentioned his severe sufferings to a friend, but he was afterwards so sorry at having done so that he made a vow never again to reveal to anybody whatever he might afterwards have to suffer. I say \" he was favoured\"; for, to the Saints, the illnesses and pains which God sends them are real favours.

II\.

One day as St. Francis of Assisi lay on his bed in excruciating torments, a companion said to him:\" Father, beg of God to ease your pains, and not to lay so heavy a hand upon you.\" On hearing this the Saint instantly leaped from his bed, and going down on his knees, thanked God for his sufferings; then, turning to his companion he said: \"Listen; did I not know that you so spoke from simplicity, I would refuse ever to see you again.\"

Some one who is sick will say it is not so much the infirmity itself that afflicts me as that it prevents me from going to church to perform my devotions, to communicate, and to hear Holy Mass; I cannot go to choir to recite the Divine Office with my brethren; I cannot celebrate Mass; I cannot pray; for my head is aching with pain, and light almost to fainting. But tell me now, if you please, why do you wish to go to church or to choir? Why would you communicate and say or hear Holy Mass? Is it to please God? But it is not now the pleasure of God that you say Office; that you communicate, or hear Mass; but that you remain patiently on this bed, and support the pains of this infirmity. But you are not pleased with my speaking thus; then you are not seeking to do what is pleasing to God, but what is pleasing to yourself. The Blessed John of Avila wrote as follows to a priest who so complained to him: \"My friend, busy not yourself with what you would do if you were well, but be content to remain ill as long as God thinks fit. If you seek the will of God, what matters it to you whether you be well or ill?\"
