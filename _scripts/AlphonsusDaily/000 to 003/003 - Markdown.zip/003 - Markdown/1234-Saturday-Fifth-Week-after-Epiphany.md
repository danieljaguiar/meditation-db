# Saturday\--Fifth Week after Epiphany

## Morning Meditation

*CONFIDENCE IN THE INTERCESSION OF THE BLESSED VIRGIN MARY*

HER POWER TO HELP US

Consider how great are the grounds of hope the soul has that trusts in the intercession of the great Mother of God. Behold the words applied by the Church to Mary on her Festivals: *He that shall find me shall find life and shall have salvation from the Lord* (Prov. viii. 35). It is impossible for a true and persevering client of Mary to be lost, for she can want neither the power nor the will to assist him.

I.

*He that shall find me shall find life and shall have salvation from the Lord*. He that shall find me, says Mary, shall find the life of grace here, and eternal glory hereafter. Addressing the Divine Mother, St. Anselm goes so far as to say that, as it is impossible for a person who is not devoted to Mary and protected by her, to be saved, so, on the other hand, it is impossible for him to be lost who recommends himself to Mary, and is regarded by her with love. St. Antoninus, says that all those that are defended by this great Queen are necessarily saved. St. Bonaventure writes that they that obtain the protection of Mary shall, even while they live on this earth, be acknowledged as companions by the Saints in glory, and that they that carry the badge of servant of Mary be written in the Book of Life. Thus to be devoted to Mary is a mark of predestination. The Angelic Doctor says that Mary is called the *Star of the sea* because, as navigators are directed to the port by means of the pole star, so Christians are guided to Paradise by Mary.

Should a person truly devoted to Mary be lost it would be because she is either unable or unwilling to assist him. \"But no,\" says St. Bernard, \"she can neither lack the power nor the will.\" It is impossible for a true and persevering client of Mary to be lost; because she can neither want the power nor the will to assist him. To inspire us with confidence, then, in this great advocate, the holy Church invokes her under the title of *Powerful Virgin. Virgo potens, ora pro nobis!* Yes, that God Who is omnipotent, has, as she herself has said, given her great power. *He that is mighty hath done great things to me* (Luke i. 49).

My Lady, if thou pray for me, I shall be saved; for thou dost obtain by thy prayers whatsoever thou wishest. Pray, then, for me, O great Mother of God: for thy Son hears thee, and grants whatever thou askest. It is true that I am unworthy of thy protection, but thou hast never abandoned a soul that had recourse to thee. O Mary, I consign my soul to thee; thou hast to save it. Obtain for me perseverance in the Divine grace, and the love of thy Son and of thee.

II\.

St. Theophilus, Bishop of Alexandria, has written: \"The Son is pleased that the Mother should pray to Him, because He wishes to grant her whatever she asks, in order to repay her for the favour received from her in giving Him her flesh.\" St. Bridget heard Jesus say to Mary: \"Ask what you wish from Me, for your petition cannot be fruitless.\" My Mother, ask of Me what you wish; you know that I cannot reject any of your petitions. He then added: \"Because you refused Me nothing on earth, I will refuse nothing to you in Heaven.\" You refused Me nothing while I lived on earth; it is right that I refuse you nothing now that you are with Me in Heaven.

But what is the principal reason the prayers of Mary are so powerful before God? St. Antoninus says: \"The prayer of the Mother of God partakes of the nature of a command; hence it is impossible that she should not be heard.\" The prayers of Mary, being the prayers of a mother, partake in a certain manner of the nature of a command, and therefore they cannot be rejected. Hence, Blessed Albert the Great, used to repeat the words of the Church: *Show thyself a mother!* \-- in this sense: O Lady, show thyself a mother! Ask thy Son, as His Mother, to have mercy on us. Cosmas of Jerusalem asserts that the protection of Mary is omnipotent: *Omnipotens auxilium tuum, O Maria*. Yes, says Richard of St. Laurence, it is but just that the Mother should share the power of the Son. The Son is *omnipotent by nature*, the Mother is *omnipotent by grace*; that is, she obtains by her prayers whatsoever she wishes.

Let a sinner be ever so abandoned, says St. Gregory of Nicomedia, if he has recourse to Mary, she will save him by her intercession. O Mother of God, thou hast invincible power that thy clemency may not be conquered by the multitude of our sins. Nothing can resist thy power since the Creator regards as His own the glory of His Mother. \"Thou, then,\" says St. Peter Damian, \"canst do all things, for thou canst inspire even those who are in despair with hopes of salvation.\" As often as the devil tempts us to diffidence, let us turn to Mary, and say to her, with St. Germanus: \"Thou, O Mary, art omnipotent in saving sinners; thy prayers are all-powerful with God, because thou art Mother of true Life.\"

O my Queen, I love thee, and I hope always to love thee. Do thou also love me. Take me under thy protection and have pity on me: grant me this favour through the love thou bearest thy Son. Behold the confidence that I place in thy clemency, and do not cease to assist me in all my wants. I know that thou wilt not cease to help me as often as I recommend myself to thee; but obtain for me also the grace to have recourse to thee in all my temptations, and in all my dangers of losing God. Assist me, particularly at the hour of my death. Obtain for me the grace that with my last breath I may pronounce thy name, and the Name of thy Son, saying: Jesus and Mary, to you I recommend my soul!

## Spiritual Reading

*HEROES AND HEROINES OF THE FAITH*

14\. \-- ST. LEO OF PATARA

(February 18)

At Patara, in Lycia, a great festival was once being celebrated in honour of a certain idol, at which a great concourse assembled. Many went there through fear as an edict had been published commanding the attendance of all. But St. Leo, who was a good Christian, departed from the city, and went to perform his devotions before the relics of St. Paregorius who had died for the Faith some short time previously. Upon his return home, St. Paregorius appeared to him in a vision, standing at the opposite side of a torrent, and inviting him to pass over.

St. Leo hence conceived a great hope that he would be honoured with Martyrdom; and going some days after to make a second visit to the tomb of St. Paregorius, he passed by the temple of fortune, where many lanterns burned before the idol. Impelled by a special impulse of the Holy Ghost, he entered the temple and threw down the lights; but the idolaters, enraged at the insult offered to their idol, raised such a clamour, that the governor heard of the affair, and ordered that the Saint should be brought before him.

When Leo made his appearance, the governor rebuked him for the outrage he had committed against the gods, in violation of the commands of the sovereign. The Saint animated with a holy zeal, replied: \"Thou speakest to me of the gods, as if there were many. There is but One God, and Jesus Christ is His Only-Begotten Son. Since statues of stone and wood are devoid of sense and feeling, of what use can lanterns be to them? If thou hadst the knowledge of the true God, thou wouldst not worship these false deities. Oh, do abandon this vain superstition, and adore our Lord and Saviour, Jesus Christ!\"

The governor said: \"Thou dost, then, exhort me to become a Christian? Better it were for thee to conform to the general practice, lest thy rashness be punished as it deserves.\" The Saint with increased ardour replied: \"I see about me a multitude of those who, blindly persevering in error, despise the true God; but I am a Christian notwithstanding, and follow the instructions of the Apostles. If this deserve chastisement, award it; for I am determined to suffer every torture, rather than become the slave of the devil. Others may do as they please, since they are solicitous merely for the present, and are reckless of the future life which is to be obtained only by sufferings. The Scripture tells us that *narrow is the gate, and strait is the way, that leadeth to life*.\" (Matt. vii. 14).

The governor observed: \"Since, then, the way of the Christians is narrow; exchange it for ours, which is wide and commodius.\" Leo answered: \"I have said that the way is narrow, because it is one of affliction and of persecutions suffered for justice sake; but it is wide enough for those who walk therein, because their Faith and the hope of an eternal reward, make it so to them. The love of virtue maketh that easy which to thee seemeth difficult. On the contrary, the road of vice is in reality narrow, and leads to an eternal precipice.\"

This discourse was most unpalatable to the pagans who accordingly exclaimed that the impious man who had spoken against their religion, should be silenced. The governor then asked St. Leo whether he would sacrifice; and being answered that his compliance was totally impossible, he ordered him to be scourged. Although this command was most cruelly executed, the Saint suffered without a groan; whereupon the governor threatened still greater torments; but the Saint answered: \"I know not these gods, and will never sacrifice to them.\" \"At least,\" said the governor, \"say that our gods are great, and I will dismiss thee, for I have compassion on thy old age.\" The Saint replied: \"They are great for the destruction of those souls that believe in them.\" The governor, infuriated at this reply, said: \"I will order thee to be dragged over stones till thou art torn to pieces.\" The Saint replied: \"I shall welcome any kind of death that procures me the kingdom of Heaven, and that blessed life which I shall enjoy in company with the Saints, upon my departure from this world.\"

The tyrant continued to importune him to sacrifice, or at least to acknowledge that the gods could save him from death. The Saint replied: \"Thou art very weak, since thou dost nothing but threaten, without putting thy threats into execution.\" The populace, being enraged at this reply, obliged the judge to condemn the Saint to be tied by the feet and dragged through a torrent.

St. Leo finding himself about to obtain the accomplishment of his desire to die for Jesus Christ, raised his eyes to Heaven and prayed after the following manner: \"I thank Thee, O God, the Father of Our Lord Jesus Christ, for granting me the grace to follow Thy servant Paregorius. I praise Thee, because Thou hast enabled me, by Martyrdom, to cancel my past sins. I commend my soul to the care of Thy holy Angels, that it may be saved from the perdition prepared for the wicked. I beseech Thee, by that which it is my blessed lot to suffer, to have mercy on those who are the cause thereof; and since Thou desirest not the death of the sinner, grant them the grace to recognize Thee as the Lord of the universe. May all that which I suffer in the Name of Jesus Christ, Thy Son, redound to Thy glory for ever and ever. Amen.\" As soon as he pronounced the word *Amen*, he rendered up his soul to God, and went to enjoy the crown to which St. Paregorius had invited him.

The executioners cast the body into a deep pit in order to break it to pieces; but it was taken thence and found entire, with only a few slight bruises, and the face appeared comely and smiling.

## Evening Meditation

THE VANITY OF THE WORLD

I.

*Only the grave*, says holy Job, *remaineth for me* (Job xvii. 1). Days and years pass away, pleasures, honours and riches pass away, and what will be the end? Death will come and strip us of all, and we shall be buried in the grave to corrupt and moulder into dust, deserted and forgotten by all. Alas! how, in the end of our lives, will the remembrance of all we have acquired in this world serve for nothing but to increase our anguish and the uncertainty of our salvation!

O death, O death, never depart from before my eyes! O God, do Thou enlighten me!

*My life is cut off as by a weaver* (Is. xxxviii. 12). How many, in the midst of executing their long contemplated designs, are overtaken by death and deprived of all things! Ah, with what pain and remorse will the goods of this world be regarded on the bed of death, by those who have been unduly attached to them! To worldlings who are spiritually blind the goods of this present life appear great; but death will discover what they really are, \-- dust, smoke, and vanity. In the light of this last candle all the dazzling grandeur of this world will vanish and disappear. The greatest fortunes, the highest honours, when considered on the bed of death, will lose all their value and splendour. The shadow of death will obscure even crowns and sceptres.

Grant me, O God, Thy holy grace, for this alone is all I desire. I am grieved for having ever despised such a treasure. Jesus, have pity on me.

II\.

Of what avail, then, will riches be at the hour of death, when nothing will remain for us but a wooden coffin and a winding-sheet? Of what avail will be the honours which we have acquired; when no others will now remain for us but a funeral procession and a tomb, which will not be able to afford us the least satisfaction, if our souls should be lost? And of what avail will the beauty of the body be; when the body itself will become a mass of worms, infect the air with its stench, and excite horror in all who behold it?

My dear Redeemer, although I knew that by sinning I would forfeit Thy friendship, yet did I sin; but I hope for pardon from Thee Who hast died to purchase pardon for me. O that I had never offended Thee, my good God! I behold the love which Thou hast shown me; and this increases my grief for having displeased Thee Who art so good a Father. I love Thee, O Lord, and will never live without loving Thee; give me perseverance. Mary, my Mother, pray to Jesus for me.
